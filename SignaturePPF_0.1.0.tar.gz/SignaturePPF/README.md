# SignaturePPF

Poisson process factorization for mutational signature analysis with genomic
covariates.

Mutations are modelled as an inhomogeneous Poisson point process along the
genome. The intensity is shaped by genomic covariates — chromatin marks,
replication timing, GC content, methylation, nucleosome occupancy — through a
log-linear term, on top of a signature factorization of the 96 substitution
channels:

$$\lambda_{ij}(t) = \tfrac{1}{2}\,c_j(t) \sum_k r_{ik}\,\phi_{kj}\,e^{\beta_k'x(t)}$$

Each signature therefore has both a **level** in each sample and a **shape**
along the genome, and the two are separately identified.

## Installation

```r
install.packages("SignaturePPF_0.1.0.tar.gz", repos = NULL, type = "source")
```

## Tutorial

`vignette("getting-started", package = "SignaturePPF")` gives a description of
the model and a worked analysis on simulated data.

## Usage

```r
library(SignaturePPF)

# `data` is a list with gr_Mutations, SignalTrack and CopyTrack.
# Check it before committing to a long run:
SignaturePPF_validate(data)

# De novo, posterior mode
fit <- SignaturePPF(data, K = 10, method = "map", seed = 1)

# De novo, full posterior; start at the mode and drop the signatures it parked
fit <- SignaturePPF(data, K = 20, method = "mcmc", seed = 1,
                    prune_after_map = TRUE,
                    controls = SignaturePPF_control(nsamples = 10000,
                                                    burnin = 2000,
                                                    thin = 5))

# Refit against a reference catalogue (signatures held fixed)
sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS2", "SBS3", "SBS5", "SBS13")]
fit <- SignaturePPF(data, sigs = sigs, method = "mcmc", seed = 1)

# Semi-supervised: references anchored but free to move, plus 5 de novo
fit <- SignaturePPF(data, sigs = sigs, sigs_fixed = FALSE, K = 5,
                    method = "mcmc", seed = 1)

summary(fit)
```

`fit$Betas` holds the covariate coefficients (`p x K`), `fit$Thetas` the total
activities $\theta_{kj}$ — expected mutation *counts*, not rates — and
`fit$MCMCchain` the stored draws.

### Three modes

| Call | Mode | Total signatures |
|---|---|---|
| `sigs = NULL` | de novo | `K` |
| `sigs = S` | refit, signatures fixed | `ncol(S)` |
| `sigs = S, sigs_fixed = FALSE` | semi-supervised | `ncol(S) + K` |

In the semi-supervised mode each reference gets an informative Dirichlet prior
centred on itself, and `K` further signatures are estimated de novo alongside —
the recovery-discovery setting of CompressiveNMF. `K = 0` gives a soft refit:
every signature anchored, none free. The compressive prior applies in all three
modes, so a reference the cohort does not support is pruned like any other.

#### How informative is the informative prior

The prior on reference *h* is `Dirichlet(betah_h * s_h)` — mean at the
reference, total concentration `betah_h`. That concentration is the only thing
controlling how far the data may move a signature, and it has no natural scale.
`betah = "auto"` (the default) calibrates it per signature on a scale that does:
the concentration at which a draw from the prior has median cosine similarity
0.975 to the reference it is centred on.

```r
b <- tune_betah(sigs)          # inspect or precompute
b <- Betah_SBS96_GRCh37_v3.4   # precalibrated for COSMIC v3.4
```

The spread matters: SBS2 needs about 17 and SBS3 about 1337 to sit at the same
similarity, because a spiked signature is far easier to reproduce from a
Dirichlet draw than a flat one. A single shared `betah` would silently make the
prior much looser on flat signatures than on spiked ones.

### Long runs

A whole-genome chain runs for hours. Point the fit at a checkpoint directory and
it executes in blocks, writing its state after each one:

```r
fit <- SignaturePPF(data, K = 20, method = "mcmc", seed = 1,
                    controls = SignaturePPF_control(nsamples = 20000,
                                                    burnin = 5000, thin = 5),
                    checkpoint = SignaturePPF_checkpoint(dir = "run/breast",
                                                         every = 200))
```

Re-issuing **the same call** after a crash, a wall-clock kill or a Ctrl-C picks
the chain up where it stopped, so a long fit can be finished over several
submissions of one script. Resuming is exact: the RNG state, the AGESS
adaptation and the sweep counter all cross the block boundary, and the assembled
chain is bit-identical to an uninterrupted run of the same length. This is
enforced by the test suite, including a test that interrupts a chain mid-sweep
and checks the resumed result against an uninterrupted reference.

Resuming onto a checkpoint written under different data, priors, controls or
seed is refused rather than silently continued.

### Progress

With `verbose = TRUE` each report gives the objective, the median per-sweep cost
over a trailing window, elapsed time and an ETA:

```
  iter    1200/10000 | logpost -1.234568e+07 |    0.84 s/it | elapsed 00:17:12 | eta 02:03:41
```

The line is refreshed in place interactively and written line-by-line when
output is redirected to a log file. Runs are interruptible with Ctrl-C.

## Design notes

* **The activity prior.** The covariate effect is carried in the rate of the
  Gamma prior on the baseline, so that $\theta_{kj} = \phi_{kj}q_j(\beta_k)$ has
  a prior free of $\beta$. This separates the level of a signature from its
  genomic shape and removes the strong $\theta$–$\beta$ posterior dependence.
  One consequence: an intercept column in `SignalTrack` is not identified, and
  is rejected by `SignaturePPF_validate()`.
* **AGESS.** The $\beta$ block is sampled by adaptive generalized elliptical
  slice sampling (Marco & Tokdar, arXiv:2605.21659), which learns the ellipse
  from the chain instead of drawing it from the far more diffuse prior. The
  plain `"ess"` kernel is kept for comparison.
* **Thinning.** The $\beta$ block mixes slowly enough that neighbouring sweeps
  are near-duplicates, so `thin` costs little and divides the stored chain and
  every checkpoint by the same factor.

## Reproducing the paper

The analysis code, data-preparation scripts and figure pipeline are distributed
with the paper's reproducibility materials, which pin the exact version of this
package used for the published results.
