# Prior strength for informative signatures.
#
# A reference signature enters the model as a Dirichlet prior with mean at the
# reference and total concentration betah:
#
#     r_{.h} ~ Dirichlet(betah_h * s_h),      sum_i s_ih = 1
# `betah = "auto"` picks, per signature, the smallest concentration at which a
# prior draw is on median `target` cosine-similar to the reference.
#
# The calibration is per signature and not shared, because a flat signature
# (SBS3, SBS5) and a spiked one (SBS1, SBS10a) need very different
# concentrations to sit at the same similarity.

# Median cosine similarity between the reference and draws from Dir(betah * s).
.median_cosine <- function(betah, s, nsim) {
  I <- length(s)
  # Dirichlet by normalised gammas. Shapes vary down the columns, so `each` is
  # what lines coordinate i up with column i.
  g <- matrix(stats::rgamma(nsim * I, shape = rep(betah * s, each = nsim)),
              nrow = nsim, ncol = I)
  tot <- rowSums(g)
  # A draw of all zeros can happen when betah is tiny and s is spiked.
  keep <- tot > 0
  if (!any(keep)) return(0)
  g <- g[keep, , drop = FALSE] / tot[keep]
  stats::median(as.vector(g %*% s) / (sqrt(rowSums(g^2)) * sqrt(sum(s^2))))
}


#' Calibrate the strength of an informative signature prior
#'
#' Finds, for each reference signature, the concentration `betah` at which a draw
#' from \eqn{\mathrm{Dirichlet}(\mathrm{betah} \times s)} has median cosine
#' similarity `target` to the reference \eqn{s} itself.
#'
#' This turns an uninterpretable concentration into a statement one can actually
#' hold an opinion about: at the default `target = 0.975`, the prior says "the
#' true signature looks like the reference to within a cosine of about 0.975",
#' which is roughly the tolerance at which two signatures are still called the
#' same. Lowering `target` loosens the prior and lets the data reshape the
#' signature more; raising it towards 1 approaches a hard refit.
#'
#' Over the range that matters the miss \eqn{1 - \cos} is inversely proportional
#' to `betah`, which the default engine exploits to solve for it directly rather
#' than bisecting; every step is still checked by an actual Monte Carlo
#' evaluation, so the scaling law only sets where to look, never what is
#' returned. It is a Monte Carlo criterion, hence `seed`: the calibration is made
#' deterministic given `sigs` and `target` so that it does not silently make a
#' fit irreproducible.
#'
#' @param sigs A reference signature matrix, channels in rows. Columns are
#'   renormalised to sum to one.
#' @param target Target median cosine similarity between the reference and a draw
#'   from its prior.
#' @param nsim Monte Carlo draws per evaluation.
#' @param range Bounds on `betah`. The solution is clamped to this interval. The
#'   lower bound is not arbitrary: below roughly 10 the Dirichlet is close to
#'   degenerate - almost all its mass sits on a single channel - and for a spiked
#'   signature that degenerate draw has a HIGH cosine to the reference. Median
#'   similarity is therefore not monotone in `betah` down there, and a bracket
#'   reaching to 0 admits a second, meaningless root. CompressiveNMF's own grid
#'   starts at 10 for the same reason.
#' @param seed Seed for the Monte Carlo. The ambient RNG stream is restored
#'   afterwards, so calibrating does not shift a chain drawn later.
#' @param tol Stop once a measured median similarity is within `tol` of `target`.
#' @param max_iter Cap on Monte Carlo evaluations per signature.
#' @param engine `"cpp"` (default) solves for `betah` directly using the
#'   \eqn{(1-\cos) \propto 1/\mathrm{betah}} scaling, checking each step by Monte
#'   Carlo. `"R"` is a slower reference implementation that brackets and bisects;
#'   it targets the same criterion and exists to test the fast path against.
#'
#' @returns A named numeric vector of concentrations, one per signature, with the
#'   achieved median similarity in the `"similarity"` attribute.
#'
#' @examples
#' sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS5")]
#' tune_betah(sigs, nsim = 200)
#'
#' @seealso [SignaturePPF()]
#' @export
tune_betah <- function(sigs, target = 0.975, nsim = 1000,
                       range = c(10, 1e5), seed = 1L, tol = 1e-3,
                       max_iter = 20L, engine = c("cpp", "R")) {
  engine <- match.arg(engine)
  sigs <- as.matrix(sigs)
  if (is.null(colnames(sigs))) colnames(sigs) <- sprintf("Ref%02d", seq_len(ncol(sigs)))
  sigs <- sweep(sigs, 2, colSums(sigs), "/")
  stopifnot(target > 0, target < 1, range[1] > 0, range[1] < range[2])

  # Calibration must not consume the caller's RNG stream: betah is a property of
  # the reference, not of the run, and a fit's draws should not depend on how
  # many signatures happened to need tuning.
  old <- if (exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
    get(".Random.seed", envir = globalenv(), inherits = FALSE)
  } else NULL
  on.exit(if (!is.null(old)) assign(".Random.seed", old, envir = globalenv()),
          add = TRUE)
  set.seed(seed)

  if (engine == "cpp") {
    res <- .tune_betah_cpp(sigs, target = target, nsim = as.integer(nsim),
                           lo = range[1], hi = range[2],
                           max_iter = as.integer(max_iter), tol = tol)
    out <- stats::setNames(as.numeric(res$betah), colnames(sigs))
    # Sitting at the lower bound with a similarity ABOVE target is not a failure:
    # it means even the loosest prior allowed is already more concentrated than
    # asked for, which is the expected outcome for a spiked signature. Failing to
    # REACH the target is the case worth warning about.
    missed <- (res$similarity < target - tol) |
      (abs(res$similarity - target) > tol & out > range[1])
    if (any(missed)) {
      warning("betah could not be calibrated to within ", tol, " of ", target,
              " for: ", paste(colnames(sigs)[missed], collapse = ", "),
              ". The value is at a bound of `range`, or `max_iter` was reached.",
              call. = FALSE)
    }
    attr(out, "similarity") <- as.numeric(res$similarity)
    attr(out, "iters") <- as.integer(res$iters)
    attr(out, "target") <- target
    return(out)
  }

  out <- vapply(seq_len(ncol(sigs)), function(h) {
    s <- sigs[, h]
    lo <- range[1]
    hi <- range[2]

    if (.median_cosine(hi, s, nsim) < target) {
      warning("signature ", colnames(sigs)[h], ": even betah = ", hi,
              " does not reach a median similarity of ", target,
              "; returning the upper bound.", call. = FALSE)
      return(hi)
    }
    if (.median_cosine(lo, s, nsim) > target) return(lo)

    # Bisection in log10(betah): the criterion is monotone increasing. This is
    # the reference path; `engine = "cpp"` solves the same equation directly.
    llo <- log10(lo)
    lhi <- log10(hi)
    while (lhi - llo > 0.005) {           # ~1% resolution in betah
      mid <- (llo + lhi) / 2
      if (.median_cosine(10^mid, s, nsim) < target) llo <- mid else lhi <- mid
    }
    10^lhi
  }, numeric(1))

  names(out) <- colnames(sigs)
  attr(out, "similarity") <- vapply(seq_along(out), function(h) {
    .median_cosine(out[h], sigs[, h], nsim)
  }, numeric(1))
  attr(out, "target") <- target
  out
}


# Resolves the `betah` argument to one concentration per informative signature.
.resolve_betah <- function(betah, sigs, verbose) {
  H <- ncol(sigs)

  if (is.character(betah)) {
    if (!identical(betah, "auto")) {
      stop("`betah` must be \"auto\", a number, or a named numeric vector.",
           call. = FALSE)
    }
    if (verbose) message("Calibrating betah for ", H, " reference signature(s).")
    return(tune_betah(sigs))
  }

  if (!is.numeric(betah)) {
    stop("`betah` must be \"auto\", a number, or a named numeric vector.",
         call. = FALSE)
  }
  if (any(betah <= 0)) stop("`betah` must be positive.", call. = FALSE)

  # Names are checked BEFORE the scalar shortcut. A named vector is a per-signature
  # specification, so `c(SBS1 = 300)` against two references is a missing entry,
  # not a scalar to broadcast - silently giving the unnamed reference SBS1's
  # concentration would be the wrong prior, applied without a word.
  if (!is.null(names(betah))) {
    absent <- setdiff(colnames(sigs), names(betah))
    if (length(absent)) {
      stop("`betah` has no entry for: ", paste(absent, collapse = ", "),
           ". Pass a single unnamed number to use one value for all.",
           call. = FALSE)
    }
    return(betah[colnames(sigs)])
  }
  if (length(betah) == 1L) {
    return(stats::setNames(rep(as.numeric(betah), H), colnames(sigs)))
  }
  if (length(betah) != H) {
    stop("`betah` has length ", length(betah), " but there are ", H,
         " reference signature(s), and it is unnamed.", call. = FALSE)
  }
  stats::setNames(as.numeric(betah), colnames(sigs))
}
