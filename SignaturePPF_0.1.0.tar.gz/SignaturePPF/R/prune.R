# The reported solution, as distinct from the record of the run.
#
# A fit carries two different things. `MAPsolution` and `MCMCchain` are the
# RECORD: what the optimizer did, what the sampler visited, every signature it
# was given including the ones it switched off. The named top-level slots -
# Signatures, Thetas, Baseline, Q, Betas, Mu, Sigma2 - are the SOLUTION: the
# answer being reported.
#
# The compressive prior means those two are not the same object. `K` is an upper
# bound, and the prior parks the signatures the cohort does not support at
# mu ~ epsilon. Their coefficients are then draws from the prior rather than
# estimates, so carrying them in the solution misleads in a specific way: a beta
# row can look large on a signature that explains nothing. The functions here
# separate the two, and only ever touch the solution.


# Which slots are indexed by signature, and on which margin.
.SIG_COL <- c("Signatures", "SigPrior", "Betas")     # I x K, I x K, p x K
.SIG_ROW <- c("Thetas", "Baseline", "Q")             # K x J
.SIG_VEC <- c("Mu", "Sigma2")                        # length K
# Inside `lowCI` / `highCI`, keyed by the block they bound.
.CI_COL  <- c("Signatures", "Betas")
.CI_ROW  <- "Thetas"
.CI_VEC  <- c("Mu", "Sigma2")


#' Drop the switched-off signatures from the reported solution
#'
#' The compressive prior on \eqn{\mu} parks a signature the cohort does not
#' support near `epsilon` instead of removing it, so `K` is an upper bound and a
#' fit routinely reports signatures that carry nothing. This removes them from
#' the SOLUTION - `Signatures`, `Thetas`, `Baseline`, `Q`, `Betas`, `Mu`,
#' `Sigma2`, `SigPrior` and the credible intervals - and leaves the RECORD
#' untouched: `MAPsolution` and `MCMCchain` keep every signature.
#'
#' Keeping the record whole is not tidiness. It is what lets the same run be
#' re-summarised at another threshold, what keeps a checkpointed chain resumable
#' - a chain with columns missing could not be continued - and what makes the
#' pruning auditable, since `fit$MCMCchain$MUchain[, fit$pruned]` shows exactly
#' what was dropped and how close to the threshold it sat.
#'
#' The operation is MONOTONE: it can remove signatures, never bring them back.
#' Applying it twice at the same threshold is a no-op; applying it again at a
#' looser threshold does not restore anything, because the solution it is given
#' no longer holds the dropped columns. Re-summarise from `MCMCchain` for that.
#'
#' [SignaturePPF()] calls this at the end of a fit unless `prune_solution` is
#' `FALSE`. It is exported so a fit made before this existed can be pruned
#' without refitting.
#'
#' @param fit A `SignaturePPF` fit.
#' @param threshold Keep signatures with `Mu` strictly above this. `NULL` uses
#'   `10 * fit$prior$epsilon`, the same scale the `print()` method reports
#'   against.
#' @param verbose Report what was dropped.
#'
#' @returns The fit, with `pruned` naming the signatures removed, `K` the number
#'   retained and `K_fitted` the number the run was given.
#' @seealso [SignaturePPF()], [add_credible_intervals()]
#' @export
prune_signatures <- function(fit, threshold = NULL, verbose = TRUE) {
  if (!inherits(fit, "SignaturePPF")) {
    stop("`fit` must be a SignaturePPF fit.", call. = FALSE)
  }
  if (!isTRUE(fit$complete)) {
    stop("this fit is incomplete; there is no solution to prune.", call. = FALSE)
  }

  thr <- if (is.null(threshold)) 10 * fit$prior$epsilon else threshold
  keep <- names(fit$Mu)[fit$Mu > thr]

  if (!length(keep)) {
    warning("no signature has Mu above ", format(thr),
            "; the solution is left unpruned.", call. = FALSE)
    return(fit)
  }

  dropped <- setdiff(names(fit$Mu), keep)
  if (verbose && length(dropped)) {
    message(sprintf("Pruned %d of %d signature(s) at Mu <= %s: %s",
                    length(dropped), length(fit$Mu), format(thr),
                    paste(dropped, collapse = ", ")))
  }

  # `K_fitted` is set once, by the first prune, and records what the RUN was
  # given. A second prune must not overwrite it with the already-reduced count.
  if (is.null(fit$K_fitted)) fit$K_fitted <- length(fit$Mu)
  fit <- .subset_solution(fit, keep)
  fit$pruned <- c(fit$pruned, dropped)
  fit$prune_threshold <- thr
  fit$K <- length(keep)

  # In the semi-supervised mode a REFERENCE signature can be among the pruned -
  # that is what makes it a recovery procedure rather than a forced attribution -
  # so H and betah have to describe the references that survived rather than the
  # matrix that was passed in.
  if (!is.null(fit$H) && fit$H > 0L) {
    if (length(fit$betah)) {
      refs <- intersect(keep, names(fit$betah))
      fit$H <- length(refs)
      fit$betah <- fit$betah[refs]
    } else {
      # A hard refit: every signature is a reference, so H tracks K.
      fit$H <- length(keep)
    }
  }
  fit
}


#' Attach posterior credible intervals to a fit
#'
#' [SignaturePPF()] stores `ci_level` intervals for the sampled blocks as part of
#' an MCMC fit. This recomputes them - at the same level or another one - from
#' the chain the fit carries, so a fit made before the intervals existed, or one
#' wanted at a different level, does not have to be refitted.
#'
#' Intervals are given for the blocks the sampler actually visits: `Signatures`,
#' `Thetas`, `Betas`, `Mu` and `Sigma2`. `Baseline` and `Q` are deterministic
#' functions of \eqn{\beta} evaluated at its posterior MEAN, and an honest
#' interval for them needs \eqn{e^{\beta'x}} over every bin once per draw - a
#' full pass over `SignalTrack` and `CopyTrack` per draw, which on a genome-scale
#' fit costs more than the chain did. They are left as plug-ins.
#'
#' Only the signatures the fit currently reports are summarised, so the bounds
#' line up with `fit$Betas` and friends after pruning.
#'
#' @param fit An MCMC `SignaturePPF` fit.
#' @param level Credible level.
#'
#' @returns The fit, with `lowCI`, `highCI` and `ci_level` set.
#' @seealso [posterior_CI()], [prune_signatures()]
#' @export
add_credible_intervals <- function(fit, level = 0.95) {
  if (!inherits(fit, "SignaturePPF")) {
    stop("`fit` must be a SignaturePPF fit.", call. = FALSE)
  }
  if (!identical(fit$method, "mcmc")) {
    stop("credible intervals need method = \"mcmc\"; this is a MAP fit.",
         call. = FALSE)
  }
  if (is.null(fit$MCMCchain)) {
    stop("this fit carries no chain, so its intervals cannot be recomputed.",
         call. = FALSE)
  }

  blocks <- c("Signatures", "Thetas", "Betas", "Mu", "Sigma2")
  q <- lapply(blocks, function(b) posterior_CI(fit, b, level))
  names(q) <- blocks
  fit$lowCI <- lapply(q, `[[`, "lowCI")
  fit$highCI <- lapply(q, `[[`, "highCI")
  fit$ci_level <- level
  fit
}


# Subset every signature-indexed slot of the SOLUTION. Deliberately does not
# touch MAPsolution or MCMCchain.
.subset_solution <- function(fit, keep) {
  for (s in intersect(.SIG_COL, names(fit))) {
    fit[[s]] <- fit[[s]][, keep, drop = FALSE]
  }
  for (s in intersect(.SIG_ROW, names(fit))) {
    fit[[s]] <- fit[[s]][keep, , drop = FALSE]
  }
  for (s in intersect(.SIG_VEC, names(fit))) {
    fit[[s]] <- fit[[s]][keep]
  }
  for (bound in c("lowCI", "highCI")) {
    ci <- fit[[bound]]
    if (is.null(ci)) next
    for (b in intersect(.CI_COL, names(ci))) ci[[b]] <- ci[[b]][, keep, drop = FALSE]
    for (b in intersect(.CI_ROW, names(ci))) ci[[b]] <- ci[[b]][keep, , drop = FALSE]
    for (b in intersect(.CI_VEC, names(ci))) ci[[b]] <- ci[[b]][keep]
    fit[[bound]] <- ci
  }
  fit
}
