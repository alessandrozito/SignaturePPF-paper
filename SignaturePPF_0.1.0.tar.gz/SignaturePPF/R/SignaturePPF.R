#' Poisson process factorization of mutational signatures with genomic covariates
#'
#' Fits the Poisson process factorization (PPF) under the activity prior, either
#' de novo or as a refit against a reference catalogue, by MAP or by MCMC.
#'
#' @section The model:
#' Mutations of sample \eqn{j} are an inhomogeneous Poisson process along the
#' genome whose intensity in channel \eqn{i} at position \eqn{t} is
#' \deqn{\lambda_{ij}(t) = \tfrac{1}{2} c_j(t) \sum_k r_{ik}\,\phi_{kj}\,e^{\beta_k'x(t)},}
#' with \eqn{r_{\cdot k}} the \eqn{k}th signature over the 96 substitution
#' channels, \eqn{c_j(t)} the copy number, \eqn{x(t)} the genomic covariates and
#' \eqn{\beta_k} their coefficients for signature \eqn{k}.
#'
#' Under the **activity prior** the covariate effect is carried in the rate of
#' the Gamma prior on the baseline,
#' \deqn{\phi_{kj}\mid\mu_k \sim \mathrm{Ga}\!\left(a,\ \tfrac{a}{\mu_k}\int_0^T \tfrac12 c_j(t)e^{\beta_k'x(t)}\mathrm{d}t\right),}
#' so that writing \eqn{q_j(\beta_k) = \int_0^T \tfrac12 c_j(t)e^{\beta_k'x(t)}\mathrm{d}t}
#' the reparametrisation \eqn{\theta_{kj} = \phi_{kj}q_j(\beta_k)} gives
#' \eqn{\theta_{kj}\mid\mu_k \sim \mathrm{Ga}(a, a/\mu_k)}, free of \eqn{\beta}.
#' Since \eqn{\theta_{kj}} is exactly the expected number of signature-\eqn{k}
#' mutations in sample \eqn{j}, the model separates the LEVEL of a signature
#' (carried by \eqn{\theta}) from its SHAPE along the genome (carried by
#' \eqn{\beta}). Two consequences:
#'
#' * \eqn{\mu_k} is the expected count per sample, so `epsilon` and the pruning
#'   rule on `Mu` are on an interpretable scale.
#' * \eqn{\beta_k} no longer sets the overall level, which breaks the strong
#'   \eqn{\theta}-\eqn{\beta} posterior dependence. The flip side is that a
#'   direction along which `SignalTrack` is nearly constant is nearly
#'   unidentified and is pinned by the prior; an intercept column is rejected
#'   outright by [SignaturePPF_validate()].
#'
#' @section Three modes:
#'
#' * **de novo** (`sigs = NULL`): `K` signatures are estimated from the data
#'   under a flat \eqn{\mathrm{Dirichlet}(\alpha)} prior. The compressive prior on
#'   \eqn{\mu} parks unsupported signatures near `epsilon`, so `K` is an upper
#'   bound rather than a count; see `prune_after_map`.
#' * **refit** (`sigs` given, `sigs_fixed = TRUE`): the signatures are held at
#'   `sigs` and only activities and coefficients are estimated. `K` is
#'   `ncol(sigs)`; the `K` argument is ignored.
#' * **semi-supervised** (`sigs` given, `sigs_fixed = FALSE`): the `ncol(sigs)`
#'   reference signatures are given an INFORMATIVE Dirichlet prior centred on
#'   themselves, and `K` further signatures are estimated de novo alongside. The
#'   total is `ncol(sigs) + K`. This is the recovery-discovery setting of
#'   CompressiveNMF: references are anchored but free to move, and anything they
#'   fail to explain is picked up by the de novo columns. `K = 0` is allowed and
#'   gives a soft refit - every signature anchored, none free.
#'
#' The compressive prior applies to all signatures in every mode, so a reference
#' the cohort does not support is pruned like any other. That is what makes the
#' semi-supervised mode a recovery procedure rather than a forced attribution.
#'
#' @section How informative is the informative prior:
#' In the semi-supervised mode the prior on reference signature \eqn{h} is
#' \deqn{r_{\cdot h} \sim \mathrm{Dirichlet}(\mathrm{betah}_h \, s_h),}
#' with mean at the reference \eqn{s_h} and total concentration
#' \eqn{\mathrm{betah}_h}. That concentration is the only thing controlling how
#' far the data may move a signature, and it has no natural scale - it is a mass
#' spread over 96 channels.
#'
#' `betah = "auto"` therefore calibrates it, per signature, on a scale that does
#' mean something: the concentration at which a draw from the prior has median
#' cosine similarity 0.975 to the reference it is centred on. See [tune_betah()]
#' to change that target, to inspect what was chosen, or to precompute it. A
#' scalar or a named vector can be passed instead. Calibration is deterministic
#' and does not consume the run's RNG stream.
#'
#' @section MCMC from the MAP:
#' `init_mcmc_from_map = TRUE` runs the optimizer first and starts the chain at
#' the mode. This removes most of the transient, so `burnin` can be far shorter
#' than from a random start - but note that it also means the chain begins in a
#' region the optimizer chose, so signatures the MAP has already pruned to
#' \eqn{\mu \approx \epsilon} are unlikely to be revived. `prune_after_map`
#' makes that explicit by dropping them before sampling.
#'
#' @param data A list with `gr_Mutations`, `SignalTrack` and `CopyTrack`; see
#'   [SignaturePPF_validate()] to check validity.
#' @param sigs Reference signature matrix with channels in rows and signatures in
#'   columns. Rows are matched to the mutation channels by name; columns are
#'   renormalised to sum to one.
#' @param sigs_fixed With `sigs` supplied, whether the references are held FIXED
#'   (`TRUE`, a refit) or given an informative prior and allowed to move
#'   (`FALSE`, semi-supervised). Ignored when `sigs` is `NULL`.
#' @param K Number of DE NOVO signatures. The total is `K` for a de novo fit,
#'   `ncol(sigs)` for a refit (where `K` is ignored), and `ncol(sigs) + K` for a
#'   semi-supervised one.
#' @param betah Strength of the informative prior, used only in the
#'   semi-supervised mode. `"auto"` (default) calibrates one concentration per
#'   reference signature with [tune_betah()]; a single number applies to all; a
#'   named vector gives one each.
#' @param method `"map"` for the posterior mode, `"mcmc"` for the full posterior.
#' @param prior Prior hyperparameters, see [SignaturePPF_prior()].
#' @param controls Algorithm settings, see [SignaturePPF_control()].
#' @param init Starting values for the estimation algorithm, see [SignaturePPF_init()].
#' @param init_mcmc_from_map Start the chain from the MAP. Only used when
#'   `method = "mcmc"`.
#' @param prune_after_map Drop signatures whose MAP `Mu` falls below
#'   `prune_threshold` before starting the chain. Requires `init_mcmc_from_map = TRUE`.
#'   This changes WHAT IS FITTED - the dropped signatures are not sampled - and is
#'   a different thing from `prune_solution`, which only changes what is reported.
#' @param prune_solution Drop the signatures the compressive prior has switched
#'   off from the REPORTED solution, i.e. from `Signatures`, `Thetas`, `Baseline`,
#'   `Q`, `Betas`, `Mu`, `Sigma2` and the credible intervals. `MAPsolution` and
#'   `MCMCchain` keep every signature, so nothing about the run is lost and the
#'   pruning can be undone or redone at another threshold. See
#'   [prune_signatures()].
#' @param prune_threshold Threshold on `Mu`, shared by `prune_after_map` and
#'   `prune_solution`. `NULL` uses `10 * prior$epsilon`.
#' @param ci_level MCMC. Credible level of the intervals stored in `lowCI` and
#'   `highCI`.
#' @param checkpoint Checkpointing for long chains, see [SignaturePPF_checkpoint()].
#'                   Disabled by default.
#' @param seed Integer seed. Recorded in the fit, and used for the checkpoint
#'   fingerprint. `NULL` leaves the ambient RNG state alone, and makes the run
#'   irreproducible.
#' @param verbose Report progress. Prints the iteration, the objective, the
#'   median per-iteration time over a trailing window, elapsed time and an ETA.
#'
#' @returns An object of class `SignaturePPF`:
#'   \item{Signatures}{`I x K` signature matrix.}
#'   \item{Thetas}{`K x J` TOTAL activities \eqn{\theta_{kj}}, i.e. expected
#'     counts - not the baseline.}
#'   \item{Baseline}{`K x J` baseline \eqn{\phi_{kj} = \theta_{kj}/q_j(\beta_k)`}.}
#'   \item{Q}{`K x J` matrix of \eqn{q_j(\beta_k)}.}
#'   \item{Betas}{`p x K` covariate coefficients.}
#'   \item{Mu, Sigma2}{Relevance weights and variances of the regression coefficients}
#'   \item{lowCI, highCI}{MCMC only: named lists of `ci_level` credible bounds for
#'     `Signatures`, `Thetas`, `Betas`, `Mu` and `Sigma2` - the SAMPLED blocks.
#'     `Baseline` and `Q` are plug-ins at the posterior mean of \eqn{\beta} and
#'     have no interval; see [posterior_CI()].}
#'   \item{MCMCchain}{MCMC only: the stored draws, on the activity scale. Always
#'     holds every signature, including any `prune_solution` removed above.}
#'   \item{MAPsolution}{MAP only: the raw optimizer output, including the objective
#'     trace. Likewise never pruned.}
#'   \item{pruned}{Signatures dropped by `prune_solution`, and `K_fitted` the
#'     number before pruning.}
#'   Along with the resolved `prior`, `controls`, `init`, `type`, `K`, `H` (the
#'   number of informative references), `betah`, `SigPrior`, `seed`, `runtime`
#'   and `call`.
#'
#' @seealso [SignaturePPF_control()], [SignaturePPF_checkpoint()],
#'   [SignaturePPF_validate()]
#' @export
SignaturePPF <- function(data,
                         sigs = NULL,
                         sigs_fixed = TRUE,
                         K = 10,
                         betah = "auto",
                         method = c("map", "mcmc"),
                         prior = SignaturePPF_prior(),
                         controls = SignaturePPF_control(),
                         init = SignaturePPF_init(),
                         init_mcmc_from_map = TRUE,
                         prune_after_map = FALSE,
                         prune_solution = TRUE,
                         prune_threshold = NULL,
                         ci_level = 0.95,
                         checkpoint = SignaturePPF_checkpoint(),
                         seed = NULL,
                         verbose = TRUE) {

  cl <- match.call()
  method <- match.arg(method)
  t_start <- Sys.time()

  prior <- do.call(SignaturePPF_prior, unclass(prior))
  controls <- do.call(SignaturePPF_control, unclass(controls))
  init <- do.call(SignaturePPF_init, unclass(init))
  checkpoint <- do.call(SignaturePPF_checkpoint, unclass(checkpoint))

  if (!is.null(seed)) set.seed(seed)

  # ------------------------------------------------------------------- data
  dat <- SignaturePPF_validate(data)
  if (verbose) {
    message(sprintf("Data: %s mutations, %d samples, %d channels, %d covariates, %s bins",
                    format(dat$N, big.mark = ","), dat$J, dat$I, dat$p,
                    format(dat$nbins, big.mark = ",")))
  }

  # --------------------------------------------------------- de novo or refit
  mode <- .resolve_mode(sigs, sigs_fixed, K, betah, dat$channels, verbose)
  K <- mode$K
  sigs <- mode$sigs
  if (verbose) message("Fit: ", mode$label, ".")

  # `update_Signatures` is implied by the mode. An explicit value in `controls`
  # wins, but not silently: overriding it is how one asks for something the mode
  # does not describe, and that is worth seeing in the log.
  implied <- !identical(mode$type, "refit")
  if (is.null(controls$update_Signatures)) {
    controls$update_Signatures <- implied
  } else if (!identical(controls$update_Signatures, implied)) {
    message("controls$update_Signatures = ", controls$update_Signatures,
            " overrides the ", mode$type, " default (", implied, ").")
  }

  # ------------------------------------------------------------------- prior
  hyper <- .resolve_hyper(prior, K, dat$J)
  # Flat Dirichlet(alpha) everywhere, then the informative block written over the
  # first H columns: concentration betah_h * s_h, i.e. mean at the reference with
  # total mass betah_h. In the de novo and hard-refit modes there is no such
  # block and the whole matrix stays flat.
  SigPrior <- matrix(prior$alpha, nrow = dat$I, ncol = K,
                     dimnames = list(dat$channels, mode$names))
  if (identical(mode$type, "semisupervised")) {
    SigPrior[, seq_len(mode$H)] <- sweep(sigs, 2, mode$betah, "*")
  }

  # ----------------------------------------------------------- initial values
  start <- .resolve_init(init, mode, SigPrior, dat, K, hyper)

  args <- list(X = dat$X, SignalTrack = dat$SignalTrack, CopyTrack = dat$CopyTrack,
               channel_id = dat$channel_id, sample_id = dat$sample_id,
               SigPrior = SigPrior,
               a = hyper$a, a0 = hyper$a0, b0 = hyper$b0,
               c0 = hyper$c0, d0 = hyper$d0,
               update_R = controls$update_Signatures,
               update_Theta = controls$update_Theta,
               update_Betas = controls$update_Betas)

  use_cr <- interactive()
  results <- list(method = method, type = mode$type)

  # =========================================================================
  # MAP
  # =========================================================================
  if (method == "map") {
    out <- .run_map(start, args, controls, use_cr, verbose)
    fit <- .name_map_output(out, SigPrior, dat$samples, colnames(dat$X))
    results$MAPsolution <- out
    results <- c(results, fit)

  } else {
    # =======================================================================
    # MCMC
    # =======================================================================
    fingerprint <- .ckpt_fingerprint(
      dims = dat[c("I", "J", "p", "N", "nbins")],
      prior = hyper, controls = controls, seed = seed,
      # SigPrior itself, so a change of reference, of betah or of mode is a
      # different run rather than a chain silently continued under a new prior.
      sigs_fixed = SigPrior)

    # Look for a checkpoint BEFORE running the optimizer: a resumed run must not
    # pay for the MAP again, and its starting values are superseded anyway by the
    # state the previous block left behind.
    resumed <- NULL
    if (!is.null(checkpoint$dir) && checkpoint$resume) {
      resumed <- .ckpt_load(checkpoint$dir, fingerprint)
    }

    if (is.null(resumed) && init_mcmc_from_map) {
      if (verbose) message("Initialising the chain from the MAP.")
      map_out <- .run_map(start, args, controls, use_cr, verbose)

      if (prune_after_map) {
        thr <- if (is.null(prune_threshold)) 10 * prior$epsilon else prune_threshold
        keep <- which(c(map_out$Mu) > thr)
        if (length(keep) == 0L) {
          stop("pruning at Mu > ", format(thr), " would remove every signature.",
               call. = FALSE)
        }
        if (length(keep) < K) {
          if (verbose) {
            message(sprintf("Pruned %d of %d signatures at Mu <= %s; K is now %d.",
                            K - length(keep), K, format(thr), length(keep)))
          }
          K <- length(keep)
          SigPrior <- SigPrior[, keep, drop = FALSE]
          args$SigPrior <- SigPrior
          hyper <- .resolve_hyper(prior, K, dat$J)
          args[c("a0", "b0", "c0", "d0")] <- hyper[c("a0", "b0", "c0", "d0")]
          map_out <- .subset_map(map_out, keep)
          # In the semi-supervised mode a reference signature can be among the
          # pruned - that is the whole point of recovery - so H and betah have to
          # be reduced to the references that survived, not left describing the
          # matrix that was passed in.
          if (mode$H > 0L) {
            surviving <- intersect(colnames(SigPrior), colnames(mode$sigs))
            mode$H <- length(surviving)
            mode$sigs <- mode$sigs[, surviving, drop = FALSE]
            if (!is.null(mode$betah)) mode$betah <- mode$betah[surviving]
          }
          # The fingerprint has to follow K, or a resumed run would be checked
          # against the pre-pruning settings.
          fingerprint$prior <- hyper
          fingerprint$sigs_fixed <- SigPrior
        }
      }

      start <- list(R_start = map_out$R,
                    Theta_start = map_out$Theta,
                    Betas_start = map_out$Betas,
                    Mu_start = c(map_out$Mu),
                    Sigma2_start = c(map_out$Sigma2))
    }

    mc <- .run_mcmc(start, args, controls, checkpoint, fingerprint,
                    resumed, use_cr, verbose)

    if (!mc$complete) {
      # Only reachable if the caller stopped the run; kept so that a partial
      # result is still a usable object rather than an error.
      results$MCMCchain <- mc$chain
      results$complete <- FALSE
      results$runtime <- Sys.time() - t_start
      class(results) <- "SignaturePPF"
      return(results)
    }

    mc$chain <- .name_chain(mc$chain, SigPrior, dat, colnames(dat$X))
    fit <- .summarise_chain(mc$chain, controls, SigPrior, dat, colnames(dat$X),
                            level = ci_level)
    results$MCMCchain <- mc$chain
    results <- c(results, fit)
    results$sampler <- controls$sampler
    if (controls$sampler == "agess") results$agess <- mc$agess_controls
  }

  results$K <- K
  results$H <- mode$H
  results$betah <- mode$betah
  results$SigPrior <- SigPrior
  results$complete <- TRUE
  results$prior <- hyper
  # Drop the switched-off signatures from the REPORTED solution. `$MAPsolution`
  # and `$MCMCchain` are left whole - see [prune_signatures()].
  if (prune_solution) {
    class(results) <- "SignaturePPF"
    results <- unclass(prune_signatures(results, prune_threshold, verbose))
    K <- results$K
  }
  # Total copy-number area per sample, sum_b c_j(b). This is q_j evaluated with
  # the covariate term at its mean - the covariates are standardised, so the mean
  # bin has x = 0 and e^{beta'x} = 1 - and it is what turns an activity into a
  # rate comparable across samples. Kept because it is J numbers, where CopyTrack
  # itself is far too large to carry in a fit.
  results$copy_area <- colSums(dat$CopyTrack)
  results$controls <- controls
  results$init <- start
  results$seed <- seed
  results$dims <- dat[c("I", "J", "p", "N", "nbins")]
  results$runtime <- Sys.time() - t_start
  results$call <- cl
  if (verbose) {
    message(sprintf("Done in %s.", .fmt_dt(results$runtime)))
  }

  class(results) <- "SignaturePPF"
  results
}


# ============================================================================
# Mode, hyperparameters, initial values
# ============================================================================

# Resolves which of the three modes is being asked for, and the total number of
# signatures each implies:
#
#   denovo          sigs = NULL                     K free signatures
#   refit           sigs, sigs_fixed = TRUE         ncol(sigs), all held fixed
#   semisupervised  sigs, sigs_fixed = FALSE        ncol(sigs) informative + K free
#
# The third is the recovery-discovery setting of CompressiveNMF: the reference
# signatures are shrunk towards their catalogue values rather than pinned to
# them, and K further signatures are free to pick up whatever the reference does
# not explain. The compressive prior on mu still applies to ALL of them, so a
# reference signature the cohort does not support is pruned like any other.
.resolve_mode <- function(sigs, sigs_fixed, K, betah, channels, verbose) {

  K <- as.integer(K)

  if (is.null(sigs)) {
    if (K < 1) stop("`K` must be at least 1 for a de novo fit.", call. = FALSE)
    return(list(type = "denovo", label = paste(K, "signatures de novo"),
                K = K, H = 0L, sigs = NULL, betah = NULL,
                names = sprintf("SigN%02d", seq_len(K))))
  }

  sigs <- .check_sigs(sigs, channels)
  H <- ncol(sigs)

  if (isTRUE(sigs_fixed)) {
    return(list(type = "refit",
                label = paste("refit against", H, "fixed reference signature(s)"),
                K = H, H = H, sigs = sigs, betah = NULL,
                names = colnames(sigs)))
  }

  # Semi-supervised. K = 0 is meaningful and allowed: it is a SOFT refit, every
  # signature anchored to a reference but free to move, none free to be new.
  if (K < 0) stop("`K` cannot be negative.", call. = FALSE)
  betah <- .resolve_betah(betah, sigs, verbose)

  new_names <- if (K > 0) sprintf("SigN%02d", seq_len(K)) else character(0)
  if (any(new_names %in% colnames(sigs))) {
    new_names <- paste0("New", sprintf("%02d", seq_len(K)))
  }

  list(type = "semisupervised",
       label = paste0(H, " informative reference signature(s) + ", K,
                      " de novo (betah ",
                      if (H == 1) format(betah, digits = 3)
                      else paste0(format(min(betah), digits = 3), "-",
                                  format(max(betah), digits = 3)), ")"),
       K = H + K, H = H, sigs = sigs, betah = betah,
       names = c(colnames(sigs), new_names))
}


# Shared validation of a reference matrix.
.check_sigs <- function(sigs, channels) {
  sigs <- as.matrix(sigs)
  if (is.null(rownames(sigs))) {
    stop("`sigs` must have rownames giving the mutational channel of each row.",
         call. = FALSE)
  }
  absent <- setdiff(channels, rownames(sigs))
  if (length(absent)) {
    stop("`sigs` is missing ", length(absent), " channel(s) present in the data: ",
         paste(utils::head(absent, 5), collapse = ", "),
         if (length(absent) > 5) ", ..." else "", call. = FALSE)
  }
  # Reordered to the data's channel ordering, which is what the backends index by.
  sigs <- sigs[channels, , drop = FALSE]
  if (is.null(colnames(sigs))) {
    colnames(sigs) <- sprintf("Ref%02d", seq_len(ncol(sigs)))
  }
  if (any(sigs < 0)) stop("`sigs` contains negative entries.", call. = FALSE)

  cs <- colSums(sigs)
  if (any(cs <= 0)) stop("`sigs` has column(s) summing to zero.", call. = FALSE)
  if (max(abs(cs - 1)) > 1e-8) sigs <- sweep(sigs, 2, cs, "/")
  sigs
}


# The compressive defaults need K and J, so they cannot live in the constructor.
.resolve_hyper <- function(prior, K, J) {
  a <- prior$a
  eps <- prior$epsilon
  a0 <- if (is.null(prior$a0)) a * J + 1 else prior$a0
  b0 <- if (is.null(prior$b0)) eps * a * J else prior$b0
  c0 <- if (is.null(prior$c0)) K / 2 + 1 else prior$c0
  d0 <- if (is.null(prior$d0)) eps * K / 2 else prior$d0
  list(a = a, alpha = prior$alpha, epsilon = eps,
       a0 = a0, b0 = b0, c0 = c0, d0 = d0)
}


.resolve_init <- function(init, mode, SigPrior, dat, K, hyper) {

  if (identical(mode$type, "refit")) {
    if (!is.null(init$R_start)) {
      stop("`init$R_start` cannot be given for a refit: the signatures are ",
           "`sigs`.", call. = FALSE)
    }
    R_start <- mode$sigs
  } else if (is.null(init$R_start)) {
    # Drawn from SigPrior, so in the semi-supervised mode the informative columns
    # start near their references and the de novo ones start flat - no special
    # casing needed, the prior already encodes the distinction.
    R_start <- sample_signatures(SigPrior)
  } else {
    R_start <- as.matrix(init$R_start)
    if (ncol(R_start) != K) {
      stop("`init$R_start` has ", ncol(R_start), " columns but K = ", K, ".",
           call. = FALSE)
    }
    R_start <- R_start[dat$channels, , drop = FALSE]
  }

  Theta_start <- init$Theta_start
  if (is.null(Theta_start)) {
    Theta_start <- matrix(stats::rgamma(dat$J * K, colSums(dat$MutMatrix)),
                          nrow = K, byrow = TRUE) / K
  }
  Mu_start <- init$Mu_start
  if (is.null(Mu_start)) Mu_start <- rowMeans(Theta_start)   # E[theta_kj] = mu_k
  Sigma2_start <- init$Sigma2_start
  if (is.null(Sigma2_start)) Sigma2_start <- rep(hyper$d0 / (hyper$c0 + 1), K)
  Betas_start <- init$Betas_start
  if (is.null(Betas_start)) {
    Betas_start <- matrix(stats::rnorm(dat$p * K, 0, 1e-7), nrow = dat$p, ncol = K)
  }

  list(R_start = R_start, Theta_start = Theta_start, Betas_start = Betas_start,
       Mu_start = Mu_start, Sigma2_start = Sigma2_start)
}


# ============================================================================
# Backends
# ============================================================================

.run_map <- function(start, args, controls, use_cr, verbose) {
  if (verbose) message("MAP optimization")
  .PoissonProcess_optim_activity_CN(
    R_start = start$R_start,
    Theta_start = start$Theta_start,
    Betas_start = start$Betas_start,
    Mu_start = start$Mu_start,
    Sigma2_start = start$Sigma2_start,
    X = args$X, SignalTrack = args$SignalTrack, CopyTrack = args$CopyTrack,
    channel_id = args$channel_id, sample_id = args$sample_id,
    SigPrior = args$SigPrior,
    method = "map",
    a = args$a, a0 = args$a0, b0 = args$b0, c0 = args$c0, d0 = args$d0,
    update_R = args$update_R, update_Theta = args$update_Theta,
    update_Betas = args$update_Betas,
    n_iter_betas = controls$n_iter_betas,
    maxiter = controls$maxiter,
    tol = controls$tol,
    exact_hessian = controls$exact_hessian,
    print_every = controls$print_every,
    use_cr = use_cr,
    verbose = verbose)
}


# Runs the chain, in one call or as a checkpointed sequence of blocks. The two
# paths are the same code: without a checkpoint directory there is simply one
# block covering the whole run and nothing is written.
.run_mcmc <- function(start, args, controls, checkpoint, fingerprint,
                      resumed, use_cr, verbose) {

  total <- controls$nsamples
  thin <- controls$thin
  ckpt <- !is.null(checkpoint$dir)

  if (ckpt) {
    dir.create(checkpoint$dir, showWarnings = FALSE, recursive = TRUE)
    paths <- .ckpt_paths(checkpoint$dir)
    # A block has to be a whole number of thinning cycles, or the seam between
    # two blocks would fall inside a cycle and shift every later draw.
    block <- max(thin, ceiling(checkpoint$every / thin) * thin)
  } else {
    block <- total
  }

  done <- 0L
  n_blocks <- 0L
  agess_state <- NULL
  # Compute time accumulated over every block of this chain, including blocks run
  # in earlier processes. Passed down so the reported elapsed time and the ETA
  # describe the run rather than the current block.
  elapsed <- 0

  if (!is.null(resumed)) {
    done <- resumed$iters_done
    n_blocks <- resumed$n_blocks
    agess_state <- resumed$agess_state
    elapsed <- resumed$elapsed
    start <- resumed$start
    .rng_restore(resumed$rng)
    if (verbose) {
      message(sprintf("Resuming from checkpoint: %d of %d iterations already done.",
                      done, total))
    }
    if (done >= total) {
      chain <- .ckpt_collect(checkpoint$dir, n_blocks, total %/% thin)
      return(list(chain = chain, complete = TRUE,
                  agess_controls = resumed$agess_controls))
    }
  }

  agess_controls <- if (!is.null(resumed)) resumed$agess_controls else NULL

  while (done < total) {
    n <- min(block, total - done)
    t_block <- Sys.time()

    out <- if (controls$sampler == "agess") {
      .PoissonProcess_BayesActivityAGESS_CN(
        R_start = start$R_start, Theta_start = start$Theta_start,
        Betas_start = start$Betas_start, Mu_start = start$Mu_start,
        Sigma2_start = start$Sigma2_start,
        X = args$X, SignalTrack = args$SignalTrack, CopyTrack = args$CopyTrack,
        nsamples = n, burn_in = 0L,
        channel_id = args$channel_id, sample_id = args$sample_id,
        SigPrior = args$SigPrior,
        update_R = args$update_R, update_Theta = args$update_Theta,
        update_Betas = args$update_Betas,
        a = args$a, a0 = args$a0, b0 = args$b0, c0 = args$c0, d0 = args$d0,
        nu = controls$agess$nu,
        eps_nonadapt = controls$agess$eps_nonadapt,
        air_beta = controls$agess$air_beta,
        w_const = controls$agess$w_const,
        adapt_start = controls$agess$adapt_start,
        ridge_rel = controls$agess$ridge_rel,
        reuse_probs = controls$reuse_probs,
        logpost_every = controls$logpost_every,
        thin = thin, iter_offset = done, total_all = total,
        print_every = controls$print_every, use_cr = use_cr,
        elapsed_offset = elapsed,
        agess_state = agess_state,
        verbose = verbose)
    } else {
      .PoissonProcess_BayesActivityCN(
        R_start = start$R_start, Theta_start = start$Theta_start,
        Betas_start = start$Betas_start, Mu_start = start$Mu_start,
        Sigma2_start = start$Sigma2_start,
        X = args$X, SignalTrack = args$SignalTrack, CopyTrack = args$CopyTrack,
        nsamples = n, burn_in = 0L,
        channel_id = args$channel_id, sample_id = args$sample_id,
        SigPrior = args$SigPrior,
        update_R = args$update_R, update_Theta = args$update_Theta,
        update_Betas = args$update_Betas,
        a = args$a, a0 = args$a0, b0 = args$b0, c0 = args$c0, d0 = args$d0,
        beta_update = controls$beta_update,
        reuse_probs = controls$reuse_probs,
        logpost_every = controls$logpost_every,
        thin = thin, iter_offset = done, total_all = total,
        print_every = controls$print_every, use_cr = use_cr,
        elapsed_offset = elapsed,
        verbose = verbose)
    }

    elapsed <- elapsed + as.numeric(Sys.time() - t_block, units = "secs")
    done <- done + n
    start <- list(R_start = out$last$R, Theta_start = out$last$Theta,
                  Betas_start = out$last$Betas, Mu_start = c(out$last$Mu),
                  Sigma2_start = c(out$last$Sigma2))
    agess_state <- out$agess_state
    if (!is.null(out$agess_controls)) agess_controls <- out$agess_controls

    draws <- out[grepl("chain$", names(out))]

    if (ckpt) {
      n_blocks <- n_blocks + 1L
      # Block first, then state. The state file is what declares how many blocks
      # exist, so writing it last means a crash between the two leaves a block
      # that is simply ignored on resume - never a state pointing at a file that
      # is not there.
      #
      # `done` has already been advanced by `n`, so this block holds iterations
      # done - n + 1 ... done, which is what it is named after.
      .save_atomic(draws, paths$block(done - n + 1L, done),
                   compress = checkpoint$compress)
      .save_atomic(list(fingerprint = fingerprint,
                        iters_done = done,
                        n_blocks = n_blocks,
                        start = start,
                        agess_state = agess_state,
                        agess_controls = agess_controls,
                        rng = .rng_state(),
                        elapsed = elapsed,
                        time = Sys.time()),
                   paths$state, compress = TRUE)
    } else {
      blocks_in_memory <- draws
    }
  }

  chain <- if (ckpt) {
    .ckpt_collect(checkpoint$dir, n_blocks, total %/% thin)
  } else {
    blocks_in_memory
  }

  if (verbose) {
    message(sprintf("MCMC: %d iterations (thin = %d, %d draws stored) in %s.",
                    total, thin, total %/% thin,
                    .fmt_dt(as.difftime(elapsed, units = "secs"))))
  }
  if (ckpt && checkpoint$cleanup) unlink(checkpoint$dir, recursive = TRUE)

  list(chain = chain, complete = TRUE, agess_controls = agess_controls)
}


# ============================================================================
# Output assembly
# ============================================================================

.name_map_output <- function(out, SigPrior, samples, covariates) {
  sig_names <- colnames(SigPrior)
  Sigs <- out$R
  dimnames(Sigs) <- dimnames(SigPrior)
  Thetas <- out$Theta;   dimnames(Thetas) <- list(sig_names, samples)
  Baseline <- out$Phi;   dimnames(Baseline) <- list(sig_names, samples)
  Qmat <- out$Q;         dimnames(Qmat) <- list(sig_names, samples)
  Betas <- out$Betas;    dimnames(Betas) <- list(covariates, sig_names)
  Mu <- c(out$Mu);       names(Mu) <- sig_names
  Sigma2 <- c(out$Sigma2); names(Sigma2) <- sig_names

  list(Signatures = Sigs, Thetas = Thetas, Baseline = Baseline, Q = Qmat,
       Betas = Betas, Mu = Mu, Sigma2 = Sigma2)
}


.subset_map <- function(out, keep) {
  out$R <- out$R[, keep, drop = FALSE]
  out$Theta <- out$Theta[keep, , drop = FALSE]
  out$Phi <- out$Phi[keep, , drop = FALSE]
  out$Q <- out$Q[keep, , drop = FALSE]
  out$Betas <- out$Betas[, keep, drop = FALSE]
  out$Mu <- out$Mu[keep]
  out$Sigma2 <- out$Sigma2[keep]
  out
}

.name_chain <- function(chain, SigPrior, dat, covariates) {
  sig_names <- colnames(SigPrior)
  dimnames(chain$SIGSchain) <- list(NULL, dat$channels, sig_names)
  dimnames(chain$THETAchain) <- list(NULL, sig_names, dat$samples)
  dimnames(chain$BETASchain) <- list(NULL, covariates, sig_names)
  dimnames(chain$MUchain) <- list(NULL, sig_names)
  dimnames(chain$SIGMA2chain) <- list(NULL, sig_names)
  if (!is.null(chain$SHRINKchain)) {
    dimnames(chain$SHRINKchain) <- list(NULL, sig_names)
    dimnames(chain$ADAPTchain) <- list(NULL, sig_names)
  }
  chain
}


.summarise_chain <- function(chain, controls, SigPrior, dat, covariates,
                             level = 0.95) {
  sig_names <- colnames(SigPrior)

  n_store <- dim(chain$MUchain)[1]
  keep <- which(seq_len(n_store) * controls$thin > controls$burnin)
  if (length(keep) == 0L) {
    stop("`burnin` discards every stored draw.", call. = FALSE)
  }

  # Posterior mean and interval in one pass per block. The blocks summarised here
  # are exactly the SAMPLED ones - everything else in the fit is a deterministic
  # function of them, see the note on Q below.
  blocks <- list(Signatures = chain$SIGSchain, Thetas = chain$THETAchain,
                 Betas = chain$BETASchain, Mu = chain$MUchain,
                 Sigma2 = chain$SIGMA2chain)
  a <- (1 - level) / 2
  summarised <- lapply(blocks, function(ch) {
    ch <- if (length(dim(ch)) == 3L) ch[keep, , , drop = FALSE]
          else ch[keep, , drop = FALSE]
    m <- seq_along(dim(ch))[-1]
    list(mean = apply(ch, m, mean),
         lowCI = apply(ch, m, stats::quantile, probs = a, names = FALSE),
         highCI = apply(ch, m, stats::quantile, probs = 1 - a, names = FALSE))
  })

  Betas <- summarised$Betas$mean
  Thetas <- summarised$Thetas$mean

  # Q, and so Baseline, is a PLUG-IN at the posterior mean of beta rather than a
  # posterior mean in its own right, and carries no interval. Doing it properly
  # means evaluating exp(beta'x) over every bin once per draw - a full pass over
  # SignalTrack and CopyTrack each time - which on a genome-scale fit costs more
  # than the chain that produced the draws. The sampled blocks above are the ones
  # with intervals; see [posterior_CI()] to compute others by hand from the chain.
  Qmat <- crossprod(exp(pmin(pmax(dat$SignalTrack %*% Betas, -20), 20)),
                    dat$CopyTrack)
  dimnames(Qmat) <- list(sig_names, dat$samples)

  list(Signatures = summarised$Signatures$mean, Thetas = Thetas,
       Baseline = Thetas / Qmat, Q = Qmat,
       Betas = Betas, Mu = summarised$Mu$mean, Sigma2 = summarised$Sigma2$mean,
       lowCI = lapply(summarised, `[[`, "lowCI"),
       highCI = lapply(summarised, `[[`, "highCI"),
       ci_level = level,
       n_kept = length(keep))
}


.fmt_dt <- function(dt) {
  s <- as.numeric(dt, units = "secs")
  sprintf("%02d:%02d:%02d", as.integer(s) %/% 3600L,
          (as.integer(s) %% 3600L) %/% 60L, as.integer(s) %% 60L)
}
