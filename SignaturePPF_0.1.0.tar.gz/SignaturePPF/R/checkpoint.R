#' Checkpointing for long MCMC runs
#'
#' A full-length chain on a whole-genome dataset runs for hours, and a run that
#' is lost to a wall-clock limit, a kill signal or a crash has to be started
#' again from nothing. With a checkpoint directory the chain is executed as a
#' sequence of blocks, and after each block the stored draws and everything
#' needed to continue are written to disk. Re-issuing *the same* [SignaturePPF()]
#' call then picks the run up where it stopped, so a long fit can be left to
#' finish over several submissions of the same script.
#'
#' Resuming is exact: the sequence of draws is the one an uninterrupted run of
#' the same length would have produced. That needs three things beyond the
#' parameter values, all of which are carried across the block boundary:
#'
#' * the RNG state. Armadillo's generators are wired to R's stream here, so
#'   `.Random.seed` is the whole of it.
#' * the AGESS adaptation - live ellipses, running moments and promotion
#'   counters. Restarting a block with a fresh adaptation would still target the
#'   right posterior, but it would rewind the learned kernel.
#' * the iteration counter, so that thinning and the log-posterior grid stay aligned
#'   to the run rather than to the block.
#'
#' Posterior summaries are formed only once the run is complete; a partial run
#' returns its draws and no estimates.
#'
#' @section Files written:
#' `state.rds` holds the resumable state and a fingerprint of the data and
#' settings; `iterations_1_100.rds`, `iterations_101_200.rds`, ... hold the draws
#' of each block, named after the iterations they contain so that a directory
#' listing says how far the run got without anything being opened. Both are
#' written to a temporary name and then renamed, so a process killed mid-write
#' leaves the previous checkpoint intact rather than a truncated
#' file. Blocks are appended rather than the whole chain being rewritten: at
#' realistic sizes the chain runs to hundreds of megabytes, and re-serialising it
#' at every checkpoint would cost more than the sampling.
#'
#' @section Refusing to resume:
#' The fingerprint covers the data dimensions, the mutation count, the prior, the
#' controls and the seed. If it does not match, resuming stops with an error
#' rather than continuing a chain onto data it was not started from. Point `dir`
#' somewhere new, or delete it, to start over.
#'
#' @param dir Directory for the checkpoint files, created if needed. `NULL`
#'   (default) disables checkpointing and runs the chain in a single block.
#' @param every Block length in iterations. Rounded up to a multiple of
#'   `thin`. Smaller blocks lose less work to a crash and cost a little more I/O.
#' @param resume Continue from an existing checkpoint in `dir` if one is found.
#'   `FALSE` starts over, overwriting it.
#' @param compress Passed to [saveRDS()] for the block files. `FALSE` (default)
#'   keeps checkpointing off the critical path at the cost of disk.
#' @param cleanup Delete the checkpoint directory once the run has completed and
#'   the chain has been assembled.
#'
#' @returns A list of checkpoint settings.
#' @seealso [SignaturePPF()]
#' @export
SignaturePPF_checkpoint <- function(dir = NULL,
                                    every = 100,
                                    resume = TRUE,
                                    compress = FALSE,
                                    cleanup = FALSE) {
  if (!is.null(dir)) {
    stopifnot(is.character(dir), length(dir) == 1L)
    if (every < 1) stop("`every` must be at least 1.", call. = FALSE)
  }
  structure(list(dir = dir,
                 every = as.integer(every),
                 resume = isTRUE(resume),
                 compress = compress,
                 cleanup = isTRUE(cleanup)),
            class = "SignaturePPF_checkpoint")
}


# ---------------------------------------------------------------- RNG plumbing
# Armadillo's randu/randn/randg are routed through R's generator by
# RcppArmadillo, so `.Random.seed` is the complete state of the samplers and
# restoring it reproduces the stream exactly. `.Random.seed` lives in the global
# environment by definition of R's RNG, which is why it is read and written
# there rather than in the package namespace.
.rng_state <- function() {
  if (!exists(".Random.seed", envir = globalenv(), inherits = FALSE)) {
    stats::runif(1)   # forces the generator to initialise
  }
  get(".Random.seed", envir = globalenv(), inherits = FALSE)
}

.rng_restore <- function(state) {
  assign(".Random.seed", state, envir = globalenv())
  invisible(NULL)
}


# ------------------------------------------------------------- atomic RDS write
# Write to a unique temporary name in the same directory, then rename. rename is
# atomic within a filesystem, so a kill at any point leaves either the old file
# or the new one, never a half-written one.
.save_atomic <- function(object, path, compress = TRUE) {
  tmp <- paste0(path, ".tmp-", Sys.getpid())
  on.exit(unlink(tmp), add = TRUE)
  saveRDS(object, tmp, compress = compress)
  if (!file.rename(tmp, path)) {
    stop("could not write checkpoint file ", path, call. = FALSE)
  }
  invisible(path)
}


# ------------------------------------------------------------------ fingerprint
# Identifies the run a checkpoint belongs to. A small list compared with
# identical() rather than a hash: it needs no dependency, and when it does not
# match the mismatching field can be named in the error.
.ckpt_fingerprint <- function(dims, prior, controls, seed, sigs_fixed) {
  list(dims = dims,
       prior = prior,
       # Only the fields that change the chain. print_every does not.
       controls = controls[c("nsamples", "burnin", "thin", "sampler", "agess",
                             "beta_update", "reuse_probs", "logpost_every",
                             "update_Signatures", "update_Theta", "update_Betas")],
       seed = seed,
       sigs_fixed = sigs_fixed)
}

.ckpt_paths <- function(dir) {
  list(state = file.path(dir, "state.rds"),
       # Named by the iterations they hold - iterations_1_100.rds,
       # iterations_101_200.rds - so a directory listing says what is in it
       # without anything having to be opened.
       block = function(from, to) {
         file.path(dir, sprintf("iterations_%d_%d.rds", from, to))
       })
}

# The block files, in iteration order. A range-named file cannot be reconstructed
# from a counter the way a zero-padded index could, so the blocks are discovered
# and sorted by their FIRST iteration - numerically, because a lexical sort would
# put iterations_1000_1100 before iterations_200_300.
.ckpt_blocks <- function(dir) {
  files <- list.files(dir, pattern = "^iterations_[0-9]+_[0-9]+\\.rds$")
  if (!length(files)) return(character(0))
  from <- as.integer(sub("^iterations_([0-9]+)_.*$", "\\1", files))
  file.path(dir, files[order(from)])
}

# Loads a checkpoint if one is usable, else NULL. Refuses loudly on a fingerprint
# mismatch: silently continuing a chain onto different data or different settings
# is the failure mode this whole mechanism exists to prevent.
.ckpt_load <- function(dir, fingerprint) {
  paths <- .ckpt_paths(dir)
  if (!file.exists(paths$state)) return(NULL)

  state <- readRDS(paths$state)
  if (!identical(state$fingerprint, fingerprint)) {
    differing <- names(which(!vapply(
      names(fingerprint),
      function(nm) identical(state$fingerprint[[nm]], fingerprint[[nm]]),
      logical(1))))
    stop("the checkpoint in '", dir, "' was written by a different run ",
         "(mismatch in: ", paste(differing, collapse = ", "), ").\n",
         "  Point `dir` at a new directory, delete this one, or pass ",
         "`resume = FALSE` to overwrite it.", call. = FALSE)
  }

  # Fewer blocks on disk than the state declares means the state was written but
  # a block was not, which the write order makes impossible - so treat it as
  # corruption. MORE is fine and expected: a crash between the two writes leaves
  # an orphan block that the state does not count and resume ignores.
  found <- length(.ckpt_blocks(dir))
  if (found < state$n_blocks) {
    stop("the checkpoint in '", dir, "' is incomplete: it declares ",
         state$n_blocks, " blocks but ", found, " are on disk.", call. = FALSE)
  }
  state
}


# Concatenates the per-block draws into the arrays the caller expects. The total
# number of stored draws is known in advance, so the result is preallocated and
# filled rather than grown; abind() over a hundred blocks would copy the whole
# chain a hundred times.
.ckpt_collect <- function(dir, n_blocks, n_store_total) {
  # Only the blocks the state declares: an orphan left by a crash between the
  # block write and the state write is not part of the chain the RNG resumes.
  blocks <- utils::head(.ckpt_blocks(dir), n_blocks)
  first <- readRDS(blocks[1])

  out <- lapply(first, function(x) {
    d <- dim(x)
    if (is.null(d)) {
      rep(NA_real_, n_store_total)
    } else if (length(d) == 2L) {
      array(NA_real_, dim = c(n_store_total, d[2]), dimnames = dimnames(x))
    } else {
      array(NA_real_, dim = c(n_store_total, d[2], d[3]), dimnames = dimnames(x))
    }
  })

  pos <- 0L
  for (i in seq_along(blocks)) {
    ch <- if (i == 1L) first else readRDS(blocks[i])
    n <- if (is.null(dim(ch[[1]]))) length(ch[[1]]) else dim(ch[[1]])[1]
    idx <- pos + seq_len(n)
    for (nm in names(out)) {
      x <- ch[[nm]]
      if (is.null(dim(x))) {
        out[[nm]][idx] <- x
      } else if (length(dim(x)) == 2L) {
        out[[nm]][idx, ] <- x
      } else {
        out[[nm]][idx, , ] <- x
      }
    }
    pos <- pos + n
  }

  if (pos != n_store_total) {
    stop("checkpoint holds ", pos, " draws but ", n_store_total,
         " were expected.", call. = FALSE)
  }
  out
}
