#' Most probable signature for every mutation
#'
#' Each mutation is attributed to the signature that most probably generated it,
#' which under the model means the largest
#' \eqn{r_{ik}\,\phi_{kj}\,e^{\beta_k'x(t)}} across \eqn{k}. That is a hard
#' assignment of a quantity the model treats probabilistically, so it is a
#' summary for plotting and tabulation rather than an estimate in its own right.
#'
#' @param fit A fitted model.
#' @param data The cohort it was fitted on, or a bare `GRanges` of mutations.
#'   The second form is for comparing SEVERAL fits on ONE fixed set of
#'   mutations: `mcols` need only carry the covariates the fit uses, so a set of
#'   mutations can be pushed through a whole sequence of nested models.
#' @returns A character vector, one signature name per mutation.
#' @seealso [df_assign()], [plot_Mu()]
#' @export
assign_mutations <- function(fit, data) {
  gr <- if (is.list(data) && !is.null(data$gr_Mutations)) data$gr_Mutations else data
  X <- as.matrix(GenomicRanges::mcols(gr)[, rownames(fit$Betas), drop = FALSE])

  # The BASELINE phi_kj, not the total activity: the comparison is between
  # per-unit-exposure rates at one genomic position, and q_j(beta_k) varies by
  # signature, so using Thetas here would tilt every assignment by that factor.
  Phi <- fit$Baseline

  # as.character() is not decoration: `channel` and `sample` are factors, and
  # indexing a matrix with a factor uses its integer CODES, not its labels. That
  # happens to be right when the fit was built on this exact object and wrong,
  # silently, as soon as the signatures have been pruned or reordered.
  bigProd <- fit$Signatures[as.character(gr$channel), , drop = FALSE] *
    t(Phi[, as.character(gr$sample), drop = FALSE]) *
    exp(pmin(pmax(X %*% fit$Betas, -20), 20))

  # max.col, not apply(., 1, which.max): identical result including ties, but it
  # does not loop in R over several hundred thousand mutations.
  colnames(fit$Signatures)[max.col(bigProd, ties.method = "first")]
}


#' Mutations attributed to each signature, alongside its relevance weight
#'
#' @param fit A fitted model.
#' @param data The cohort it was fitted on.
#' @returns A data frame with one row per signature: `best_sig`, the number of
#'   mutations `m` assigned to it, and its `mu`. Signatures that win no mutation
#'   are kept with `m = 0` - they are exactly the ones worth seeing.
#' @seealso [assign_mutations()], [plot_Mu()]
#' @export
df_assign <- function(fit, data) {
  levs <- colnames(fit$Signatures)
  counts <- table(factor(assign_mutations(fit, data), levels = sort(levs)))
  out <- data.frame(best_sig = names(counts), m = as.integer(counts),
                    row.names = NULL, stringsAsFactors = FALSE)
  merge(out,
        data.frame(best_sig = names(fit$Mu), mu = as.numeric(fit$Mu),
                   stringsAsFactors = FALSE),
        by = "best_sig", all.x = TRUE)
}
