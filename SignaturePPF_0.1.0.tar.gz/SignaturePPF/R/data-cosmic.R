#' COSMIC v3.4 SBS signatures (GRCh37)
#'
#' The COSMIC v3.4 catalogue of single base substitution signatures over the 96
#' trinucleotide channels, on GRCh37. Intended as the `sigs` argument of
#' [SignaturePPF()] for a refit - usually after subsetting to the signatures
#' expected in the tissue at hand, since refitting against all 86 at once is
#' badly under-determined.
#'
#' @format A numeric matrix with 96 rows (channels, named `A[C>A]A` ... `T[T>G]T`)
#'   and 86 columns (signatures, named `SBS1`, `SBS2`, ...). Columns sum to one.
#' @source COSMIC Mutational Signatures v3.4,
#'   <https://cancer.sanger.ac.uk/signatures/>
#' @examples
#' dim(COSMIC_v3.4_SBS96_GRCh37)
#' colnames(COSMIC_v3.4_SBS96_GRCh37)[1:6]
"COSMIC_v3.4_SBS96_GRCh37"
