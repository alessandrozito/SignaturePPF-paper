#' Validate and normalise the input data
#'
#' Checks the alignment contract that the model depends on and returns the data
#' in the exact form the backends expect. [SignaturePPF()] calls this on entry,
#' so it rarely needs to be called directly; it is exported because running it on
#' a hand-assembled dataset is much quicker than discovering the problem three
#' hours into a chain.
#'
#' The contract is:
#'
#' * `SignalTrack` and `CopyTrack` describe the **same genomic bins in the same
#'   order**. Only the row counts can be checked mechanically, so the two must be
#'   built from one binning - see the preprocessing pipeline.
#' * the numeric covariate columns of `gr_Mutations` are the covariates evaluated
#'   at each mutation, and are the **same covariates in the same order** as the
#'   columns of `SignalTrack`. Mismatched order here silently pairs each
#'   coefficient with the wrong track.
#' * `colnames(CopyTrack)` covers every sample appearing in `gr_Mutations`.
#'   `CopyTrack` is reordered to the sample order of the mutation matrix.
#'
#' Columns named `sample` and `channel` are never treated as covariates, even
#' when they are numeric.
#'
#' @param data A list (or object) with elements `gr_Mutations`, `SignalTrack` and
#'   `CopyTrack`. `gr_mutations` and `mutations` are accepted as aliases for the
#'   first.
#'
#' @returns A list with the validated `gr_Mutations`, `SignalTrack`, `CopyTrack`,
#'   the covariate matrix `X` at the mutations, the aggregate `MutMatrix`, the
#'   0-based `channel_id` and `sample_id`, the level sets, and the dimensions
#'   `I`, `J`, `p`, `N`, `nbins`.
#' @export
SignaturePPF_validate <- function(data) {

  if (!is.list(data)) {
    stop("`data` must be a list with elements `gr_Mutations`, `SignalTrack` ",
         "and `CopyTrack`.", call. = FALSE)
  }

  pick <- function(nms) {
    hit <- nms[nms %in% names(data)]
    if (length(hit) == 0L) return(NULL)
    data[[hit[1]]]
  }
  gr <- pick(c("gr_Mutations", "gr_mutations", "mutations"))
  SignalTrack <- pick("SignalTrack")
  CopyTrack <- pick("CopyTrack")

  missing <- c(gr_Mutations = is.null(gr), SignalTrack = is.null(SignalTrack),
               CopyTrack = is.null(CopyTrack))
  if (any(missing)) {
    stop("`data` is missing: ", paste(names(missing)[missing], collapse = ", "),
         call. = FALSE)
  }

  SignalTrack <- as.matrix(SignalTrack)
  CopyTrack <- as.matrix(CopyTrack)

  # --------------------------------------------------------------- mutations
  mc <- as.data.frame(GenomicRanges::mcols(gr))
  for (nm in c("sample", "channel")) {
    if (!nm %in% names(mc)) {
      stop("mcols(gr_Mutations) must contain a `", nm, "` column.", call. = FALSE)
    }
  }

  # `sample` and `channel` are excluded by NAME, not by type: a cohort with
  # numeric sample identifiers would otherwise be silently fitted with the
  # patient id as a genomic covariate.
  is_cov <- vapply(mc, is.numeric, logical(1)) & !names(mc) %in% c("sample", "channel")
  X <- as.matrix(mc[, is_cov, drop = FALSE])

  channel <- as.factor(mc$channel)
  sample <- as.factor(mc$sample)
  if (anyNA(channel)) {
    stop(sum(is.na(channel)), " mutations have a missing `channel`. These are ",
         "usually mutations whose trinucleotide context could not be resolved; ",
         "drop them before fitting.", call. = FALSE)
  }
  if (anyNA(sample)) stop("some mutations have a missing `sample`.", call. = FALSE)

  MutMatrix <- .total_mutations(channel, sample)

  # --------------------------------------------------------------- covariates
  if (ncol(X) != ncol(SignalTrack)) {
    stop("SignalTrack has ", ncol(SignalTrack), " covariate(s) but ",
         "gr_Mutations carries ", ncol(X), " numeric covariate column(s) ",
         "(excluding `sample` and `channel`).", call. = FALSE)
  }
  if (ncol(X) == 0L) {
    stop("no covariates found: mcols(gr_Mutations) has no numeric columns ",
         "besides `sample` and `channel`.", call. = FALSE)
  }
  if (!identical(colnames(SignalTrack), colnames(X))) {
    stop("colnames(SignalTrack) and the covariate columns of gr_Mutations must ",
         "match in name AND in order.\n",
         "  SignalTrack: ", paste(colnames(SignalTrack), collapse = ", "), "\n",
         "  gr_Mutations: ", paste(colnames(X), collapse = ", "), call. = FALSE)
  }
  if (nrow(SignalTrack) != nrow(CopyTrack)) {
    stop("SignalTrack has ", nrow(SignalTrack), " bins but CopyTrack has ",
         nrow(CopyTrack), ". They must describe the same bins in the same order.",
         call. = FALSE)
  }
  if (!all(is.finite(SignalTrack))) stop("SignalTrack contains non-finite values.", call. = FALSE)
  if (!all(is.finite(X))) stop("the covariates at the mutations contain non-finite values.", call. = FALSE)
  if (!all(is.finite(CopyTrack))) stop("CopyTrack contains non-finite values.", call. = FALSE)
  if (any(CopyTrack < 0)) stop("CopyTrack contains negative values.", call. = FALSE)

  # A direction along which SignalTrack barely varies carries almost no
  # likelihood information, so beta is pinned by the prior alone and its
  # posterior is not something to interpret. A constant column is an intercept,
  # which under the activity prior is not identified at all: the level of each
  # signature is carried by theta.
  sds <- apply(SignalTrack, 2, stats::sd)
  const <- sds < .Machine$double.eps^0.5
  if (any(const)) {
    stop("SignalTrack column(s) ", paste(colnames(SignalTrack)[const], collapse = ", "),
         " are constant. Under the activity prior the overall level is carried ",
         "by the activities, so an intercept is not identified; drop these ",
         "columns.", call. = FALSE)
  }

  # --------------------------------------------------------------- copy number
  if (is.null(colnames(CopyTrack))) {
    stop("CopyTrack must have colnames giving the sample each column belongs to.",
         call. = FALSE)
  }
  absent <- setdiff(colnames(MutMatrix), colnames(CopyTrack))
  if (length(absent)) {
    stop(length(absent), " sample(s) in gr_Mutations have no CopyTrack column: ",
         paste(utils::head(absent, 5), collapse = ", "),
         if (length(absent) > 5) ", ..." else "", call. = FALSE)
  }
  # Reordered, not assumed: the columns of CopyTrack must line up with the
  # columns of the mutation matrix, and nothing guarantees they were built in the
  # same order.
  CopyTrack <- CopyTrack[, colnames(MutMatrix), drop = FALSE]

  dead <- colSums(CopyTrack) == 0
  if (any(dead)) {
    stop("sample(s) ", paste(colnames(CopyTrack)[dead], collapse = ", "),
         " have zero copy number over the whole genome.", call. = FALSE)
  }

  list(gr_Mutations = gr,
       X = X,
       SignalTrack = SignalTrack,
       CopyTrack = CopyTrack,
       MutMatrix = MutMatrix,
       channel_id = as.integer(channel) - 1L,
       sample_id = as.integer(sample) - 1L,
       channels = levels(channel),
       samples = colnames(MutMatrix),
       I = nlevels(channel),
       J = ncol(MutMatrix),
       p = ncol(SignalTrack),
       N = length(gr),
       nbins = nrow(SignalTrack))
}


# Channel x sample count matrix. Kept internal to the validator's contract:
# the column order it produces defines the sample order everywhere downstream.
.total_mutations <- function(channel, sample) {
  tab <- table(channel, sample)
  matrix(tab, nrow = nrow(tab), dimnames = dimnames(tab))
}


#' Aggregate mutation counts
#'
#' The channel-by-sample count matrix, i.e. the input a plain NMF would take.
#'
#' @param gr_Mutations A `GRanges` of mutations with `sample` and `channel` in
#'   its metadata columns.
#' @returns An integer matrix with channels in rows and samples in columns.
#' @export
getTotalMutations <- function(gr_Mutations) {
  mc <- as.data.frame(GenomicRanges::mcols(gr_Mutations))
  .total_mutations(as.factor(mc$channel), as.factor(mc$sample))
}


#' Draw a signature matrix from a Dirichlet prior
#'
#' @param Alpha An `I x K` matrix of Dirichlet concentrations.
#' @returns An `I x K` matrix whose columns sum to one.
#' @export
sample_signatures <- function(Alpha) {
  R <- matrix(stats::rgamma(length(Alpha), shape = Alpha), nrow = nrow(Alpha))
  R <- sweep(R, 2, colSums(R), "/")
  dimnames(R) <- dimnames(Alpha)
  R
}
