#' @keywords internal
"_PACKAGE"

#' @useDynLib SignaturePPF, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom rlang .data
NULL


#' @export
print.SignaturePPF <- function(x, ...) {
  cat("Poisson process factorization of mutational signatures\n")
  cat("  fit    : ", x$type, ", ", toupper(x$method), sep = "")
  if (identical(x$method, "mcmc")) cat(" (", x$sampler, ")", sep = "")
  cat("\n")

  if (!isTRUE(x$complete)) {
    cat("  status : INCOMPLETE - draws only, no posterior summaries\n")
    return(invisible(x))
  }

  d <- x$dims
  cat(sprintf("  data   : %s mutations, %d samples, %d channels, %d covariates, %s bins\n",
              format(d$N, big.mark = ","), d$J, d$I, d$p,
              format(d$nbins, big.mark = ",")))
  cat("  K      : ", x$K, sep = "")
  if (length(x$pruned)) {
    cat(" of ", x$K_fitted, " fitted (", length(x$pruned),
        " pruned at Mu <= ", format(x$prune_threshold), ")", sep = "")
  } else {
    active <- sum(x$Mu > 10 * x$prior$epsilon)
    if (active < x$K) {
      cat(" (", active, " with Mu above the pruning scale)", sep = "")
    }
  }
  cat("\n")

  if (identical(x$method, "mcmc")) {
    cat(sprintf("  chain  : %d iterations, thin %d, burn-in %d, %d draws summarised\n",
                x$controls$nsamples, x$controls$thin, x$controls$burnin,
                x$n_kept))
  } else {
    cat(sprintf("  optim  : %d iterations, relative change %.2e\n",
                x$MAPsolution$iter, x$MAPsolution$maxdiff))
  }
  cat("  time   : ", .fmt_dt(x$runtime), "\n", sep = "")
  invisible(x)
}


#' Summarise a fitted model
#'
#' Per-signature summary: the relevance weight \eqn{\mu_k}, the mean and total
#' activity across samples, and how many samples carry the signature.
#'
#' @param object A `SignaturePPF` fit.
#' @param ... Ignored.
#' @returns A data frame with one row per signature, invisibly returned after
#'   printing.
#' @export
summary.SignaturePPF <- function(object, ...) {
  if (!isTRUE(object$complete)) {
    stop("this fit is incomplete; no posterior summaries are available.",
         call. = FALSE)
  }
  print(object)

  # "Present" is on the activity scale: theta_kj is an expected count, so a
  # threshold of one mutation is a statement about the data, not a convention.
  df <- data.frame(
    signature = colnames(object$Signatures),
    Mu = as.numeric(object$Mu),
    mean_activity = rowMeans(object$Thetas),
    total_activity = rowSums(object$Thetas),
    n_samples = rowSums(object$Thetas > 1),
    row.names = NULL,
    stringsAsFactors = FALSE)
  if (!is.null(object$lowCI$Mu)) {
    df$Mu_low <- as.numeric(object$lowCI$Mu)
    df$Mu_high <- as.numeric(object$highCI$Mu)
  }
  df <- df[order(-df$total_activity), ]

  cat("\n")
  print(format(df, digits = 3), row.names = FALSE)
  invisible(df)
}
