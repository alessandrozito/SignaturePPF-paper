# Plotting. ggplot2 is a Suggests rather than an Imports: the model layer is
# deliberately light so that installing it on a cluster pulls almost nothing, and
# a fit does not need a graphics stack to run.

.need_ggplot <- function() {
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("this function needs ggplot2. Install it with install.packages(\"ggplot2\").",
         call. = FALSE)
  }
}

# Which stored draws survive burn-in. Stored draw s is iteration s * thin, so the
# burn-in - which the user gives in iterations - has to be translated first.
.kept_draws <- function(fit) {
  n <- dim(fit$MCMCchain$MUchain)[1]
  which(seq_len(n) * fit$controls$thin > fit$controls$burnin)
}

# Accepts either a fit or the matrix itself, so that both plot_Betas(fit) and
# plot_Betas(fit$Betas) work.
.slot_or_matrix <- function(x, slot) {
  if (inherits(x, "SignaturePPF")) x[[slot]] else as.matrix(x)
}

# Credible bounds for one block. The fit already carries them at its own
# `ci_level`, so re-scanning the chain is only needed for a different level -
# which matters: SIGSchain alone is draws x 96 x K, and a fit's chain is often
# the largest object in the session.
.bounds <- function(fit, what, level) {
  if (!identical(fit$method, "mcmc")) return(NULL)
  if (!is.null(fit$lowCI[[what]]) && isTRUE(all.equal(fit$ci_level, level))) {
    return(list(lowCI = fit$lowCI[[what]], highCI = fit$highCI[[what]]))
  }
  q <- posterior_CI(fit, what, level)
  list(lowCI = q$lowCI, highCI = q$highCI)
}

# Wide matrix -> long data frame, without pulling in tidyr.
.melt <- function(m, row_name, col_name, value_name) {
  rn <- rownames(m)
  cn <- colnames(m)
  if (is.null(rn)) rn <- as.character(seq_len(nrow(m)))
  if (is.null(cn)) cn <- as.character(seq_len(ncol(m)))
  out <- data.frame(rep(rn, times = ncol(m)),
                    rep(cn, each = nrow(m)),
                    as.vector(m),
                    stringsAsFactors = FALSE)
  names(out) <- c(row_name, col_name, value_name)
  out[[row_name]] <- factor(out[[row_name]], levels = rn)
  out[[col_name]] <- factor(out[[col_name]], levels = cn)
  out
}


#' Posterior means and credible intervals
#'
#' Computed from the chain on demand, which is what makes a level other than the
#' fit's own `ci_level` available. A fit already carries `lowCI` and `highCI` at
#' `ci_level`; reach for those unless another level is wanted.
#'
#' @param x A `SignaturePPF` fit, or a chain array with draws in the first
#'   dimension.
#' @param what Which block to summarise when `x` is a fit: `"Betas"`,
#'   `"Signatures"`, `"Thetas"`, `"Mu"` or `"Sigma2"`.
#' @param level Credible level.
#' @param all Summarise every signature the run was given, rather than only the
#'   ones the fit reports. The chain is never pruned, so the switched-off
#'   signatures are still in there; the default matches the solution so that the
#'   bounds line up with `fit$Betas` and friends, and `TRUE` is for inspecting
#'   what the compressive prior actually did to a dropped signature.
#'
#' @returns A list with `mean`, `lowCI` and `highCI`, each of the shape of one
#'   draw. Burn-in is discarded using the fit's own `burnin` and `thin`.
#' @seealso [prune_signatures()], [add_credible_intervals()]
#' @export
posterior_CI <- function(x, what = "Betas", level = 0.95, all = FALSE) {
  if (inherits(x, "SignaturePPF")) {
    if (!identical(x$method, "mcmc")) {
      stop("credible intervals need method = \"mcmc\"; this is a MAP fit.",
           call. = FALSE)
    }
    slot <- c(Betas = "BETASchain", Signatures = "SIGSchain",
              Thetas = "THETAchain", Mu = "MUchain", Sigma2 = "SIGMA2chain")
    what <- match.arg(what, names(slot))
    chain <- x$MCMCchain[[slot[[what]]]]

    # Which margin carries the signature: the last one, except for Thetas, whose
    # columns are the samples.
    sig_margin <- if (identical(what, "Thetas")) 2L else length(dim(chain))
    sigs <- if (all) dimnames(chain)[[sig_margin]] else colnames(x$Signatures)

    idx <- rep(list(quote(expr = )), length(dim(chain)))
    idx[[1]] <- .kept_draws(x)
    idx[[sig_margin]] <- sigs
    chain <- do.call(`[`, c(list(chain), idx, list(drop = FALSE)))
  } else {
    chain <- x
  }

  a <- (1 - level) / 2
  margins <- seq_along(dim(chain))[-1]
  list(mean = apply(chain, margins, mean),
       lowCI = apply(chain, margins, stats::quantile, probs = a, names = FALSE),
       highCI = apply(chain, margins, stats::quantile, probs = 1 - a, names = FALSE))
}


#' Plot the covariate coefficients
#'
#' A signature-by-covariate heatmap of \eqn{\beta}. Two things make it readable
#' on real fits:
#'
#' * **the colour scale is capped.** A single large coefficient otherwise
#'   stretches the scale until every other cell is indistinguishable from white.
#'   `cap` bounds the FILL only - the printed number is always the true value, so
#'   nothing is hidden, and cells beyond the cap simply saturate.
#' * **coefficients whose credible interval covers zero are greyed out** and
#'   left unlabelled, so the plot shows what the data resolved rather than the
#'   sign of a posterior that is indifferent.
#'
#' @param x A `SignaturePPF` fit, or a `p x K` matrix of coefficients.
#' @param lowCI,highCI Credible interval matrices. Ignored when `x` is an MCMC
#'   fit, which supplies its own unless `ci = FALSE`.
#' @param ci For an MCMC fit, whether to compute and use credible intervals.
#' @param level Credible level used when `ci` is `TRUE`.
#' @param cap Absolute value at which the colour scale saturates. `NULL` scales
#'   to the largest absolute coefficient, which is the behaviour to avoid on
#'   fits with one dominant effect.
#' @param digits Digits for the printed coefficient.
#'
#' @returns A ggplot object.
#' @export
plot_Betas <- function(x, lowCI = NULL, highCI = NULL, ci = TRUE, level = 0.95,
                       cap = 1, digits = 2) {
  .need_ggplot()

  Betas <- .slot_or_matrix(x, "Betas")
  if (inherits(x, "SignaturePPF") && isTRUE(ci)) {
    q <- .bounds(x, "Betas", level)
    lowCI <- q$lowCI
    highCI <- q$highCI
  }

  df <- .melt(Betas, "Covariate", "Signature", "Beta")
  if (!is.null(lowCI) && !is.null(highCI)) {
    df$lowCI <- as.vector(as.matrix(lowCI))
    df$highCI <- as.vector(as.matrix(highCI))
    df$Beta[df$lowCI < 0 & df$highCI > 0] <- NA_real_
  }

  lim <- if (is.null(cap)) max(abs(df$Beta), na.rm = TRUE) else abs(cap)
  # Fill is clamped, the label is not: the cap is a display device, not a
  # transformation of the estimate.
  df$fill <- pmax(pmin(df$Beta, lim), -lim)

  ggplot2::ggplot(df, ggplot2::aes(x = .data$Covariate, y = .data$Signature,
                                   fill = .data$fill)) +
    ggplot2::geom_tile(colour = "black", width = 1, height = 1, na.rm = TRUE) +
    # No colour guide: every cell carries its own number, so a scale bar
    # restates what is already printed and costs a fifth of the panel width.
    ggplot2::scale_fill_gradientn(
      colours = c("#2166AC", "white", "#B2182B"),
      limits = c(-lim, lim), na.value = "gray90", guide = "none") +
    ggplot2::geom_text(
      ggplot2::aes(label = ifelse(is.na(.data$Beta), "", round(.data$Beta, digits))),
      size = 3, na.rm = TRUE) +
    ggplot2::scale_y_discrete(limits = rev(levels(df$Signature))) +
    ggplot2::scale_x_discrete(position = "top") +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 0, vjust = 0,
                                          size = 10, colour = "black"),
      axis.title = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank())
}


#' Plot mutational signatures
#'
#' The usual 96-channel barplot, one row per signature.
#'
#' @param x A `SignaturePPF` fit, or an `I x K` matrix of signatures.
#' @param lowCI,highCI Credible interval matrices, drawn as vertical ranges.
#' @param ci For an MCMC fit, whether to compute and draw credible intervals.
#' @param level Credible level used when `ci` is `TRUE`.
#' @param palette Six colours for the substitution types, in COSMIC order.
#'
#' @returns A ggplot object.
#' @export
plot_Signatures <- function(x, lowCI = NULL, highCI = NULL, ci = TRUE,
                            level = 0.95,
                            palette = c("#40BDEE", "#020202", "#E52925",
                                        "#CCC9CA", "#A3CF62", "#ECC5C5")) {
  .need_ggplot()

  sigs <- .slot_or_matrix(x, "Signatures")
  if (inherits(x, "SignaturePPF") && isTRUE(ci)) {
    q <- .bounds(x, "Signatures", level)
    lowCI <- q$lowCI
    highCI <- q$highCI
  }

  df <- .melt(sigs, "Channel", "Signature", "Prob")
  ch <- as.character(df$Channel)
  # Channels are "A[C>A]A": characters 1, 3 and 7 are the trinucleotide and
  # 3 to 5 the substitution.
  df$Triplet <- paste0(substr(ch, 1, 1), substr(ch, 3, 3), substr(ch, 7, 7))
  df$Mutation <- factor(substr(ch, 3, 5))

  p <- ggplot2::ggplot(df, ggplot2::aes(x = .data$Triplet, y = .data$Prob,
                                        fill = .data$Mutation)) +
    ggplot2::geom_col(width = 0.7) +
    ggplot2::facet_grid(Signature ~ Mutation, scales = "free", switch = "y") +
    ggplot2::scale_fill_manual(values = palette) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      legend.position = "none",
      axis.title = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(angle = 90, colour = "gray35",
                                          vjust = 0.5, size = 6.5,
                                          margin = ggplot2::margin(t = -4)),
      panel.grid = ggplot2::element_blank(),
      panel.spacing.x = ggplot2::unit(0, "lines"),
      panel.spacing.y = ggplot2::unit(0, "lines"),
      strip.text.y.left = ggplot2::element_text(angle = 0, hjust = 1))

  if (!is.null(lowCI) && !is.null(highCI)) {
    df$lowCI <- as.vector(as.matrix(lowCI))
    df$highCI <- as.vector(as.matrix(highCI))
    p <- p + ggplot2::geom_linerange(
      data = df,
      ggplot2::aes(x = .data$Triplet, ymin = .data$lowCI, ymax = .data$highCI),
      inherit.aes = FALSE, colour = "grey65")
  }
  p
}


# Renumber cluster labels so 1 is the most populous, 2 the next, and so on.
# PAM numbers its clusters by where the medoids happened to land, which carries
# no information - so without this the panel order and the legend are arbitrary,
# and change if the covariate set or the seed changes. Ties keep their existing
# relative order: `order` is stable here, so the result is deterministic.
#
# Returns the permutation as an attribute, because anything else indexed BY
# cluster - the medoids, above all - has to be permuted the same way.
.clusters_by_size <- function(clust) {
  tab <- table(clust)
  ord <- order(-as.integer(tab))
  map <- stats::setNames(seq_along(ord), names(tab)[ord])
  out <- unname(map[as.character(clust)])
  names(out) <- names(clust)
  structure(out, permutation = ord)
}


#' Cluster samples by signature composition
#'
#' Clusters are numbered by SIZE: cluster 1 is the most populous, and the panels
#' of [plot_Theta()] therefore run largest to smallest. PAM's own numbering
#' follows wherever the medoids landed and means nothing, so it would put the
#' panels in an order that changes with the seed.
#'
#' Partitioning around medoids ([cluster::pam()]) on the samples' NORMALISED
#' activities, i.e. the share of each sample's burden carried by each signature.
#' Normalising first is what makes the clusters about aetiology rather than about
#' how heavily mutated a sample happens to be.
#'
#' PAM rather than hierarchical clustering, for two reasons that matter on
#' cohorts of this shape. It optimises the partition it reports, where `cutree`
#' returns a slice through a tree built by a greedy merge that never revisits an
#' early mistake - and every candidate `k` here is a fresh optimisation rather
#' than a different cut of one fixed tree. And each cluster is summarised by an
#' actual sample, its medoid, so a cluster can be described by pointing at a
#' tumour rather than at an average that may resemble nothing in the cohort.
#'
#' @param Theta A `K x J` activity matrix.
#' @param k Number of clusters. `NULL` (default) chooses it by maximising the
#'   average silhouette width over `k_range`.
#' @param k_range Candidate numbers of clusters, used when `k` is `NULL`.
#'
#' @returns An integer vector of cluster labels, one per sample, carrying the
#'   chosen `k`, the silhouette profile and the medoid sample of each cluster in
#'   its attributes.
#' @export
cluster_samples <- function(Theta, k = NULL, k_range = 2:10) {
  prop <- t(sweep(Theta, 2, colSums(Theta), "/"))
  J <- nrow(prop)

  if (!is.null(k)) {
    k <- as.integer(k)
    if (k < 1L || k >= J) {
      stop("`k` must be at least 1 and smaller than the number of samples (",
           J, ").", call. = FALSE)
    }
    if (k == 1L) {
      return(structure(rep(1L, J), names = rownames(prop), k = 1L,
                       silhouette = NULL, medoids = rownames(prop)[1]))
    }
    p <- cluster::pam(prop, k = k, stand = FALSE)
    lab <- .clusters_by_size(p$clustering)
    return(structure(as.integer(lab), names = names(lab), k = k,
                     silhouette = p$silinfo$avg.width,
                     medoids = rownames(prop)[p$id.med][attr(lab, "permutation")]))
  }

  k_range <- k_range[k_range >= 2 & k_range < J]
  if (length(k_range) == 0L) {
    return(structure(rep(1L, J), names = rownames(prop), k = 1L,
                     silhouette = NULL, medoids = rownames(prop)[1]))
  }

  # One PAM per candidate k. Its own average silhouette width is the selection
  # criterion, so nothing has to be recomputed from a distance matrix afterwards.
  fits <- lapply(k_range, function(kk) cluster::pam(prop, k = kk, stand = FALSE))
  widths <- vapply(fits, function(p) p$silinfo$avg.width, numeric(1))
  best <- which.max(widths)

  lab <- .clusters_by_size(fits[[best]]$clustering)
  structure(as.integer(lab), names = names(lab),
            k = k_range[best],
            silhouette = stats::setNames(widths, k_range),
            medoids = rownames(prop)[fits[[best]]$id.med][attr(lab, "permutation")])
}


#' Plot the activities
#'
#' Stacked bars of the total activities \eqn{\theta_{kj}} - expected mutation
#' counts - one bar per sample, grouped by cluster.
#'
#' @param x A `SignaturePPF` fit, or a `K x J` activity matrix.
#' @param clust Cluster labels, one per sample. `NULL` calls
#'   [cluster_samples()], which partitions the samples with [cluster::pam()].
#' @param normalize Plot each sample's composition rather than its counts.
#'   Note the clustering is always done on the normalised activities regardless.
#' @param k,k_range Number of clusters, or the candidates to choose it from by
#'   silhouette. Passed to [cluster_samples()] and ignored when `clust` is given.
#' @param scales Passed to [ggplot2::facet_wrap()]. The default frees the y axis
#'   per cluster, which is usually what one wants here: a hypermutated cluster
#'   can carry an order of magnitude more burden than the rest, and on a shared
#'   axis it flattens every other panel into the baseline. Free axes make the
#'   composition of each cluster readable at the cost of comparing heights ACROSS
#'   panels - use `"free_x"` to keep that comparison.
#'
#' @returns A ggplot object.
#' @export
plot_Theta <- function(x, clust = NULL, normalize = FALSE, k = NULL,
                       k_range = 2:10, scales = "free") {
  .need_ggplot()
  Theta <- .slot_or_matrix(x, "Thetas")

  if (is.null(clust)) clust <- cluster_samples(Theta, k = k, k_range = k_range)
  if (length(clust) != ncol(Theta)) {
    stop("`clust` must have one entry per sample (ncol(Theta) = ", ncol(Theta),
         ").", call. = FALSE)
  }

  # Largest cluster first. cluster_samples() already numbers them this way, so
  # this is a no-op on its output and only bites for labels passed in from
  # elsewhere. Numeric labels only: a character or factor label is somebody's
  # NAME for the group - a subtype, a cohort - and renumbering it to 1, 2, 3
  # would throw away the very thing they supplied it for.
  if (is.numeric(clust)) clust <- .clusters_by_size(clust)

  totals <- colSums(Theta)
  if (normalize) Theta <- sweep(Theta, 2, totals, "/")

  df <- .melt(Theta, "Signature", "Sample", "Activity")
  df$clust <- factor(clust[match(as.character(df$Sample), colnames(Theta))])

  # Within a cluster, lightest sample first: the eye reads a monotone block far
  # faster than an arbitrary order, and rising into the heavy tail puts the
  # tallest bars of each panel against the next panel's axis.
  ord <- order(clust, totals)
  df$Sample <- factor(df$Sample, levels = colnames(Theta)[ord])

  # facet_wrap, not facet_grid: in a grid the y scale is shared along a row, so
  # with the clusters in columns `scales = "free"` would free x and quietly leave
  # y common - the opposite of the point. `space = "free_x"` keeps each panel as
  # wide as its cluster is large, which facet_wrap has supported since 3.5.0 and
  # is why this no longer needs facet_grid or ggforce::facet_row.
  space <- if (scales %in% c("free", "free_x")) "free_x" else "fixed"

  ggplot2::ggplot(df, ggplot2::aes(x = .data$Sample, y = .data$Activity,
                                   fill = .data$Signature)) +
    ggplot2::geom_col() +
    ggplot2::facet_wrap(~ clust, nrow = 1, scales = scales, space = space) +
    ggplot2::labs(y = if (normalize) "Share of mutations" else "Expected mutations") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.x = ggplot2::element_blank(),
                   axis.title.x = ggplot2::element_blank(),
                   axis.ticks.x = ggplot2::element_blank(),
                   panel.grid.major.x = ggplot2::element_blank(),
                   legend.position = "right")
}


#' Plot the copy-number adjusted baseline
#'
#' The activity of each signature per megabase of copy-number-weighted genome,
#' \deqn{\tilde\phi_{kj} = 10^6 \times \theta_{kj} \big/ \sum_b c_j(b),}
#' i.e. the baseline with the covariate effect held at its mean. The covariates
#' are standardised, so the mean bin has \eqn{x = 0} and \eqn{e^{\beta'x} = 1};
#' the denominator is then the whole of \eqn{q_j}, the total copy-number area of
#' the sample.
#'
#' This is the quantity to compare ACROSS samples. The raw activities confound
#' the mutation rate with how much genome a sample has - ploidy, amplifications,
#' the bins that survived the blacklist - and this divides that out. It differs
#' from `fit$Baseline`, which divides by \eqn{q_j(\beta_k)} and so also removes
#' the signature's own genomic preference.
#'
#' @param x A `SignaturePPF` fit.
#' @param clust,normalize,k,k_range,scales As in [plot_Theta()].
#'
#' @returns A ggplot object.
#' @export
plot_Baseline <- function(x, clust = NULL, normalize = FALSE, k = NULL,
                          k_range = 2:10, scales = "free") {
  .need_ggplot()
  if (!inherits(x, "SignaturePPF")) {
    stop("`x` must be a SignaturePPF fit: the copy-number area is taken from it.",
         call. = FALSE)
  }
  if (is.null(x$copy_area)) {
    stop("this fit predates `copy_area` and cannot be rescaled; refit to plot ",
         "the adjusted baseline.", call. = FALSE)
  }

  rate <- 1e6 * sweep(x$Thetas, 2, x$copy_area[colnames(x$Thetas)], "/")
  p <- plot_Theta(rate, clust = clust, normalize = normalize, k = k,
                  k_range = k_range, scales = scales)
  if (!normalize) {
    p <- p + ggplot2::labs(y = "Expected mutations per Mb (copy-number adjusted)")
  }
  p
}


#' Relevance weight and attributed mutations, one panel per signature
#'
#' One row per signature: point size is the relevance weight \eqn{\mu_k}, fill is
#' the number of mutations the signature is the most probable explanation for,
#' and a cross marks a signature the compressive prior has switched off. Drawn to
#' sit beside [plot_Betas()], so a row of coefficients can be read together with
#' whether its signature is carrying anything - a large coefficient on a
#' signature that wins no mutations is a draw from the prior, not a finding.
#'
#' `data` is required, and not as a convenience: the mutation count cannot be
#' recovered from a fit. It needs every mutation attributed to its most probable
#' signature, which is [assign_mutations()] over the cohort.
#'
#' @param x A `SignaturePPF` fit.
#' @param data The cohort it was fitted on.
#' @param levs Signature order, first panel at the top. `NULL` uses the order in
#'   the fit, which is what makes it line up row-for-row with [plot_Betas()].
#' @param mu_cutoff Below this `mu`, a signature is drawn as switched off. This
#'   is a DISPLAY threshold and is deliberately looser than the package's own
#'   pruning scale of `10 * epsilon`: a signature can clear the pruning rule and
#'   still be carrying nothing worth reading a coefficient row for.
#'
#' @returns A ggplot object.
#' @seealso [df_assign()], [assign_mutations()], [plot_Betas()]
#' @export
plot_Mu <- function(x, data, levs = NULL, mu_cutoff = 0.05) {
  .need_ggplot()
  if (!inherits(x, "SignaturePPF")) {
    stop("`x` must be a SignaturePPF fit: attributing mutations needs the ",
         "signatures, the baseline and the coefficients, not `Mu` alone.",
         call. = FALSE)
  }
  if (missing(data)) {
    stop("`data` is required: how many mutations a signature wins cannot be ",
         "recovered from a fit, only from the cohort it was fitted on.",
         call. = FALSE)
  }

  df <- df_assign(x, data)
  if (is.null(levs)) levs <- colnames(x$Signatures)
  df$best_sig <- factor(df$best_sig, levels = levs)
  df$compressed <- ifelse(df$m == 0 | df$mu < mu_cutoff,
                          "compressed", "not compressed")

  # The shape only ever carries information when BOTH states are present. On a
  # fit that has been through prune_signatures() the compressed ones are already
  # gone, so a "Compressed" key with a single entry is pure legend clutter.
  shape_guide <- if (length(unique(df$compressed)) > 1L) "legend" else "none"

  ggplot2::ggplot(df, ggplot2::aes(x = 1, y = 1, size = .data$mu,
                                   fill = .data$m, shape = .data$compressed)) +
    ggplot2::geom_point(colour = "black", stroke = 0.7) +
    ggplot2::facet_wrap(~ best_sig, ncol = 1, strip.position = "left") +
    ggplot2::scale_size(name = expression(mu[k]), range = c(3, 12)) +
    ggplot2::scale_fill_gradientn(
      name = "N. mutations",
      colours = c("#F6C866", "#F2AB67", "#EF8F6B", "#ED7470", "#BF6E97",
                  "#926AC2", "#6667EE", "#4959C7", "#2D4A9F", "#173C78")) +
    ggplot2::scale_shape_manual(
      name = "Compressed", guide = shape_guide,
      values = c("compressed" = 4, "not compressed" = 21)) +
    ggplot2::theme_bw() +
    ggplot2::theme(
      aspect.ratio = 1,
      axis.title = ggplot2::element_blank(),
      axis.text = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank(),
      strip.text.y.left = ggplot2::element_text(angle = 0),
      strip.background = ggplot2::element_rect(fill = "white", colour = NA),
      legend.position = "left",
      panel.spacing = grid::unit(0.03, "lines"))
}


#' Plot a fitted model
#'
#' The signature spectra, which is the canonical view of a fit. The other panels
#' have their own functions and are called by name rather than through a
#' character switch: [plot_Betas()], [plot_Theta()], [plot_Baseline()] and
#' [plot_Mu()]. They compose with `+` if patchwork is loaded.
#'
#' @param x A `SignaturePPF` fit.
#' @param ... Passed to [plot_Signatures()].
#' @returns A ggplot object.
#' @export
plot.SignaturePPF <- function(x, ...) {
  plot_Signatures(x, ...)
}
