#' Calibrated prior concentrations for the COSMIC v3.4 SBS signatures
#'
#' Precomputed `betah` for each COSMIC v3.4 SBS96 signature: the Dirichlet
#' concentration at which a draw from the signature's own prior has median cosine
#' similarity 0.975 to the signature itself. Pass to the `betah` argument of
#' [SignaturePPF()] to skip the calibration step, or compute your own with
#' [tune_betah()].
#'
#' The spread is the point: SBS2 needs a concentration of about 17 and SBS3 about
#' 1337 to sit at the same similarity, because a spiked signature is far easier
#' to reproduce from a Dirichlet draw than a flat one. A single shared `betah`
#' would therefore make the prior on a flat signature much looser than the prior
#' on a spiked one, without that ever being asked for.
#'
#' @format A named numeric vector of length 86.
#' @source Calibrated against COSMIC Mutational Signatures v3.4,
#'   <https://cancer.sanger.ac.uk/signatures/>, by the procedure in
#'   [tune_betah()].
#' @seealso [tune_betah()], [SignaturePPF()]
#' @examples
#' sort(Betah_SBS96_GRCh37_v3.4)[1:5]     # easiest signatures to pin down
#' Betah_SBS96_GRCh37_v3.4[c("SBS1", "SBS3", "SBS5")]
"Betah_SBS96_GRCh37_v3.4"
