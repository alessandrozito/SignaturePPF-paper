#' Prior hyperparameters
#'
#' Hyperparameters of the Poisson process factorization. The defaults are the
#' compressive ones: `a0` and `b0` are derived from `epsilon` and the number of
#' patients so that signatures with no support are shrunk to `Mu ~ epsilon` and
#' can be pruned.
#'
#' Note that there is no argument for an informative Dirichlet prior on the
#' signatures. Reference signatures enter through the `sigs` argument of
#' [SignaturePPF()] and are held fixed; the model is fitted either de novo or as
#' a refit, never as a mixture of the two. See [SignaturePPF()].
#'
#' @param a Shape of the Gamma prior on the activities,
#'   \eqn{\theta_{kj} \mid \mu_k \sim \mathrm{Ga}(a, a/\mu_k)}.
#' @param alpha Concentration of the Dirichlet prior on the signatures.
#' @param epsilon Scale at which an unsupported signature is parked. Used to
#'   derive `a0`, `b0`, `c0` and `d0` when those are `NULL`, and as the default
#'   pruning threshold in [SignaturePPF()].
#' @param a0,b0 Shape and rate of \eqn{\mu_k \sim \mathrm{InvGa}(a_0, b_0)}.
#'   `NULL` (default) derives the compressive choice
#'   \eqn{a_0 = aJ + 1}, \eqn{b_0 = \epsilon a J}.
#' @param c0,d0 Shape and rate of \eqn{\sigma^2_k \sim \mathrm{InvGa}(c_0, d_0)},
#'   the prior variance of the covariate coefficients. `NULL` derives
#'   \eqn{c_0 = K/2 + 1}, \eqn{d_0 = \epsilon K/2}; the explicit default
#'   `c0 = 100`, `d0 = 1` instead concentrates \eqn{\sigma^2} near 0.01.
#'
#' @returns A list of hyperparameters.
#' @seealso [SignaturePPF()], [SignaturePPF_control()]
#' @export
SignaturePPF_prior <- function(a = 1.01,
                               alpha = 1.01,
                               epsilon = 0.001,
                               a0 = NULL,
                               b0 = NULL,
                               c0 = 100,
                               d0 = 1) {
  stopifnot(a > 0, alpha > 0, epsilon > 0)
  structure(list(a = a, alpha = alpha, epsilon = epsilon,
                 a0 = a0, b0 = b0, c0 = c0, d0 = d0),
            class = "SignaturePPF_prior")
}


#' Control parameters for the estimation algorithms
#'
#' Everything that governs *how* the model is fitted, as opposed to what is
#' fitted. Fields are used by one method or the other, as marked.
#'
#' The three switches that were global options in the predecessor package
#' (`beta_update`, `reuse_probs`, `logpost_every`) are ordinary arguments here.
#' An option set with `options()` is invisible in a script and does not travel
#' with the fit, which makes a run impossible to reproduce from its own record.
#'
#' @param nsamples MCMC. Total number of Gibbs iterations, burn-in included.
#' @param burnin MCMC. Number of initial iterations discarded when forming posterior
#'   summaries. The draws themselves are always kept in `$MCMCchain`.
#' @param thin MCMC. Keep one iteration in `thin`. `nsamples` must be a multiple of
#'   it. Thinning costs almost nothing here - the beta block mixes slowly enough
#'   that neighbouring iterations are nearly duplicates - and it divides the size of
#'   the stored chain and of every checkpoint by the same factor.
#' @param sampler MCMC. Kernel for the \eqn{\beta} block. `"agess"` (default) is
#'   adaptive generalized elliptical slice sampling (Marco & Tokdar,
#'   arXiv:2605.21659), which learns the ellipse from the chain; `"ess"` is the
#'   plain elliptical slice step that draws the ellipse from the Gaussian prior.
#'   Both target the same full conditional, but the prior here is far more
#'   diffuse than the conditional posterior, so `"ess"` mixes considerably worse.
#'   It is retained for the kernel comparison in the paper.
#' @param agess MCMC, `sampler = "agess"` only. See [SignaturePPF_agess_control()].
#'   The defaults are derived from `p` and need no tuning.
#' @param beta_update MCMC, `sampler = "ess"` only. How the slice step is
#'   organised: `2` (default) advances all signatures in lockstep so one pass
#'   over `CopyTrack` serves them all, `1` is sequential, `0` the plain
#'   reference. All three target the same conditional; `0` and `1` follow the
#'   same path for a given seed, `2` interleaves the draws and so does not.
#'   AGESS is always batched and ignores this.
#' @param reuse_probs MCMC. Reuse the assignment probabilities computed at the
#'   end of the previous iteration instead of recomputing them. Purely a speed
#'   switch; the chain is identical either way.
#' @param logpost_every MCMC. Evaluate the log posterior every this many iterations.
#'   It is a diagnostic and never feeds back into an update, so subsampling it
#'   only thins the trace. Non-evaluated iterations store `NA`.
#' @param maxiter MAP. Maximum number of optimization iterations.
#' @param tol MAP. Convergence tolerance on the relative change in the objective.
#' @param n_iter_betas MAP. Fisher scoring steps for \eqn{\beta} per iteration.
#' @param exact_hessian MAP. Use the exact Newton Hessian, including the
#'   \eqn{-\sum_j \bar S_{kj} m_j m_j'/q_j^2} correction. `FALSE` drops that term,
#'   which saves one GEMM over `CopyTrack` per signature per Newton step; the
#'   remaining matrix bounds the Hessian, so the step is still an ascent
#'   direction but a shorter one.
#' @param update_Signatures,update_Theta,update_Betas Hold a block fixed at its
#'   starting value. `update_Signatures` is set automatically by the `sigs`
#'   argument of [SignaturePPF()] - a refit fixes the signatures - and setting it
#'   here overrides that, with a message.
#' @param print_every Iterations between progress reports when `verbose = TRUE`.
#'
#' @returns A list of control parameters.
#' @seealso [SignaturePPF()], [SignaturePPF_checkpoint()]
#' @export
SignaturePPF_control <- function(nsamples = 2000,
                                 burnin = 1000,
                                 thin = 1,
                                 sampler = c("agess", "ess"),
                                 agess = SignaturePPF_agess_control(),
                                 beta_update = 2L,
                                 reuse_probs = TRUE,
                                 logpost_every = 10L,
                                 maxiter = 5000,
                                 tol = 1e-6,
                                 n_iter_betas = 2,
                                 exact_hessian = TRUE,
                                 update_Signatures = NULL,
                                 update_Theta = TRUE,
                                 update_Betas = TRUE,
                                 print_every = 10L) {
  sampler <- match.arg(sampler)
  stopifnot(nsamples >= 1, burnin >= 0, thin >= 1, maxiter >= 1, tol > 0)
  if (burnin >= nsamples) {
    stop("`burnin` (", burnin, ") must be smaller than `nsamples` (", nsamples,
         "): there would be no draws left to summarise.", call. = FALSE)
  }
  if (nsamples %% thin != 0) {
    stop("`nsamples` (", nsamples, ") must be a multiple of `thin` (", thin,
         ").", call. = FALSE)
  }
  if (!beta_update %in% 0:2) stop("`beta_update` must be 0, 1 or 2.", call. = FALSE)

  structure(list(nsamples = as.integer(nsamples),
                 burnin = as.integer(burnin),
                 thin = as.integer(thin),
                 sampler = sampler,
                 agess = agess,
                 beta_update = as.integer(beta_update),
                 reuse_probs = isTRUE(reuse_probs),
                 logpost_every = as.integer(logpost_every),
                 maxiter = as.integer(maxiter),
                 tol = tol,
                 n_iter_betas = as.integer(n_iter_betas),
                 exact_hessian = isTRUE(exact_hessian),
                 update_Signatures = update_Signatures,
                 update_Theta = isTRUE(update_Theta),
                 update_Betas = isTRUE(update_Betas),
                 print_every = as.integer(print_every)),
            class = "SignaturePPF_control")
}


#' Controls for the adaptive elliptical slice sampler
#'
#' Tuning constants of the AGESS kernel (Marco & Tokdar, arXiv:2605.21659). The
#' two that depend on the dimension are derived from `p` rather than guessed, so
#' the defaults are meant to be left alone.
#'
#' @param nu Degrees of freedom of the multivariate \eqn{t} ellipse.
#' @param eps_nonadapt Probability of falling back to the fixed prior ellipse on
#'   any given draw. Keeps the kernel irreducible while the adaptation is still
#'   poor.
#' @param air_beta AirMCMC exponent: gaps between promotions grow like
#'   \eqn{n_j^{\mathrm{air\_beta}}}, which is what makes the adaptation diminish
#'   at the rate the ergodicity argument needs.
#' @param w_const Adaptation weight exponent, \eqn{w_i = i^{-w\_const}}.
#'   `NULL` uses \eqn{\max(2/3, (p^{1/3}-1)/p^{1/3})}, which is 2/3 for every
#'   `p` this model runs at.
#' @param adapt_start Iteration of the first promotion. `NULL` delays it to
#'   \eqn{(2p+2)^{1/w\_const}}, the point at which the running covariance has
#'   accumulated enough effective terms to be full rank.
#' @param ridge_rel Relative jitter used only if the running covariance is
#'   numerically singular at promotion time.
#'
#' @returns A list of AGESS controls.
#' @seealso [SignaturePPF_control()]
#' @export
SignaturePPF_agess_control <- function(nu = 6,
                                       eps_nonadapt = 0.05,
                                       air_beta = 0.5,
                                       w_const = NULL,
                                       adapt_start = NULL,
                                       ridge_rel = 1e-8) {
  stopifnot(nu > 2, eps_nonadapt >= 0, eps_nonadapt < 1, air_beta > 0)
  structure(list(nu = nu,
                 eps_nonadapt = eps_nonadapt,
                 air_beta = air_beta,
                 # The C++ side takes a sentinel rather than NULL for these two.
                 w_const = if (is.null(w_const)) -1 else w_const,
                 adapt_start = if (is.null(adapt_start)) -1L else as.integer(adapt_start),
                 ridge_rel = ridge_rel),
            class = "SignaturePPF_agess_control")
}


#' Initial values
#'
#' Starting values for the blocks. Anything left `NULL` is drawn from the prior
#' or set from the data.
#'
#' @param R_start Signature matrix, `I x K`. For a refit this is set from `sigs`
#'   and cannot be given here.
#' @param Theta_start Activities, `K x J`. On the ACTIVITY scale: \eqn{\theta_{kj}}
#'   is an expected count, not a rate per unit of genome.
#' @param Betas_start Covariate coefficients, `p x K`.
#' @param Mu_start Signature relevance weights, length `K`.
#' @param Sigma2_start Coefficient variances, length `K`.
#'
#' @returns A list of initial values.
#' @seealso [SignaturePPF()]
#' @export
SignaturePPF_init <- function(R_start = NULL,
                              Theta_start = NULL,
                              Betas_start = NULL,
                              Mu_start = NULL,
                              Sigma2_start = NULL) {
  structure(list(R_start = R_start,
                 Theta_start = Theta_start,
                 Betas_start = Betas_start,
                 Mu_start = Mu_start,
                 Sigma2_start = Sigma2_start),
            class = "SignaturePPF_init")
}
