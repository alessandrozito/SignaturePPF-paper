library(testthat)
library(SignaturePPF)

test_check("SignaturePPF")
