test_that("the MAP recovers the signatures it was simulated from", {
  sim <- simulate_ppf(nbins = 2000, J = 6, K = 3, p = 4)
  fit <- SignaturePPF(sim$data, K = 5, method = "map", seed = 1, verbose = FALSE,
                      controls = SignaturePPF_control(maxiter = 300))

  cs <- crossprod(fit$Signatures, sim$truth$R) /
    outer(sqrt(colSums(fit$Signatures^2)), sqrt(colSums(sim$truth$R^2)))
  # Each true signature is matched by some estimated one.
  expect_true(all(apply(cs, 2, max) > 0.95))

  expect_equal(dim(fit$Signatures), c(96L, 5L))
  expect_equal(dim(fit$Thetas), c(5L, 6L))
  expect_equal(dim(fit$Betas), c(4L, 5L))
  # Theta is the TOTAL activity, so it lives on the scale of a mutation count.
  expect_equal(sum(fit$Thetas), length(sim$data$gr_Mutations), tolerance = 0.05)
  # Baseline = Theta / Q, by definition.
  expect_equal(fit$Baseline, fit$Thetas / fit$Q, tolerance = 1e-8)
})

test_that("a refit holds the reference signatures fixed and recovers beta", {
  sim <- simulate_ppf(nbins = 2000, J = 6, K = 3, p = 4)
  fit <- SignaturePPF(sim$data, sigs = sim$truth$R, method = "map", seed = 3,
                      verbose = FALSE,
                      controls = SignaturePPF_control(maxiter = 300))

  expect_equal(fit$type, "refit")
  expect_equal(fit$K, 3L)
  expect_identical(fit$Signatures, sim$truth$R)
  expect_false(fit$controls$update_Signatures)
  expect_gt(cor(c(fit$Betas), c(sim$truth$Betas)), 0.95)
})

test_that("`sigs_fixed` selects between the refit and the semi-supervised fit", {
  sim <- simulate_ppf(nbins = 500, J = 3, K = 2, p = 3)
  ctl <- SignaturePPF_control(maxiter = 5)
  ref <- sim$truth$R

  # FALSE anchors the references but leaves them estimated, and adds K de novo.
  soft <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 4,
                       betah = 100, method = "map", seed = 1, verbose = FALSE,
                       controls = ctl)
  expect_equal(soft$type, "semisupervised")
  expect_equal(soft$K, ncol(ref) + 4L)
  expect_true(soft$controls$update_Signatures)

  # TRUE pins them and ignores K.
  hard <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = TRUE, K = 4,
                       method = "map", seed = 1, verbose = FALSE, controls = ctl)
  expect_equal(hard$type, "refit")
  expect_equal(hard$K, ncol(ref))
  expect_false(hard$controls$update_Signatures)

  # With no `sigs`, sigs_fixed is irrelevant either way.
  for (sf in c(TRUE, FALSE)) {
    d <- SignaturePPF(sim$data, K = 2, sigs_fixed = sf, method = "map", seed = 1,
                      verbose = FALSE, controls = ctl)
    expect_equal(d$type, "denovo")
    expect_equal(d$K, 2L)
  }
})

test_that("a refit rejects a reference that does not cover the channels", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  bad <- sim$truth$R[1:50, , drop = FALSE]
  expect_error(SignaturePPF(sim$data, sigs = bad, method = "map", verbose = FALSE),
               "missing 46 channel")

  unnamed <- unname(sim$truth$R)
  expect_error(SignaturePPF(sim$data, sigs = unnamed, method = "map", verbose = FALSE),
               "rownames")
})

test_that("reference signatures are reordered to the data's channel ordering", {
  sim <- simulate_ppf(nbins = 800, J = 4, K = 2, p = 3)
  shuffled <- sim$truth$R[sample.int(96), , drop = FALSE]
  fit <- SignaturePPF(sim$data, sigs = shuffled, method = "map", seed = 2,
                      verbose = FALSE, controls = SignaturePPF_control(maxiter = 5))
  expect_identical(fit$Signatures, sim$truth$R)
})

test_that("MCMC returns draws of the declared shape and honours thinning", {
  sim <- simulate_ppf(nbins = 800, J = 4, K = 2, p = 3)
  ctl <- SignaturePPF_control(nsamples = 120, burnin = 40, thin = 4)
  fit <- SignaturePPF(sim$data, K = 3, method = "mcmc", seed = 5, verbose = FALSE,
                      controls = ctl, init_mcmc_from_map = FALSE)

  expect_equal(dim(fit$MCMCchain$MUchain), c(30L, 3L))          # 120 / 4
  expect_equal(dim(fit$MCMCchain$SIGSchain), c(30L, 96L, 3L))
  # Stored draw s is iteration 4s, so burn-in 40 discards the first 10 draws.
  expect_equal(fit$n_kept, 20L)
  expect_equal(dimnames(fit$MCMCchain$BETASchain)[[2]], colnames(sim$data$SignalTrack))
})

test_that("both samplers run and agree on the shape of the output", {
  sim <- simulate_ppf(nbins = 600, J = 4, K = 2, p = 3)
  ctl <- function(s) SignaturePPF_control(nsamples = 60, burnin = 20, sampler = s)

  a <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, verbose = FALSE,
                    controls = ctl("agess"), init_mcmc_from_map = FALSE)
  e <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, verbose = FALSE,
                    controls = ctl("ess"), init_mcmc_from_map = FALSE)

  expect_equal(dim(a$MCMCchain$BETASchain), dim(e$MCMCchain$BETASchain))
  # Only the adaptive kernel reports ellipse diagnostics.
  expect_false(is.null(a$MCMCchain$SHRINKchain))
  expect_null(e$MCMCchain$SHRINKchain)
})

test_that("prune_after_map drops the signatures the optimizer parked", {
  sim <- simulate_ppf(nbins = 2000, J = 6, K = 3, p = 4)
  fit <- SignaturePPF(sim$data, K = 8, method = "mcmc", seed = 5, verbose = FALSE,
                      prune_after_map = TRUE,
                      controls = SignaturePPF_control(nsamples = 40, burnin = 10,
                                                      maxiter = 300))
  expect_lt(fit$K, 8L)
  expect_equal(dim(fit$MCMCchain$MUchain)[2], fit$K)
  expect_equal(ncol(fit$Signatures), fit$K)
})

test_that("controls reject impossible combinations", {
  expect_error(SignaturePPF_control(nsamples = 100, burnin = 100), "must be smaller")
  expect_error(SignaturePPF_control(nsamples = 100, burnin = 50, thin = 3),
               "multiple of")
  expect_error(SignaturePPF_control(beta_update = 5), "0, 1 or 2")
})
