# The whole value of checkpointing rests on one claim: a chain assembled from
# blocks is the chain an uninterrupted run would have produced. These tests are
# the ones that fail loudly if that stops being true.

test_that("running in blocks does not change the chain", {
  sim <- simulate_ppf(nbins = 800, J = 4, K = 2, p = 3)
  dir <- new_ckpt_dir()
  ctl <- SignaturePPF_control(nsamples = 200, burnin = 50, sampler = "agess")

  plain <- SignaturePPF(sim$data, K = 3, method = "mcmc", seed = 7,
                        controls = ctl, verbose = FALSE)
  # A block length that divides neither the run nor the print interval, so the
  # seams fall in awkward places.
  blocked <- SignaturePPF(sim$data, K = 3, method = "mcmc", seed = 7,
                          controls = ctl, verbose = FALSE,
                          checkpoint = SignaturePPF_checkpoint(dir = dir, every = 37))

  for (nm in names(plain$MCMCchain)) {
    expect_identical(blocked$MCMCchain[[nm]], plain$MCMCchain[[nm]], info = nm)
  }
  expect_identical(blocked$Signatures, plain$Signatures)
  expect_identical(blocked$Betas, plain$Betas)
})

test_that("blocking is exact with thinning too", {
  sim <- simulate_ppf(nbins = 600, J = 4, K = 2, p = 3)
  dir <- new_ckpt_dir()
  ctl <- SignaturePPF_control(nsamples = 240, burnin = 60, thin = 3)

  plain <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 4, controls = ctl,
                        verbose = FALSE, init_mcmc_from_map = FALSE)
  # 50 is not a multiple of thin; the block length must be rounded up so that a
  # seam never falls inside a thinning cycle.
  blocked <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 4, controls = ctl,
                          verbose = FALSE, init_mcmc_from_map = FALSE,
                          checkpoint = SignaturePPF_checkpoint(dir = dir, every = 50))

  expect_identical(blocked$MCMCchain$BETASchain, plain$MCMCchain$BETASchain)
  expect_identical(blocked$MCMCchain$MUchain, plain$MCMCchain$MUchain)
  expect_equal(dim(blocked$MCMCchain$MUchain)[1], 80L)
})

test_that("a chain interrupted mid-run resumes into the identical chain", {
  skip_on_cran()
  sim <- simulate_ppf(nbins = 1500, J = 5, K = 3, p = 4)
  dir <- new_ckpt_dir()
  ctl <- SignaturePPF_control(nsamples = 4000, burnin = 500)
  run <- function(ck) {
    SignaturePPF(sim$data, K = 3, method = "mcmc", seed = 11, controls = ctl,
                 checkpoint = ck, verbose = FALSE, init_mcmc_from_map = FALSE)
  }

  reference <- run(SignaturePPF_checkpoint())

  # setTimeLimit fires at the next interrupt check, which the samplers now
  # perform every iteration - so this stops the run in the middle of the C++ loop,
  # exactly as Ctrl-C or a wall-clock kill would. It arrives as an interrupt
  # rather than an error, hence the `condition` handler.
  ck <- SignaturePPF_checkpoint(dir = dir, every = 100)
  stopped <- tryCatch({
    setTimeLimit(elapsed = 2, transient = TRUE)
    run(ck)
    "completed"
  }, condition = function(c) { setTimeLimit(); "interrupted" })
  setTimeLimit()
  skip_if(stopped == "completed", "run finished before the time limit fired")

  state <- readRDS(file.path(dir, "state.rds"))
  expect_gt(state$iters_done, 0)
  expect_lt(state$iters_done, 4000)

  resumed <- run(ck)
  expect_identical(resumed$MCMCchain$BETASchain, reference$MCMCchain$BETASchain)
  expect_identical(resumed$MCMCchain$SIGSchain, reference$MCMCchain$SIGSchain)
  expect_identical(resumed$MCMCchain$MUchain, reference$MCMCchain$MUchain)
  expect_identical(resumed$Signatures, reference$Signatures)
})

test_that("a completed checkpoint is returned without resampling", {
  sim <- simulate_ppf(nbins = 500, J = 3, K = 2, p = 3)
  dir <- new_ckpt_dir()
  ctl <- SignaturePPF_control(nsamples = 60, burnin = 20)
  ck <- SignaturePPF_checkpoint(dir = dir, every = 20)

  first <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, controls = ctl,
                        checkpoint = ck, verbose = FALSE)
  again <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, controls = ctl,
                        checkpoint = ck, verbose = FALSE)
  expect_identical(again$MCMCchain$MUchain, first$MCMCchain$MUchain)
  expect_true(again$complete)
})

test_that("resuming onto a different run is refused", {
  sim <- simulate_ppf(nbins = 500, J = 3, K = 2, p = 3)
  dir <- new_ckpt_dir()
  ctl <- SignaturePPF_control(nsamples = 60, burnin = 20)
  ck <- SignaturePPF_checkpoint(dir = dir, every = 20)

  SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, controls = ctl,
               checkpoint = ck, verbose = FALSE)

  expect_error(
    SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 2, controls = ctl,
                 checkpoint = ck, verbose = FALSE),
    "written by a different run.*seed")

  expect_error(
    SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, checkpoint = ck,
                 controls = SignaturePPF_control(nsamples = 80, burnin = 20),
                 verbose = FALSE),
    "written by a different run.*controls")

  # ... but starting over in the same directory is allowed when asked for.
  expect_no_error(
    SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 2, controls = ctl,
                 verbose = FALSE,
                 checkpoint = SignaturePPF_checkpoint(dir = dir, every = 20,
                                                      resume = FALSE)))
})

test_that("checkpoint files are written atomically", {
  # A temporary file left behind would mean a kill could be observed mid-write.
  sim <- simulate_ppf(nbins = 500, J = 3, K = 2, p = 3)
  dir <- new_ckpt_dir()
  SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, verbose = FALSE,
               controls = SignaturePPF_control(nsamples = 60, burnin = 20),
               checkpoint = SignaturePPF_checkpoint(dir = dir, every = 20))

  expect_length(list.files(dir, pattern = "^iterations_"), 3L)
  expect_true(file.exists(file.path(dir, "state.rds")))
  expect_length(list.files(dir, pattern = "\\.tmp-"), 0L)
})

test_that("cleanup removes the directory once the chain is assembled", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  dir <- tempfile("ck-")
  fit <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, verbose = FALSE,
                      controls = SignaturePPF_control(nsamples = 40, burnin = 10),
                      checkpoint = SignaturePPF_checkpoint(dir = dir, every = 20,
                                                           cleanup = TRUE))
  expect_false(dir.exists(dir))
  expect_equal(dim(fit$MCMCchain$MUchain)[1], 40L)
})
