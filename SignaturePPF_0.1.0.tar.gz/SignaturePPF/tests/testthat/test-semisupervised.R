# The three modes, and the calibration that makes the informative one usable.

test_that("the three modes give the K they advertise", {
  sim <- simulate_ppf(nbins = 800, J = 5, K = 3, p = 3)
  ref <- sim$truth$R[, 1:2]
  colnames(ref) <- c("RefA", "RefB")
  ctl <- SignaturePPF_control(maxiter = 20)
  fit <- function(...) SignaturePPF(sim$data, method = "map", seed = 1,
                                    verbose = FALSE, controls = ctl, ...)

  d <- fit(K = 4)
  expect_equal(d$type, "denovo"); expect_equal(d$K, 4L); expect_equal(d$H, 0L)

  r <- fit(sigs = ref, sigs_fixed = TRUE, K = 99)   # K ignored for a refit
  expect_equal(r$type, "refit"); expect_equal(r$K, 2L); expect_equal(r$H, 2L)

  s <- fit(sigs = ref, sigs_fixed = FALSE, K = 3, betah = 200)
  expect_equal(s$type, "semisupervised")
  expect_equal(s$K, 5L)                              # 2 informative + 3 de novo
  expect_equal(s$H, 2L)
  expect_equal(colnames(s$Signatures)[1:2], c("RefA", "RefB"))

  # K = 0 is a soft refit: anchored, but free to move.
  z <- fit(sigs = ref, sigs_fixed = FALSE, K = 0, betah = 200)
  expect_equal(z$K, 2L)
  expect_equal(z$H, 2L)
})

test_that("the informative block is betah * s and the rest stays flat", {
  sim <- simulate_ppf(nbins = 600, J = 4, K = 2, p = 3)
  ref <- sim$truth$R[, 1, drop = FALSE]
  colnames(ref) <- "RefA"

  fit <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 2,
                      betah = 250, method = "map", seed = 1, verbose = FALSE,
                      controls = SignaturePPF_control(maxiter = 5))

  expect_equal(fit$betah, c(RefA = 250))
  # Column 1: Dirichlet(betah * s), so it sums to betah and is proportional to s.
  expect_equal(sum(fit$SigPrior[, 1]), 250)
  expect_equal(unname(fit$SigPrior[, 1]),
               unname(250 * ref[rownames(fit$SigPrior), 1]))
  # Columns 2-3: flat alpha.
  expect_true(all(fit$SigPrior[, 2:3] == fit$prior$alpha))
})

test_that("a refit and a de novo fit both keep a flat prior", {
  sim <- simulate_ppf(nbins = 500, J = 4, K = 2, p = 3)
  ref <- sim$truth$R
  ctl <- SignaturePPF_control(maxiter = 5)

  r <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = TRUE, method = "map",
                    seed = 1, verbose = FALSE, controls = ctl)
  expect_true(all(r$SigPrior == r$prior$alpha))
  expect_null(r$betah)
  expect_false(r$controls$update_Signatures)

  d <- SignaturePPF(sim$data, K = 3, method = "map", seed = 1, verbose = FALSE,
                    controls = ctl)
  expect_true(all(d$SigPrior == d$prior$alpha))
  expect_true(d$controls$update_Signatures)
})

test_that("an informative prior anchors a signature without pinning it", {
  sim <- simulate_ppf(nbins = 2000, J = 8, K = 3, p = 4)
  ref <- sim$truth$R[, 1, drop = FALSE]
  colnames(ref) <- "RefA"
  cosine <- function(a, b) sum(a * b) / sqrt(sum(a^2) * sum(b^2))

  tight <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 3,
                        betah = 1e6, method = "map", seed = 1, verbose = FALSE,
                        controls = SignaturePPF_control(maxiter = 300))
  loose <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 3,
                        betah = 5, method = "map", seed = 1, verbose = FALSE,
                        controls = SignaturePPF_control(maxiter = 300))

  # A huge concentration is a hard refit in the limit; a tiny one lets the data
  # take over. Both are still ESTIMATED, unlike sigs_fixed = TRUE.
  expect_gt(cosine(tight$Signatures[, "RefA"], ref[, 1]), 0.99)
  expect_gt(cosine(tight$Signatures[, "RefA"], ref[, 1]),
            cosine(loose$Signatures[, "RefA"], ref[, 1]))
  expect_true(tight$controls$update_Signatures)
})

test_that("tune_betah hits its target similarity and scales with flatness", {
  set.seed(4)
  spiked <- c(rep(0.001, 90), rep(0.9 / 6, 6)); spiked <- spiked / sum(spiked)
  flat <- rep(1 / 96, 96)
  sigs <- cbind(spiked = spiked, flat = flat)
  rownames(sigs) <- paste0("ch", 1:96)

  b <- tune_betah(sigs, nsim = 400)
  expect_named(b, c("spiked", "flat"))
  expect_equal(unname(attr(b, "similarity")), c(0.975, 0.975), tolerance = 0.01)
  # A flat signature is harder to reproduce from a Dirichlet draw, so it needs
  # more mass to reach the same similarity.
  expect_gt(b[["flat"]], b[["spiked"]])
})

test_that("tune_betah is deterministic and leaves the RNG stream alone", {
  sigs <- cbind(a = rep(1 / 96, 96)); rownames(sigs) <- paste0("ch", 1:96)

  expect_equal(tune_betah(sigs, nsim = 200), tune_betah(sigs, nsim = 200))

  # Calibration must not shift a chain drawn afterwards.
  set.seed(99); before <- runif(3)
  set.seed(99); invisible(tune_betah(sigs, nsim = 200)); after <- runif(3)
  expect_equal(before, after)
})

test_that("betah accepts a scalar, a named vector, and rejects the rest", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  ref <- sim$truth$R; colnames(ref) <- c("RefA", "RefB")
  fit <- function(b) SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 1,
                                  betah = b, method = "map", seed = 1,
                                  verbose = FALSE,
                                  controls = SignaturePPF_control(maxiter = 3))

  expect_equal(fit(300)$betah, c(RefA = 300, RefB = 300))
  expect_equal(fit(c(RefB = 20, RefA = 10))$betah, c(RefA = 10, RefB = 20))
  expect_error(fit(c(RefA = 10)), "no entry for: RefB")
  expect_error(fit(-1), "must be positive")
  expect_error(fit("nonsense"), "must be \"auto\"")
})

test_that("betah is ignored where it has no meaning", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  ref <- sim$truth$R
  ctl <- SignaturePPF_control(maxiter = 3)
  # A refit holds the signatures fixed, so there is no prior strength to set;
  # "auto" must not trigger a pointless calibration.
  expect_null(SignaturePPF(sim$data, sigs = ref, sigs_fixed = TRUE,
                           method = "map", seed = 1, verbose = FALSE,
                           controls = ctl)$betah)
  expect_null(SignaturePPF(sim$data, K = 2, method = "map", seed = 1,
                           verbose = FALSE, controls = ctl)$betah)
})

test_that("pruning a reference signature keeps H and betah consistent", {
  # Two references, one of which (RefB) is absent from the simulated data, so the
  # compressive prior should park it and pruning should drop it.
  sim <- simulate_ppf(nbins = 2000, J = 6, K = 2, p = 4)
  ref <- cbind(RefA = sim$truth$R[, 1], RefB = rev(sim$truth$R[, 1]))
  ref <- sweep(ref, 2, colSums(ref), "/")

  fit <- SignaturePPF(sim$data, sigs = ref, sigs_fixed = FALSE, K = 2,
                      betah = 100, method = "mcmc", seed = 3, verbose = FALSE,
                      prune_after_map = TRUE,
                      controls = SignaturePPF_control(nsamples = 40, burnin = 10,
                                                      maxiter = 300))
  expect_lte(fit$H, 2L)
  expect_equal(length(fit$betah), fit$H)
  expect_true(all(names(fit$betah) %in% colnames(fit$Signatures)))
  expect_equal(ncol(fit$SigPrior), fit$K)
})

test_that("the packaged COSMIC concentrations are usable as betah", {
  expect_length(Betah_SBS96_GRCh37_v3.4, 86L)
  expect_true(all(Betah_SBS96_GRCh37_v3.4 > 0))
  expect_true(all(c("SBS1", "SBS3", "SBS5") %in% names(Betah_SBS96_GRCh37_v3.4)))
  # A flat signature needs far more mass than a spiked one.
  expect_gt(Betah_SBS96_GRCh37_v3.4[["SBS3"]], Betah_SBS96_GRCh37_v3.4[["SBS2"]])
})
