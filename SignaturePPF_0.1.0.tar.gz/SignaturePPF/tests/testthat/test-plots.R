skip_if_not_installed("ggplot2")

# plot_Mu() needs the cohort as well as the fit, so the fixture keeps both.
sim_for_plots <- function() {
  sim <- simulate_ppf(nbins = 800, J = 12, K = 3, p = 4)
  fit <- SignaturePPF(sim$data, K = 5, method = "mcmc", seed = 2, verbose = FALSE,
                      controls = SignaturePPF_control(nsamples = 100, burnin = 40,
                                                      maxiter = 200))
  list(fit = fit, data = sim$data)
}

fit_for_plots <- function() sim_for_plots()$fit

test_that("every panel builds", {
  s <- sim_for_plots()
  panels <- list(plot_Signatures(s$fit), plot_Betas(s$fit), plot_Theta(s$fit),
                 plot_Baseline(s$fit), plot_Mu(s$fit, s$data))
  for (p in panels) {
    expect_s3_class(p, "ggplot")
    expect_no_error(ggplot2::ggplot_build(p))
  }
})

test_that("plot_Mu refuses without the cohort", {
  s <- sim_for_plots()
  # The mutation count is not recoverable from a fit, so this must fail loudly
  # rather than silently draw a panel with nothing in the fill.
  expect_error(plot_Mu(s$fit), "data. is required")
  expect_error(plot_Mu(s$fit$Mu, s$data), "must be a SignaturePPF fit")
})

test_that("df_assign keeps signatures that win nothing", {
  s <- sim_for_plots()
  df <- df_assign(s$fit, s$data)
  expect_setequal(df$best_sig, colnames(s$fit$Signatures))
  expect_equal(sum(df$m), length(s$data$gr_Mutations))
  expect_true(all(df$m >= 0))
})

test_that("plot() on a fit gives the signatures", {
  fit <- fit_for_plots()
  expect_s3_class(plot(fit), "ggplot")
  expect_equal(plot(fit)$labels, plot_Signatures(fit)$labels)
})

test_that("the beta heatmap carries no colour guide", {
  # The estimate is printed in each cell, so a scale bar would restate it.
  fit <- fit_for_plots()
  g <- ggplot2::ggplot_build(plot_Betas(fit))
  expect_length(ggplot2::get_guide_data(g, "fill"), 0L)
})

test_that("plot_Betas caps the fill without altering the label", {
  fit <- fit_for_plots()
  fit$Betas[1, 1] <- 12          # one dominant coefficient

  built <- ggplot2::ggplot_build(plot_Betas(fit, ci = FALSE, cap = 1))
  # The fill saturates AT the cap - it is bounded by it, not stretched to it, so
  # only the side that actually has an outlier reaches the limit.
  expect_lte(max(abs(built$plot$data$fill), na.rm = TRUE), 1)
  expect_equal(max(built$plot$data$fill, na.rm = TRUE), 1)
  # ... while the printed value is the true one.
  expect_true("12" %in% built$data[[2]]$label)

  # Without a cap the scale stretches to the outlier, which is the behaviour the
  # cap exists to avoid.
  uncapped <- ggplot2::ggplot_build(plot_Betas(fit, ci = FALSE, cap = NULL))$plot$data
  expect_equal(max(uncapped$fill, na.rm = TRUE), 12)
})

test_that("coefficients whose interval covers zero are dropped from the fill", {
  fit <- fit_for_plots()
  p <- plot_Betas(fit, ci = TRUE)
  q <- posterior_CI(fit, "Betas")
  expect_equal(sum(is.na(p$data$Beta)), sum(q$lowCI < 0 & q$highCI > 0))
})

test_that("posterior_CI respects burn-in and thinning", {
  sim <- simulate_ppf(nbins = 600, J = 4, K = 2, p = 3)
  fit <- SignaturePPF(sim$data, K = 2, method = "mcmc", seed = 1, verbose = FALSE,
                      init_mcmc_from_map = FALSE,
                      controls = SignaturePPF_control(nsamples = 120, burnin = 40,
                                                      thin = 4))
  q <- posterior_CI(fit, "Betas")
  # 30 draws stored, the first 10 discarded; means must match the fit's own.
  manual <- apply(fit$MCMCchain$BETASchain[11:30, , , drop = FALSE], c(2, 3), mean)
  expect_equal(q$mean, manual)
  expect_equal(q$mean, fit$Betas)
  expect_true(all(q$lowCI <= q$highCI))
})

test_that("posterior_CI refuses a MAP fit", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  fit <- SignaturePPF(sim$data, K = 2, method = "map", seed = 1, verbose = FALSE,
                      controls = SignaturePPF_control(maxiter = 20))
  expect_error(posterior_CI(fit), "need method = \"mcmc\"")
})

test_that("clustering runs on normalised activities and picks k by silhouette", {
  # Two blocks of samples with clearly different composition but very different
  # burdens: clustering on raw counts would split on burden instead.
  set.seed(1)
  K <- 3; J <- 20
  comp <- cbind(matrix(c(0.8, 0.15, 0.05), K, J / 2),
                matrix(c(0.05, 0.15, 0.8), K, J / 2))
  burden <- rep(c(100, 10000), each = J / 2)
  Theta <- sweep(comp, 2, burden, "*")
  dimnames(Theta) <- list(paste0("S", 1:K), paste0("P", 1:J))

  cl <- cluster_samples(Theta)
  expect_equal(attr(cl, "k"), 2L)
  expect_equal(length(unique(cl[1:10])), 1L)
  expect_equal(length(unique(cl[11:20])), 1L)
  expect_false(cl[1] == cl[20])
})

test_that("the adjusted baseline divides activities by the copy-number area", {
  fit <- fit_for_plots()
  p <- plot_Baseline(fit)
  expected <- 1e6 * sweep(fit$Thetas, 2, fit$copy_area[colnames(fit$Thetas)], "/")
  got <- tapply(p$data$Activity,
                list(as.character(p$data$Signature), as.character(p$data$Sample)),
                identity)
  expect_equal(got[rownames(expected), colnames(expected)], expected,
               ignore_attr = TRUE)
})

test_that("plot_Baseline needs a fit, not a bare matrix", {
  fit <- fit_for_plots()
  expect_error(plot_Baseline(fit$Thetas), "must be a SignaturePPF fit")
})

test_that("the plot functions accept a bare matrix as well as a fit", {
  fit <- fit_for_plots()
  expect_s3_class(plot_Betas(fit$Betas), "ggplot")
  expect_s3_class(plot_Signatures(fit$Signatures), "ggplot")
  expect_s3_class(plot_Theta(fit$Thetas), "ggplot")
  # plot_Mu is deliberately NOT in this set: it needs the cohort, not a matrix.
})
