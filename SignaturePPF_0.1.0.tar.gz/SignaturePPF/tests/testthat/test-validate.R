test_that("a well-formed dataset passes and reports the right dimensions", {
  sim <- simulate_ppf(nbins = 500, J = 4, K = 2, p = 3)
  d <- SignaturePPF_validate(sim$data)

  expect_equal(d$I, 96L)
  expect_equal(d$J, 4L)
  expect_equal(d$p, 3L)
  expect_equal(d$nbins, 500L)
  expect_equal(d$N, length(sim$data$gr_Mutations))
  expect_equal(colnames(d$CopyTrack), colnames(d$MutMatrix))
  expect_true(all(d$channel_id >= 0), all(d$sample_id >= 0))
})

test_that("covariates must agree in name and in order", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)

  bad <- sim$data
  colnames(bad$SignalTrack) <- rev(colnames(bad$SignalTrack))
  expect_error(SignaturePPF_validate(bad), "match in name AND in order")

  bad <- sim$data
  bad$SignalTrack <- bad$SignalTrack[, -1, drop = FALSE]
  expect_error(SignaturePPF_validate(bad), "covariate")
})

test_that("the two tracks must describe the same bins", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  bad <- sim$data
  bad$CopyTrack <- bad$CopyTrack[1:10, , drop = FALSE]
  expect_error(SignaturePPF_validate(bad), "same bins in the same order")
})

test_that("every sample needs a CopyTrack column", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  bad <- sim$data
  bad$CopyTrack <- bad$CopyTrack[, -1, drop = FALSE]
  expect_error(SignaturePPF_validate(bad), "no CopyTrack column")
})

test_that("a constant covariate is rejected as an unidentified intercept", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  bad <- sim$data
  bad$SignalTrack <- cbind(bad$SignalTrack, intercept = 1)
  mcols(bad$gr_Mutations)$intercept <- 1
  expect_error(SignaturePPF_validate(bad), "intercept is not identified")
})

test_that("`sample` and `channel` are never taken for covariates", {
  # A cohort with numeric sample ids would otherwise be fitted with the patient
  # identifier as a genomic covariate.
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)
  d <- sim$data
  mcols(d$gr_Mutations)$sample <- as.numeric(mcols(d$gr_Mutations)$sample)
  mcols(d$gr_Mutations)$channel <- as.numeric(mcols(d$gr_Mutations)$channel)
  colnames(d$CopyTrack) <- as.character(seq_len(ncol(d$CopyTrack)))
  out <- SignaturePPF_validate(d)
  expect_equal(out$p, 3L)
  expect_equal(colnames(out$X), colnames(d$SignalTrack))
})

test_that("non-finite and negative entries are caught", {
  sim <- simulate_ppf(nbins = 400, J = 3, K = 2, p = 3)

  bad <- sim$data; bad$SignalTrack[1, 1] <- NA
  expect_error(SignaturePPF_validate(bad), "non-finite")

  bad <- sim$data; bad$CopyTrack[1, 1] <- -1
  expect_error(SignaturePPF_validate(bad), "negative")
})
