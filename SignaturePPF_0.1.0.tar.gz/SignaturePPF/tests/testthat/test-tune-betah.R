# The fast engine solves the same equation as the reference one. These tests are
# what stops the scaling-law shortcut from quietly drifting away from the
# criterion it is supposed to be solving.

test_that("the cpp and R engines agree", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS2", "SBS3", "SBS5", "SBS13",
                                       "SBS17b", "SBS40a")]
  a <- tune_betah(sigs, engine = "cpp")
  b <- tune_betah(sigs, engine = "R")

  expect_named(a, colnames(sigs))
  expect_equal(names(a), names(b))
  # Both are Monte Carlo solutions of the same equation, so they agree up to
  # sampling noise rather than exactly. 15% is comfortably inside that.
  expect_lt(max(abs(log2(a / b))), log2(1.15))
})

test_that("both engines land on the requested similarity", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS3", "SBS5")]
  for (eng in c("cpp", "R")) {
    b <- tune_betah(sigs, engine = eng)
    expect_equal(unname(attr(b, "similarity")), rep(0.975, 3), tolerance = 0.005,
                 info = eng)
  }
})

test_that("a non-default target moves betah the right way", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37[, "SBS5", drop = FALSE]
  loose <- tune_betah(sigs, target = 0.95)
  tight <- tune_betah(sigs, target = 0.99)
  # Demanding a closer match to the reference means a more concentrated prior.
  expect_gt(tight[[1]], loose[[1]])
  expect_equal(attr(loose, "similarity"), 0.95, tolerance = 0.005)
  expect_equal(attr(tight, "similarity"), 0.99, tolerance = 0.005)
})

test_that("the scaling law converges in a couple of evaluations", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37
  b <- tune_betah(sigs, engine = "cpp")
  # The analytic starting value should be close enough that one correction is
  # usually enough. The bisection path needs about 13.
  expect_lt(mean(attr(b, "iters")), 4)
  expect_true(all(attr(b, "iters") <= 20))
})

test_that("the search stays off the degenerate branch for spiked signatures", {
  # Median similarity is NOT monotone in betah near zero: as betah -> 0 the
  # Dirichlet collapses onto a single channel, and for a signature whose mass is
  # concentrated there that collapsed draw scores a HIGH cosine. SBS10a measures
  # ~0.977 at betah = 1, dips to ~0.969, and recovers - so a bracket reaching
  # below the default lower bound admits a second, meaningless root.
  s <- COSMIC_v3.4_SBS96_GRCh37[, "SBS10a", drop = FALSE]
  expect_gt(max(s), 0.6)                       # genuinely spiked

  set.seed(1)
  dip <- vapply(c(1, 2, 5), function(b) SignaturePPF:::.median_cosine(b, s[, 1], 4000), numeric(1))
  expect_lt(dip[2], dip[1])                    # the non-monotonicity is real

  b <- tune_betah(s)
  expect_gte(b[[1]], 10)
})

test_that("betah is reported at the bound without a spurious warning", {
  # A signature whose prior already exceeds the target at the loosest allowed
  # concentration is not a calibration failure, and must not warn.
  s <- COSMIC_v3.4_SBS96_GRCh37[, "SBS10a", drop = FALSE]
  expect_no_warning(b <- tune_betah(s))
  expect_equal(b[[1]], 10)

  # Being unable to REACH the target is a failure, and must warn.
  expect_warning(tune_betah(COSMIC_v3.4_SBS96_GRCh37[, "SBS5", drop = FALSE],
                            range = c(10, 20)),
                 "could not be calibrated")
})

test_that("flatter signatures need more prior mass", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS2", "SBS3")]
  b <- tune_betah(sigs)
  # SBS2 is spiked, SBS3 is nearly flat; at the same target similarity the flat
  # one needs orders of magnitude more concentration.
  expect_gt(b[["SBS3"]], 10 * b[["SBS2"]])
})

test_that("the cpp engine is deterministic and leaves the RNG alone", {
  sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS5")]
  expect_equal(tune_betah(sigs), tune_betah(sigs))
  expect_false(isTRUE(all.equal(unname(tune_betah(sigs, seed = 1)),
                                unname(tune_betah(sigs, seed = 2)))))

  set.seed(7); before <- runif(3)
  set.seed(7); invisible(tune_betah(sigs)); after <- runif(3)
  expect_equal(before, after)
})

test_that("unnamed reference columns are still labelled", {
  sigs <- unname(COSMIC_v3.4_SBS96_GRCh37[, 1:2])
  b <- tune_betah(sigs, nsim = 200)
  expect_named(b, c("Ref01", "Ref02"))
})
