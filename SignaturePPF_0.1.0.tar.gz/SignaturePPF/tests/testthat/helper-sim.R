# Small synthetic PPF dataset drawn from the model itself, so that the tests can
# check recovery against a known truth rather than against a stored fit.
suppressMessages(library(GenomicRanges))

simulate_ppf <- function(nbins = 2000, J = 6, K = 3, p = 4, bin_width = 1000,
                         seed = 42) {
  set.seed(seed)
  I <- 96
  channels <- {
    nuc <- c("A", "C", "G", "T")
    subs <- c("C>A", "C>G", "C>T", "T>A", "T>C", "T>G")
    sort(apply(expand.grid(nuc, subs, nuc), 1,
               function(x) paste0(x[1], "[", x[2], "]", x[3])))
  }
  samples <- sprintf("S%02d", seq_len(J))
  covs <- sprintf("cov%d", seq_len(p))

  # Covariates: correlated, standardised - as the real tracks are after
  # preprocessing.
  Z <- matrix(rnorm(nbins * p), nbins, p)
  Z[, 2] <- 0.7 * Z[, 1] + sqrt(1 - 0.49) * Z[, 2]
  SignalTrack <- scale(Z)
  attr(SignalTrack, "scaled:center") <- NULL
  attr(SignalTrack, "scaled:scale") <- NULL
  colnames(SignalTrack) <- covs

  # Copy number x bin weight.
  CopyTrack <- matrix(bin_width * pmax(rnorm(nbins * J, 1, 0.15), 0.1), nbins, J)
  colnames(CopyTrack) <- samples

  # Truth
  R <- matrix(rgamma(I * K, 0.3), I, K)
  R <- sweep(R, 2, colSums(R), "/")
  dimnames(R) <- list(channels, sprintf("SigN%02d", seq_len(K)))
  Betas <- matrix(rnorm(p * K, 0, 0.4), p, K, dimnames = list(covs, colnames(R)))
  Theta <- matrix(rgamma(K * J, 8, 8 / 400), K, J, dimnames = list(colnames(R), samples))

  # Intensity per bin: lambda_kj(b) = theta_kj * c_j(b) e^{beta_k'x(b)} / q_j(beta_k)
  EBS <- exp(pmin(pmax(SignalTrack %*% Betas, -20), 20))   # nbins x K
  Q <- crossprod(EBS, CopyTrack)                            # K x J

  rows <- list()
  for (j in seq_len(J)) {
    for (k in seq_len(K)) {
      rate <- Theta[k, j] * CopyTrack[, j] * EBS[, k] / Q[k, j]
      n <- rpois(nbins, rate)
      idx <- rep(seq_len(nbins), n)
      if (!length(idx)) next
      rows[[length(rows) + 1L]] <- data.frame(
        bin = idx,
        sample = samples[j],
        channel = channels[sample.int(I, length(idx), TRUE, prob = R[, k])],
        stringsAsFactors = FALSE)
    }
  }
  mut <- do.call(rbind, rows)
  mut <- mut[order(mut$sample, mut$bin), ]

  gr <- GRanges(seqnames = "chr1",
                ranges = IRanges(start = (mut$bin - 1L) * bin_width + 1L,
                                 width = 1L))
  mcols(gr) <- cbind(
    data.frame(sample = factor(mut$sample, levels = samples),
               channel = factor(mut$channel, levels = channels)),
    as.data.frame(SignalTrack[mut$bin, , drop = FALSE]))

  list(data = list(gr_Mutations = gr, SignalTrack = SignalTrack,
                   CopyTrack = CopyTrack),
       truth = list(R = R, Betas = Betas, Theta = Theta, Q = Q))
}

# A fresh directory under the session temp dir. Deliberately NOT built from
# runif(): simulate_ppf() calls set.seed(), so an RNG-derived name repeats across
# tests and two runs end up sharing a checkpoint. tempfile() is independent of
# the RNG stream.
new_ckpt_dir <- function() {
  d <- tempfile("ck-")
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  d
}
