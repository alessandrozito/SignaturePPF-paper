## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>",
                      fig.width = 8, fig.height = 4.2, fig.align = "center",
                      dpi = 110, out.width = "100%")

## ----setup--------------------------------------------------------------------
library(SignaturePPF)
suppressPackageStartupMessages({
  library(GenomicRanges)
  library(ggplot2)
})

## ----simulate-----------------------------------------------------------------
set.seed(1)
nbins <- 4000; J <- 8; bin_width <- 1000

truth_sigs  <- c("SBS1", "SBS2", "SBS13")
R           <- COSMIC_v3.4_SBS96_GRCh37[, truth_sigs]
channels    <- rownames(R)
samples     <- sprintf("S%02d", seq_len(J))
covs        <- c("H3K9me3", "RepliTime", "GC")

# Covariates. Real tracks are spatially correlated along the genome, so each is
# drawn as an AR(1) sequence over bins and then standardised, as the real tracks
# are after preprocessing.
ar1 <- function(n, rho) {
  as.numeric(stats::filter(rnorm(n, 0, sqrt(1 - rho^2)), rho,
                           method = "recursive", init = rnorm(1)))
}
SignalTrack <- scale(sapply(covs, function(nm) ar1(nbins, rho = 0.97)))
attributes(SignalTrack)[c("scaled:center", "scaled:scale")] <- NULL
colnames(SignalTrack) <- covs

# Copy number x bin width: the exposure c_j(t) the process integrates over.
CopyTrack <- matrix(bin_width * pmax(rnorm(nbins * J, 1, 0.15), 0.1),
                    nbins, J, dimnames = list(NULL, samples))

## ----truth--------------------------------------------------------------------
Betas <- matrix(c( 0.8, -0.5,  0.0,     # SBS1
                  -0.6,  0.4,  0.3,     # SBS2
                   0.0,  0.0, -0.7),    # SBS13
                nrow = length(covs), ncol = 3,
                dimnames = list(covs, truth_sigs))
Theta <- matrix(rgamma(3 * J, 8, 8 / 500), 3, J,
                dimnames = list(truth_sigs, samples))
round(Theta[, 1:4])

## ----draw---------------------------------------------------------------------
EBS <- exp(SignalTrack %*% Betas)      # bins x K
Q   <- crossprod(EBS, CopyTrack)       # K x J

rows <- list()
for (j in seq_len(J)) for (k in seq_len(3)) {
  n   <- rpois(nbins, Theta[k, j] * CopyTrack[, j] * EBS[, k] / Q[k, j])
  idx <- rep(seq_len(nbins), n)
  if (!length(idx)) next
  rows[[length(rows) + 1L]] <- data.frame(
    bin     = idx,
    sample  = samples[j],
    channel = channels[sample.int(nrow(R), length(idx), TRUE, prob = R[, k])])
}
mut <- do.call(rbind, rows)

## ----assemble-----------------------------------------------------------------
gr <- GRanges("chr1", IRanges((mut$bin - 1L) * bin_width + 1L, width = 1L))
mcols(gr) <- cbind(
  data.frame(sample  = factor(mut$sample,  levels = samples),
             channel = factor(mut$channel, levels = channels)),
  as.data.frame(SignalTrack[mut$bin, , drop = FALSE]))

data <- list(gr_Mutations = gr, SignalTrack = SignalTrack, CopyTrack = CopyTrack)
length(gr)

## ----motivation, fig.height = 3.1---------------------------------------------
win  <- 100                                  # 100 bins = 100 kb
grp  <- ceiling(seq_len(nbins) / win)
cnt  <- as.vector(table(factor(ceiling(mut$bin / win), levels = unique(grp))))
Xwin <- apply(SignalTrack, 2, function(z) tapply(z, grp, mean))

ggplot(data.frame(count     = rep(cnt, times = length(covs)),
                  value     = as.vector(Xwin),
                  covariate = rep(covs, each = length(cnt))),
       aes(value, count)) +
  geom_point(alpha = 0.5, size = 1, colour = "#2E6189") +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE,
              colour = "#B3312C", linewidth = 0.7) +
  facet_wrap(~ covariate) +
  labs(x = "covariate in 100 kb window (standardised)", y = "mutations") +
  theme_bw(base_size = 11)

## ----validate-----------------------------------------------------------------
v <- SignaturePPF_validate(data)
str(v[c("I", "J", "p", "N", "nbins")])

## ----denovo-------------------------------------------------------------------
fit <- SignaturePPF(data, K = 6, method = "map", seed = 1, verbose = FALSE)
fit <- prune_signatures(fit)
fit

## ----cosine-------------------------------------------------------------------
cosine <- function(a, b) sum(a * b) / sqrt(sum(a^2) * sum(b^2))
M <- outer(seq_len(3), seq_len(ncol(fit$Signatures)),
           Vectorize(function(i, j) cosine(R[, i], fit$Signatures[, j])))
dimnames(M) <- list(truth_sigs, colnames(fit$Signatures))
round(M, 3)

## ----betas--------------------------------------------------------------------
ord <- apply(M, 1, which.max)
round(Betas, 2)
round(fit$Betas[, ord], 2)

## ----plot-denovo, fig.height = 4.6--------------------------------------------
plot_Signatures(fit)

## ----plot-betas, fig.height = 2.8---------------------------------------------
plot_Betas(fit)

## ----lambda-------------------------------------------------------------------
lambda <- rowSums((exp(SignalTrack %*% fit$Betas) %*% fit$Baseline) * CopyTrack)
observed <- tabulate(mut$bin, nbins)

c(observed = sum(observed), fitted = round(sum(lambda), 1))

## ----track, fig.height = 3.2--------------------------------------------------
w    <- 50
grpw <- ceiling(seq_len(nbins) / w)
track <- data.frame(
  position = as.vector(tapply(seq_len(nbins), grpw, mean)) * bin_width / 1e6,
  observed = as.vector(tapply(observed, grpw, sum)),
  fitted   = as.vector(tapply(lambda,   grpw, sum)))

ggplot(track, aes(position)) +
  geom_point(aes(y = observed), shape = 21, size = 1.4, colour = "grey30") +
  geom_line(aes(y = fitted), colour = "#B3312C", linewidth = 0.7) +
  labs(x = "position on chr1 (Mb)", y = "mutations per 50 kb") +
  theme_bw(base_size = 11)

## ----track-cor----------------------------------------------------------------
round(cor(track$observed, track$fitted), 3)

## ----mcmc---------------------------------------------------------------------
fitm <- SignaturePPF(data, K = 6, method = "mcmc", seed = 1, verbose = FALSE,
                     init_mcmc_from_map = TRUE, prune_after_map = TRUE,
                     controls = SignaturePPF_control(nsamples = 2000,
                                                     burnin = 500, thin = 2))
fitm

## ----ci-----------------------------------------------------------------------
ci <- posterior_CI(fitm, "Betas")
round(ci$lowCI, 2)
round(ci$highCI, 2)

## ----plot-mcmc, fig.height = 2.8----------------------------------------------
plot_Betas(fitm)

## ----refit--------------------------------------------------------------------
sigs <- COSMIC_v3.4_SBS96_GRCh37[, c("SBS1", "SBS2", "SBS3", "SBS5", "SBS13")]
fitr <- SignaturePPF(data, sigs = sigs, method = "map", seed = 1, verbose = FALSE)
fitr

## ----assign-------------------------------------------------------------------
df_assign(fitr, data)

## ----plot-mu, fig.height = 3.4------------------------------------------------
plot_Mu(fitr, data)

## ----plot-theta, fig.height = 3.4---------------------------------------------
plot_Theta(fit)

