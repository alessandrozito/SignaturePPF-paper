// ============================================================================
// Gibbs sampler for the Poisson process factorization under the ACTIVITY prior,
// with the beta block replaced by ADAPTIVE GENERALIZED ELLIPTICAL SLICE SAMPLING
// (AGESS; Marco & Tokdar, arXiv:2605.21659).
//
// The MODEL is bit-for-bit the one in PoissonProcess_multiplicative_Bayes_activity_CN.cpp:
// same likelihood, same priors, same Gibbs blocks for W, R, theta, mu and sigma2.
// The ONLY thing that changes is how beta_k is drawn from its full conditional.
//
// ---------------------------------------------------------------------------
// 1. WHY THE CURRENT BETA STEP MIXES BADLY
// ---------------------------------------------------------------------------
// The existing sampler draws beta_k with vanilla elliptical slice sampling
// (Murray, Adams & MacKay 2010), which is exact whenever the target factorises as
//
//     pi(beta) prop  N(beta; 0, sigma2_k I)  *  L(beta),
//
// and the ellipse is generated from that Gaussian PRIOR. That is why the existing
// `logF` contains only the likelihood part
//
//     logF(beta) = - sum_j S_kj log q_j(beta) + (W'X)_k' beta,
//
// with the Gaussian prior deliberately absent: it is carried by the ellipse.
//
// The price is that the ellipse has the shape and the scale of the PRIOR. Here the
// prior is vastly more diffuse than the conditional posterior - millions of
// mutations informing p ~ 11 coefficients - and it is isotropic, while the genomic
// tracks are strongly correlated, so the posterior contours are elongated and
// tilted. Every proposal is therefore drawn from a hugely over-dispersed, wrongly
// oriented ellipse and is rejected until the bracket has shrunk almost to zero.
// The header of the activity sampler measures this directly: ~8.3 proposals per
// signature per iteration, i.e. ~7 shrinkages, and it identifies a preconditioned
// proposal as "where the next factor would come from".
//
// ---------------------------------------------------------------------------
// 2. WHAT AGESS DOES
// ---------------------------------------------------------------------------
// Generalized ESS (Nishihara, Murray & Adams 2014) removes the requirement that
// the ellipse be the prior. For ANY ellipse-generating density q one writes
//
//     pi(beta)  =  q(beta)  *  [ pi(beta) / q(beta) ],
//
// and runs the ordinary ESS transition with q in place of the prior and
// pi/q in place of the likelihood. The transition stays exact and REJECTION-FREE
// (no Metropolis ratio, no step size) for any fixed q. The slice functional
// therefore becomes
//
//     logF(beta) = [ -sum_j S_kj log q_j(beta) + (W'X)_k'beta          ]   (likelihood)
//                + [ -||beta||^2 / (2 sigma2_k)                        ]   (prior, now EXPLICIT)
//                - [ log q_ellipse(beta)                               ]   (correction)
//
// AGESS then LEARNS q on the fly: q_k = multivariate t with ellipse centre mu_k,
// scale Sigma_k and nu degrees of freedom, where (mu_k, Sigma_k) are the running
// mean and covariance of the beta_k chain itself. Ergodicity is preserved by the
// two devices of the paper, both implemented below:
//
//   (a) DIMINISHING ADAPTATION. The running moments are updated with weight
//       w_i = i^(-w_const), and are only PROMOTED into the live kernel at the
//       AirMCMC times N_J (Chimisov, Latuszynski & Roberts 2018), which thin out
//       like n^air_beta. Between promotions the kernel is a fixed, exactly
//       invariant GESS kernel.
//   (b) CONTAINMENT. A fraction eps_nonadapt of the iterations fall back to a FIXED
//       kernel that does not depend on the chain history.
//
// ---------------------------------------------------------------------------
// 3. TWO CHOICES SPECIFIC TO THIS MODEL
// ---------------------------------------------------------------------------
// (i) THE FALLBACK KERNEL IS THE EXISTING SAMPLER. The reference implementation
//     uses a t ellipse with user-supplied (mu_0, Sigma_0) for the eps-fraction.
//     Here the natural fixed kernel is the Gaussian PRIOR N(0, sigma2_k I) - and
//     if the ellipse is that prior, the two bracketed terms above cancel exactly,
//     the correction vanishes, and the step degenerates to the vanilla ESS step
//     of the activity sampler. So the containment kernel costs nothing to
//     implement, tracks the current sigma2_k for free, and is already validated.
//     A useful consequence: eps_nonadapt = 1 turns this file back into the
//     existing sampler, which is the A/B control for any timing comparison.
//
// (ii) THE t IS NOT OPTIONAL. With a GAUSSIAN adapted ellipse the correction term
//     would be + (beta-mu)' Sigma^{-1} (beta-mu) / 2. The whole point of adapting
//     is that Sigma is much tighter than sigma2_k I, so Sigma^{-1} >> I/sigma2_k
//     and that term would DOMINATE the -||beta||^2/(2 sigma2_k) of the prior: logF
//     would diverge to +infinity along the tails and the slice set would be
//     unbounded. This is not hypothetical here - the activity model is known to be
//     weakly identified in any direction where SignalTrack is near constant, where
//     the prior is the only thing keeping the target integrable. The t tails make
//     the correction grow only like (nu+p) log||beta||, which -||beta||^2 always
//     beats, so logF stays bounded above. The t is therefore hard-wired, not
//     exposed as a switch.
//
// Deliberately NOT ported: the one-dimensional warm-up iterations of the reference
// implementation. They are an accelerant for the first few hundred iterations in
// high dimensions, and they cost one full log-target evaluation PER COORDINATE.
// In the generic setting that is cheap; here a single log-target evaluation is a
// pass over CopyTrack (O(B*J), ~22 MFlop), so p iterations per signature would cost
// p*K = 132 passes for one iteration against the ~15 the whole beta block uses
// now. The cost model is inverted, so they are omitted; the eps-fraction prior
// kernel covers the same early-phase role.
//
// ---------------------------------------------------------------------------
// 4. SPEED
// ---------------------------------------------------------------------------
// The two structural optimizations of the activity sampler both survive intact.
//
//   * Hoisting. The ellipse is now centred at C rather than the origin,
//         beta(t) = C + (beta0 - C) cos t + (z - C) sin t,
//     which is still affine in (cos t, sin t), so
//         SignalTrack beta(t) = SC + SG0 cos t + SH sin t
//     with SC, SG0, SH formed once per iteration. Three B x K GEMMs instead of
//     the two the current code needs; the extra one is ~74 MFlop against ~270
//     MFlop for a single shrinkage round, i.e. under half a percent of the block.
//     (SC could be cached across iterations, since mu_k only moves at promotion
//     times - not worth the stale-cache hazard for 0.4%.)
//
//   * Batching. The target for beta_k still involves nothing from any other
//     signature, so the K slice updates remain conditionally independent given
//     W, S and sigma2 and are advanced in lockstep: one pass over CopyTrack per
//     shrinkage ROUND rather than per proposal. This is `beta_update = 2` of the
//     activity sampler, and it is the only mode here.
//
// The AGESS overhead itself is one p x p triangular solve per log-target
// evaluation plus one rank-1 covariance update per iteration, i.e. O(p^2) = ~121
// flops against ~22 MFlop for the term it is attached to. It is unmeasurable.
//
// The whole point is the SHRINKAGE COUNT, so it is returned: `SHRINKchain` holds
// the number of shrinkage rounds each signature needed at each iteration. If AGESS
// is doing its job that trace falls from ~7 towards ~1 once adaptation kicks in.
// `ADAPTchain` records which kernel was used, so the two can be told apart.
//
// ---------------------------------------------------------------------------
// 5. THE ONE THING TO BE AWARE OF
// ---------------------------------------------------------------------------
// This is adaptation on a component kernel INSIDE a Gibbs sampler, so the target
// of the beta_k block moves every iteration as W, S and sigma2 update. What the
// running moments converge to is therefore the MARGINAL posterior covariance of
// beta_k, which is at least as spread out as any of the conditionals - a
// conservative ellipse, but conservative by a small factor rather than by the
// orders of magnitude the prior is off by. The paper's ergodicity theory is
// stated for a fixed target; adaptive-within-Gibbs is the standard construction
// of Roberts & Rosenthal (2009) and the package already relies on it for the
// adaptive Metropolis block of the original sampler, so this adds no new
// exposure - but it is worth a sentence if this goes in a paper.
//
// Related: if signature labels ever switch during the run, the per-k moments
// become a mixture of two modes and the ellipse inflates. That makes the sampler
// SLOW, never wrong, and the eps-fraction prior kernel bounds how slow.
// ============================================================================
#include <RcppArmadillo.h>
#include <math.h>
#include <algorithm>
#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include "progress.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// Everything except the exported entry points lives here. The Gibbs helpers are
// duplicated from the activity sampler rather than shared: they are `inline` in
// that translation unit, so they cannot be forward-declared across files, and
// keeping this sampler self-contained means it can be modified without any risk
// to the sampler it is being compared against.
namespace agess_activity {

const double Q_FLOOR = 1e-300;   // guards log(q) if a patient has no copies

// ============================================================================
// PART I - Gibbs blocks. Identical to PoissonProcess_multiplicative_Bayes_activity_CN.cpp.
// ============================================================================

// ---------------------------------------------------------------- assignments
inline void update_Mutation_assignement(arma::mat &W, const arma::mat &Probs) {
  const arma::uword N = Probs.n_rows, K = Probs.n_cols;
  W.zeros();
  for (arma::uword i = 0; i < N; ++i) {
    double u = arma::randu();
    double acc = 0.0;
    arma::uword col = 0;
    for (; col < K; ++col) {
      acc += Probs(i, col);
      if (u < acc || col == K - 1) {
        W(i, col) = 1;
        break;
      }
    }
  }
}

// ----------------------------------------------------------------- signatures
inline void update_Signatures_R(arma::mat &R,
                                const arma::mat &W,
                                const arma::mat &SigPrior,
                                arma::mat &Alpha,
                                std::vector<arma::uvec> &channel_indices) {
  const arma::uword I = R.n_rows, K = R.n_cols;
  for (arma::uword i = 0; i < I; i++) {
    arma::uvec &idx = channel_indices[i];
    if (!idx.is_empty()) {
      Alpha.row(i) = arma::sum(W.rows(idx), 0);
    }
    for (arma::uword k = 0; k < K; k++) {
      R(i, k) = arma::randg(1, arma::distr_param(Alpha(i, k) + SigPrior(i, k), 1.0))(0);
    }
  }
  R = arma::normalise(R, 1, 0);
}

// ------------------------------------------------ S_kj = sum_i sum_n W_ijk(t)
inline void accumulate_S(arma::mat &Smat,
                         const arma::mat &W,
                         std::vector<arma::uvec> &sample_indices) {
  const arma::uword J = Smat.n_rows;
  for (arma::uword j = 0; j < J; j++) {
    arma::uvec &idx = sample_indices[j];
    if (!idx.is_empty()) {
      Smat.row(j) = arma::sum(W.rows(idx), 0);
    } else {
      Smat.row(j).zeros();
    }
  }
}

// ------------------------------------------------------------- activities
// theta_kj ~ Ga(a + S_kj, 1 + a/mu_k). Neither CopyTrack nor beta appears: the
// e^{beta'x} in the prior rate is exactly what cancels the compensator.
inline void update_Activities_Theta(arma::mat &Theta,
                                    const arma::mat &Smat,
                                    const arma::rowvec &Mu,
                                    double a) {
  const arma::uword J = Theta.n_rows, K = Theta.n_cols;
  for (arma::uword j = 0; j < J; j++) {
    for (arma::uword k = 0; k < K; k++) {
      Theta(j, k) = arma::randg(1, arma::distr_param(a + Smat(j, k),
                                1.0 / (1.0 + a / Mu(k))))(0);
    }
  }
}

// ------------------------------------------------------- relevance weights
inline void update_RelevanceWeights_Mu(arma::rowvec &Mu,
                                       const arma::mat &Theta,
                                       double a, double a0, double b0) {
  const arma::uword K = Theta.n_cols, J = Theta.n_rows;
  arma::rowvec rate = b0 + a * arma::sum(Theta, 0);
  for (arma::uword k = 0; k < K; k++) {
    Mu(k) = arma::randg(1, arma::distr_param(a0 + a * J, 1.0 / rate(k)))(0);
  }
  Mu = 1.0 / Mu;
}

// ------------------------------------------------------------------ variances
inline void update_Variances_Sigma2(arma::rowvec &Sigma2,
                                    const arma::mat &Betas,
                                    double c0, double d0) {
  const arma::uword K = Betas.n_cols;
  const double p = Betas.n_rows;
  arma::rowvec Betasq = arma::sum(arma::square(Betas), 0);
  for (arma::uword k = 0; k < K; k++) {
    Sigma2(k) = arma::randg(1, arma::distr_param(c0 + p / 2.0,
                            1.0 / (d0 + Betasq(k) / 2.0)))(0);
  }
  Sigma2 = 1.0 / Sigma2;
}

// ============================================================================
// PART II - AGESS machinery
// ============================================================================

// ----------------------------------------------------------------- controls
// Every field has a default taken from the reference implementation, and the two
// that depend on the dimension are derived rather than guessed (see make_controls).
struct AgessControls {
  double nu;             // degrees of freedom of the t ellipse
  double eps_nonadapt;   // probability of falling back to the fixed prior kernel
  double air_beta;       // AirMCMC exponent: promotion gaps grow like n_j^air_beta
  double w_const;        // adaptation weight exponent: w_i = i^(-w_const)
  arma::uword adapt_start;   // iteration of the FIRST promotion
  double ridge_rel;      // relative jitter used if the running covariance is singular
};

inline AgessControls make_controls(int p,
                                   double nu,
                                   double eps_nonadapt,
                                   double air_beta,
                                   double w_const,
                                   int adapt_start,
                                   double ridge_rel) {
  AgessControls c;
  c.nu = nu;
  c.eps_nonadapt = eps_nonadapt;
  c.air_beta = air_beta;
  c.ridge_rel = ridge_rel;

  // w_const: the reference implementation's max(2/3, (p^{1/3}-1)/p^{1/3}). For
  // the dimensions this model runs at (p ~ 5-30) the first branch always wins,
  // so w_i = i^{-2/3} in practice. Pass w_const > 0 to override.
  const double cp = std::cbrt((double)p);
  c.w_const = (w_const > 0.0) ? w_const : std::max(2.0 / 3.0, (cp - 1.0) / cp);

  // adapt_start: the reference implementation promotes for the first time at
  // iteration 2, which in dimension p leaves the running covariance rank 2 and
  // therefore singular. It gets away with it because it carries the Cholesky
  // factor itself through rank-1 updates; here the factorisation is recomputed
  // at promotion time, so a rank-deficient candidate has to be refused outright.
  // Rather than lean on the refusal, the first promotion is delayed until the
  // running covariance has accumulated enough effective terms to be full rank.
  //
  // The recursion Sigma <- (1-w_i) Sigma + w_i (x-mu)(x-mu)' with w_i = i^{-w_const}
  // has an effective sample size of about 1/w_i = i^{w_const}, so requiring
  // i^{w_const} >= 2p + 2 gives i >= (2p+2)^{1/w_const}. At p = 11, w_const = 2/3
  // that is 24^{1.5} ~ 118 iterations. Pass adapt_start > 0 to override.
  if (adapt_start > 0) {
    c.adapt_start = (arma::uword) adapt_start;
  } else {
    c.adapt_start = (arma::uword) std::max(
      50.0, std::ceil(std::pow(2.0 * (double)p + 2.0, 1.0 / c.w_const)));
  }
  return c;
}

// -------------------------------------------------------------------- state
// One adapted t ellipse per signature. Two copies of the moments are kept: the
// RUNNING ones, updated every iteration, and the LIVE ones, which the sampler
// actually uses and which only change at the AirMCMC promotion times. That split
// is what makes the kernel a fixed, exactly invariant kernel between promotions.
struct AgessState {
  arma::mat  Mu_adapt;    // p x K     - live ellipse centres
  arma::cube L_adapt;     // p x p x K - live lower Cholesky factors of the scales
  arma::mat  Mu_run;      // p x K     - running mean
  arma::cube Sigma_run;   // p x p x K - running covariance
  arma::uvec ready;       // K         - 1 once signature k has been promoted once
  arma::uword iter;       // adaptation counter
  arma::uword n_j;        // AirMCMC promotion index
  arma::uword N_J;        // next promotion time
};

inline AgessState init_state(const arma::mat &Betas0,
                             const arma::rowvec &Sigma2,
                             const AgessControls &ctl) {
  const arma::uword p = Betas0.n_rows, K = Betas0.n_cols;
  AgessState st;
  st.Mu_adapt = Betas0;
  st.Mu_run   = Betas0;
  st.L_adapt.set_size(p, p, K);
  st.Sigma_run.set_size(p, p, K);
  const arma::mat Ip = arma::eye(p, p);
  for (arma::uword k = 0; k < K; ++k) {
    // Seeded at the prior, which is also what the fallback kernel uses, so the
    // live ellipse is never worse than the current sampler's even before the
    // first promotion. (`ready` is 0 until then, so it is not used yet either.)
    st.L_adapt.slice(k)   = std::sqrt(Sigma2(k)) * Ip;
    st.Sigma_run.slice(k) = Sigma2(k) * Ip;
  }
  st.ready.zeros(K);
  st.iter = 0;
  st.n_j  = 2;                 // reference implementation's starting index
  st.N_J  = ctl.adapt_start;   // ... but the first promotion is delayed
  return st;
}

// ------------------------------------------------------ state (de)serialisation
// A long run is executed as a sequence of blocks so that it can be checkpointed
// and resumed (see SignaturePPF_checkpoint). Resuming has to be EXACT, and the
// parameters alone are not the whole state of this sampler: the live ellipses,
// the running moments and the AirMCMC promotion counters all persist across
// iterations. Restarting a block with a fresh AgessState would silently rewind the
// adaptation - the chain would still target the right posterior, but it would
// not be the chain an uninterrupted run produces, and the resume test would fail.
//
// So the whole struct crosses the R boundary. `Sigma_run` is carried as the
// covariance and `L_adapt` as the Cholesky factor, i.e. exactly the two forms
// held internally, so a round trip is lossless rather than a re-factorisation.
inline List state_to_list(const AgessState &st) {
  return List::create(_["Mu_adapt"]  = st.Mu_adapt,
                      _["L_adapt"]   = st.L_adapt,
                      _["Mu_run"]    = st.Mu_run,
                      _["Sigma_run"] = st.Sigma_run,
                      _["ready"]     = st.ready,
                      _["iter"]      = (double) st.iter,
                      _["n_j"]       = (double) st.n_j,
                      _["N_J"]       = (double) st.N_J);
}

inline AgessState state_from_list(const List &L) {
  AgessState st;
  st.Mu_adapt  = as<arma::mat>(L["Mu_adapt"]);
  st.L_adapt   = as<arma::cube>(L["L_adapt"]);
  st.Mu_run    = as<arma::mat>(L["Mu_run"]);
  st.Sigma_run = as<arma::cube>(L["Sigma_run"]);
  st.ready     = as<arma::uvec>(L["ready"]);
  st.iter      = (arma::uword) as<double>(L["iter"]);
  st.n_j       = (arma::uword) as<double>(L["n_j"]);
  st.N_J       = (arma::uword) as<double>(L["N_J"]);
  return st;
}

// ------------------------------------------------- running moments + promotion
// Called once per Gibbs iteration, AFTER beta has been updated, on the new state.
inline void agess_adapt(AgessState &st,
                        const arma::mat &Betas,
                        const AgessControls &ctl) {
  const arma::uword p = Betas.n_rows, K = Betas.n_cols;

  st.iter += 1;
  const double w = std::pow((double) st.iter, -ctl.w_const);

  for (arma::uword k = 0; k < K; ++k) {
    // Sigma <- (1-w) Sigma + w (x - mu_old)(x - mu_old)', then mu <- (1-w) mu + w x.
    // The covariance uses the OLD mean, exactly as in the reference implementation.
    const arma::vec d = Betas.col(k) - st.Mu_run.col(k);
    st.Sigma_run.slice(k) *= (1.0 - w);
    st.Sigma_run.slice(k) += w * (d * d.t());
    st.Mu_run.col(k)      += w * d;
  }

  if (st.iter < st.N_J) return;

  // ---- promotion: the running moments become the live ellipse ----
  for (arma::uword k = 0; k < K; ++k) {
    arma::mat S = st.Sigma_run.slice(k);
    S = 0.5 * (S + S.t());                       // symmetrise away rounding drift
    const double scale = arma::trace(S) / (double) p;

    // Try an unjittered factorisation first; only fall back to a ridge if the
    // candidate is numerically indefinite. If even the ridged version fails, the
    // signature simply keeps its previous live ellipse - refusing a promotion is
    // always safe, since any FIXED ellipse leaves the target invariant.
    arma::mat L;
    bool ok = arma::chol(L, S, "lower");
    double jit = ctl.ridge_rel * std::max(scale, 1e-300);
    for (int attempt = 0; attempt < 4 && !ok; ++attempt) {
      ok = arma::chol(L, S + jit * arma::eye(p, p), "lower");
      jit *= 100.0;
    }
    if (ok) {
      st.L_adapt.slice(k)  = L;
      st.Mu_adapt.col(k)   = st.Mu_run.col(k);
      st.ready(k)          = 1;
    }
  }

  // AirMCMC schedule: gaps grow like n_j^air_beta, so with air_beta = 0.5 the
  // number of promotions in n iterations is O(n^{2/3}) and the adaptation
  // diminishes at the rate the theory needs.
  st.n_j += 1;
  st.N_J += std::max<arma::uword>(
    1, (arma::uword) std::floor(std::pow((double) st.n_j, ctl.air_beta)));
}

// ============================ elliptical slice ==============================
// Batched AGESS update of all K coefficient vectors.
//
// Per signature the kernel is chosen first (adaptive t, or the fixed prior
// Gaussian with probability eps_nonadapt), and both choices share the SAME
// geometry - centre C_k, second ellipse point Z_k, and a per-signature additive
// correction to the slice functional - so they can be advanced in one batched
// loop regardless of which signature drew which kernel.
inline void update_Betas_AGESS(arma::mat &Betas,
                               const arma::mat &WtX,
                               const arma::rowvec &Sigma2,
                               const arma::mat &Smat,
                               const arma::mat &SignalTrack,
                               const arma::mat &CopyTrack,
                               const AgessState &st,
                               const AgessControls &ctl,
                               arma::rowvec &shrink,
                               arma::rowvec &adaptive_used) {
  const arma::uword K = Betas.n_cols, p = Betas.n_rows, B = SignalTrack.n_rows;
  const double nu       = ctl.nu;
  const double nu_tilde = nu + (double) p;
  const double half_nu_p = 0.5 * nu_tilde;

  const arma::mat Beta0 = Betas;

  arma::mat  C(p, K, arma::fill::zeros);   // ellipse centre  (mu_k, or 0 for the prior kernel)
  arma::mat  Z(p, K);                      // second ellipse point
  arma::uvec use_adapt(K, arma::fill::zeros);

  // ---- 1. pick a kernel per signature and draw its ellipse ----
  for (arma::uword k = 0; k < K; ++k) {
    const bool adapt_k = (st.ready(k) == 1) &&
      (arma::as_scalar(arma::randu(1)) > ctl.eps_nonadapt);
    use_adapt(k) = adapt_k ? 1 : 0;

    if (adapt_k) {
      C.col(k) = st.Mu_adapt.col(k);
      const arma::mat &L = st.L_adapt.slice(k);

      // For a t ellipse the second point is NOT drawn marginally: it is drawn
      // from the conditional that makes (beta0, z) exchangeable under
      // t_nu(mu, Sigma), which is  z | beta0 ~ t_{nu+p}( mu, ((nu+d0)/(nu+p)) Sigma )
      // with d0 the squared Mahalanobis distance of beta0 (Nishihara et al. 2014).
      // Sampling that as a Gaussian scale mixture: N(0, Sigma) divided by the
      // square root of a mean-one Gamma(nu_tilde/2, 2/nu_tilde).
      const arma::vec r0 = arma::solve(arma::trimatl(L), Beta0.col(k) - C.col(k));
      const double d0 = arma::dot(r0, r0);
      const double g  = arma::randg(1, arma::distr_param(half_nu_p, 2.0 / nu_tilde))(0);
      const double s  = std::sqrt((nu + d0) / nu_tilde) / std::sqrt(g);
      Z.col(k) = C.col(k) + s * (L * arma::randn<arma::vec>(p));
    } else {
      // Containment kernel: the prior ellipse, i.e. exactly the current sampler.
      // C stays at the origin.
      Z.col(k) = arma::randn<arma::vec>(p) * std::sqrt(Sigma2(k));
    }
    adaptive_used(k) = (double) use_adapt(k);
  }

  // ---- 2. the per-signature correction to the slice functional ----
  // Adaptive kernel: add back the Gaussian prior that the ellipse no longer
  // carries, and subtract the log density of the t ellipse (normalising
  // constants drop out of the slice, so only the kernel of the t is needed).
  // Prior kernel: the two terms cancel identically and the correction is zero -
  // which is why that branch reproduces the existing sampler exactly.
  auto correction = [&](arma::uword k, const arma::vec &beta) -> double {
    if (use_adapt(k) == 0) return 0.0;
    const arma::vec r = arma::solve(arma::trimatl(st.L_adapt.slice(k)),
                                    beta - st.Mu_adapt.col(k));
    return -arma::dot(beta, beta) / (2.0 * Sigma2(k))
           + half_nu_p * std::log1p(arma::dot(r, r) / nu);
  };

  // ---- 3. hoist the ellipse out of the shrinkage loop ----
  // beta(t) = C + G0 cos t + H sin t, so SignalTrack beta(t) = SC + SG0 cos t + SH sin t.
  // t = 0 recovers beta0 and t = pi/2 recovers z, as it must.
  const arma::mat G0 = Beta0 - C;
  const arma::mat H  = Z - C;
  // If every signature drew the prior kernel this iteration then C is identically
  // zero, and the third GEMM is pure waste - which matters because that is
  // exactly the configuration used as the non-adaptive timing baseline.
  const bool any_adapt = arma::any(use_adapt == 1);
  const arma::mat SC  = any_adapt ? arma::mat(SignalTrack * C)
                                  : arma::mat(B, K, arma::fill::zeros);
  const arma::mat SG0 = SignalTrack * G0;    // B x K, one GEMM
  const arma::mat SH  = SignalTrack * H;     // B x K, one GEMM

  arma::vec logy(K), theta(K), theta_min(K), theta_max(K);
  for (arma::uword k = 0; k < K; ++k) {
    logy(k)      = std::log(arma::as_scalar(arma::randu(1)));  // logF0 added below
    theta(k)     = 2 * M_PI * arma::as_scalar(arma::randu(1));
    theta_min(k) = theta(k) - 2.0 * M_PI;
    theta_max(k) = theta(k);
  }

  // ---- 4. slice level for every signature: one pass over CopyTrack for all ----
  arma::mat Q0 = CopyTrack.t() * arma::exp(arma::clamp(SC + SG0, -20, 20));  // J x K
  for (arma::uword k = 0; k < K; ++k) {
    logy(k) += -arma::dot(Smat.col(k),
                          arma::log(arma::clamp(Q0.col(k), Q_FLOOR, arma::datum::inf)))
             + arma::as_scalar(WtX.row(k) * Beta0.col(k))
             + correction(k, Beta0.col(k));
  }

  // ---- 5. batched shrinkage ----
  // Every signature still looking for a point is evaluated in the same pass over
  // CopyTrack, so the cost is 1 + max_k shrinks_k passes rather than
  // sum_k (1 + shrinks_k). Each beta_k is still drawn from its own exact full
  // conditional with its own randomness; only the interleaving differs.
  shrink.zeros();
  arma::uvec active = arma::regspace<arma::uvec>(0, K - 1);
  arma::mat  Prop(p, K);
  const int max_iter = 1000;
  for (int r = 0; r < max_iter && !active.is_empty(); ++r) {
    const arma::uword A = active.n_elem;
    arma::mat V(B, A);
    for (arma::uword m = 0; m < A; ++m) {
      const arma::uword k = active(m);
      const double ct = std::cos(theta(k)), stn = std::sin(theta(k));
      Prop.col(k) = C.col(k) + G0.col(k) * ct + H.col(k) * stn;
      V.col(m) = arma::exp(arma::clamp(SC.col(k) + SG0.col(k) * ct + SH.col(k) * stn,
                                       -20, 20));
    }
    arma::mat Q = CopyTrack.t() * V;                  // J x A, one pass
    std::vector<arma::uword> still;
    still.reserve(A);
    for (arma::uword m = 0; m < A; ++m) {
      const arma::uword k = active(m);
      const double logF =
        -arma::dot(Smat.col(k),
                   arma::log(arma::clamp(Q.col(m), Q_FLOOR, arma::datum::inf)))
        + arma::as_scalar(WtX.row(k) * Prop.col(k))
        + correction(k, Prop.col(k));
      if (logF > logy(k)) {
        Betas.col(k) = Prop.col(k);
        shrink(k) = (double) r;
      } else {
        if (theta(k) < 0) theta_min(k) = theta(k); else theta_max(k) = theta(k);
        theta(k) = arma::as_scalar(arma::randu(1)) * (theta_max(k) - theta_min(k)) +
          theta_min(k);
        still.push_back(k);
      }
    }
    active.set_size(still.size());
    for (std::size_t i = 0; i < still.size(); ++i) active(i) = still[i];
  }
  if (!active.is_empty()) {
    // Signatures still in `active` keep their incoming value, as in the
    // non-adaptive sampler.
    for (arma::uword m = 0; m < active.n_elem; ++m) shrink(active(m)) = (double) max_iter;
    Rcpp::Rcout << "Warning: AGESS did not accept in max_iter\n";
  }
}

} // namespace agess_activity


// ---------------------------------------------------------------------------
// Full sampler. Argument list matches .PoissonProcess_BayesActivityCN, minus
// `beta_update` (AGESS is always batched) and plus the AGESS controls, all of
// which default to the values in the reference implementation or to a rule
// derived from p - nothing here needs to be tuned to run it.
// ---------------------------------------------------------------------------
// [[Rcpp::export(.PoissonProcess_BayesActivityAGESS_CN)]]
List PoissonProcess_BayesActivityAGESS_CN(arma::mat &R_start,
                                          arma::mat &Theta_start,
                                          arma::mat &Betas_start,
                                          arma::rowvec &Mu_start,
                                          arma::rowvec &Sigma2_start,
                                          arma::mat &X,
                                          arma::mat &SignalTrack,
                                          arma::mat &CopyTrack,
                                          int nsamples,
                                          int burn_in,
                                          arma::uvec channel_id,
                                          arma::uvec sample_id,
                                          arma::mat SigPrior,
                                          bool update_R = true,
                                          bool update_Theta = true,
                                          bool update_Betas = true,
                                          double a = 1.1,
                                          double a0 = 2.5,
                                          double b0 = 1.5,
                                          double c0 = 100,
                                          double d0 = 1,
                                          double nu = 6.0,
                                          double eps_nonadapt = 0.05,
                                          double air_beta = 0.5,
                                          double w_const = -1.0,
                                          int adapt_start = -1,
                                          double ridge_rel = 1e-8,
                                          bool reuse_probs = true,
                                          int logpost_every = 10,
                                          int thin = 1,
                                          double iter_offset = 0,
                                          double total_all = 0,
                                          int print_every = 10,
                                          bool use_cr = true,
                                          double elapsed_offset = 0,
                                          Nullable<List> agess_state = R_NilValue,
                                          bool verbose = false) {
  using namespace agess_activity;

  // Model dimensions
  const int I = R_start.n_rows;        // mutational channels
  const int J = Theta_start.n_cols;    // patients
  const int K = Theta_start.n_rows;    // signatures
  const int p = Betas_start.n_rows;    // covariates
  const int N = X.n_rows;              // mutations

  if (thin < 1) thin = 1;
  // Only every thin-th iteration is retained. `nsamples` always counts ITERATIONS, so a
  // block is a whole number of thinning cycles and the stored draws of
  // consecutive blocks concatenate without a gap or a duplicate at the seam.
  const arma::uword n_store = (arma::uword) (nsamples / thin);

  // Storage
  arma::cube BETAS(n_store, p, K);
  arma::cube THETAS(n_store, K, J);
  arma::cube SIGS(n_store, I, K);
  arma::mat MU(n_store, K);
  arma::mat SIGMA(n_store, K);
  arma::vec LP(n_store);
  arma::vec LLik(n_store);
  arma::vec LPrior(n_store);
  // AGESS diagnostics: shrinkage rounds needed, and which kernel was used.
  arma::mat SHRINK(n_store, K, arma::fill::zeros);
  arma::mat ADAPT(n_store, K, arma::fill::zeros);

  // Starting values. Theta is TOTAL activity here, transposed to J x K once.
  arma::mat R = R_start;
  arma::mat Theta = Theta_start.t();
  arma::mat Betas = Betas_start;
  arma::rowvec Mu = Mu_start;
  arma::rowvec Sigma2 = Sigma2_start;
  arma::mat W(N, K, arma::fill::zeros);
  arma::mat bigProd(N, K);

  // Ancillary quantities
  arma::mat Probs(N, K, arma::fill::zeros);
  arma::mat Alpha(I, K, arma::fill::zeros);
  arma::mat Smat(J, K, arma::fill::zeros);
  arma::mat WtX = W.t() * X;

  // AGESS controls and per-signature adapted ellipses
  const AgessControls ctl = make_controls(p, nu, eps_nonadapt, air_beta,
                                          w_const, adapt_start, ridge_rel);
  // Resuming a checkpoint restores the adaptation exactly where the previous
  // block left it; a fresh run seeds it from the starting values.
  AgessState st = agess_state.isNotNull()
    ? state_from_list(List(agess_state))
    : init_state(Betas, Sigma2, ctl);
  arma::rowvec shrink(K, arma::fill::zeros), adaptive_used(K, arma::fill::zeros);

  if (verbose && iter_offset == 0) {
    Rcout << "AGESS: nu = " << ctl.nu
          << ", eps_nonadapt = " << ctl.eps_nonadapt
          << ", w_const = " << ctl.w_const
          << ", air_beta = " << ctl.air_beta
          << ", first promotion at iteration " << ctl.adapt_start << "\n";
  }

  // Mean responses. Qmat(j, k) = q_j(beta_k); Phi = Theta / Qmat is the baseline
  // on the old scale, and is what the assignment probabilities need.
  arma::mat Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
  arma::mat ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
  arma::mat Qmat = CopyTrack.t() * ExpBetaSignal;
  arma::mat Phi = Theta / Qmat;

  // Seed bigProd from the starting values, so the first iteration sees the same
  // Probs whether or not reuse_probs is on.
  bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);

  // Index sets
  std::vector<arma::uvec> channel_indices(I);
  for (arma::uword i = 0; i < (arma::uword)I; ++i) channel_indices[i] = arma::find(channel_id == i);
  std::vector<arma::uvec> sample_indices(J);
  for (arma::uword j = 0; j < (arma::uword)J; ++j) sample_indices[j] = arma::find(sample_id == j);

  signatureppf::ProgressReporter progress("MCMC (agess)", (arma::uword) nsamples,
                                          (arma::uword) iter_offset,
                                          (arma::uword) total_all,
                                          verbose ? print_every : 0, use_cr,
                                          elapsed_offset);

  arma::uword s = 0;   // index of the next stored draw
  for (arma::uword iter = 0; iter < (arma::uword)nsamples; iter++) {

    // STEP 1 - latent categorical assignment for each mutation
    if (!reuse_probs) {
      bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
    }
    Probs = arma::normalise(bigProd + arma::datum::eps / 30, 1, 1);
    update_Mutation_assignement(W, Probs);

    // Aggregate the assignments once: both the Theta step and the beta target
    // need S_kj.
    accumulate_S(Smat, W, sample_indices);

    // STEP 2 - signatures
    if (update_R) update_Signatures_R(R, W, SigPrior, Alpha, channel_indices);

    // STEP 3 - activities and relevance weights
    if (update_Theta) {
      update_Activities_Theta(Theta, Smat, Mu, a);
      update_RelevanceWeights_Mu(Mu, Theta, a, a0, b0);
    }

    // STEP 4 - regression coefficients and their variances, via AGESS
    if (update_Betas) {
      WtX = W.t() * X;
      update_Betas_AGESS(Betas, WtX, Sigma2, Smat, SignalTrack, CopyTrack,
                         st, ctl, shrink, adaptive_used);
      // Adaptation is fed the NEW state, and happens after the draw so that the
      // kernel used within a iteration is fixed. It is deliberately not switched off
      // after burn-in: diminishing adaptation is what makes running it throughout
      // legitimate, and the marginal moments keep improving.
      agess_adapt(st, Betas, ctl);

      Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
      ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
      Qmat = CopyTrack.t() * ExpBetaSignal;
      update_Variances_Sigma2(Sigma2, Betas, c0, d0);
    }

    // Phi must be refreshed after either Theta or Betas moved.
    Phi = Theta / Qmat;

    // Thinning and the log-posterior grid are anchored to the RUN, not to the
    // checkpoint block, so that the draws of consecutive blocks concatenate into
    // exactly the sequence an uninterrupted run of the same length would store.
    const arma::uword global = (arma::uword) iter_offset + iter;
    const bool store = (((iter + 1) % (arma::uword) thin) == 0);

    // The log posterior is a diagnostic and never feeds back into an update, so
    // evaluating it every logpost_every-th iteration only subsamples the trace.
    // There is no reason to spend it on a iteration that is about to be discarded by
    // thinning, so it is only ever evaluated on a stored iteration.
    const bool eval_logpost = store &&
      ((logpost_every <= 1) || (((global + 1) % (arma::uword) logpost_every) == 0));
    if (reuse_probs || eval_logpost) {
      bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
    }

    double logLik = arma::datum::nan, logPrior = arma::datum::nan,
           logPost = arma::datum::nan;
    if (eval_logpost) {
      // The compensator is just the sum of the activities.
      logLik = arma::accu(arma::log(arma::sum(bigProd, 1))) - arma::accu(Theta);

      logPrior = arma::accu((SigPrior - 1) % arma::log(R)) +               // Dirichlet over signatures
        arma::accu((a - 1) * arma::log(Theta)) -
        a * arma::accu(arma::sum(Theta, 0) / Mu) -
        arma::accu(a * J * arma::log(Mu)) +                                // Gamma over activities
        arma::accu(- (a0 + 1) * arma::log(Mu) - b0 / Mu) +                 // InvGamma over mu
        arma::accu(- (c0 + 1 + p / 2.0) * arma::log(Sigma2) - d0 / Sigma2) + // InvGamma over sigma2
        arma::accu(- (0.5 / Sigma2) % arma::sum(arma::square(Betas), 0));  // Normal over betas

      logPost = logPrior + logLik;
    }

    if (store) {
      BETAS.row(s) = Betas;
      THETAS.row(s) = Theta.t();
      SIGS.row(s) = R;
      MU.row(s) = Mu;
      SIGMA.row(s) = Sigma2;
      SHRINK.row(s) = shrink;
      ADAPT.row(s) = adaptive_used;
      LPrior(s) = logPrior;
      LLik(s) = logLik;
      LP(s) = logPost;
      ++s;
    }

    progress.tick(iter, logPost);
  }
  progress.finish();

  // Learned ellipses, for inspection: Sigma_adapt.slice(k) should end up close to
  // the empirical posterior covariance of BETASchain[, , k].
  arma::cube Sigma_adapt(p, p, K);
  for (arma::uword k = 0; k < (arma::uword)K; ++k) {
    Sigma_adapt.slice(k) = st.L_adapt.slice(k) * st.L_adapt.slice(k).t();
  }

  return List::create(_["SIGSchain"] = SIGS,
                      _["THETAchain"] = THETAS,
                      _["BETASchain"] = BETAS,
                      _["MUchain"] = MU,
                      _["SIGMA2chain"] = SIGMA,
                      _["logPostchain"] = LP,
                      _["logLikchain"] = LLik,
                      _["logPriorchain"] = LPrior,
                      _["SHRINKchain"] = SHRINK,
                      _["ADAPTchain"] = ADAPT,
                      _["Mu_adapt"] = st.Mu_adapt,
                      _["Sigma_adapt"] = Sigma_adapt,
                      // Everything needed to continue this chain in a further
                      // call: the parameters at the last iteration (which are NOT
                      // recoverable from the chain once thin > 1) and the full
                      // adaptation state.
                      _["last"] = List::create(_["R"] = R,
                                               _["Theta"] = Theta.t(),
                                               _["Betas"] = Betas,
                                               _["Mu"] = Mu,
                                               _["Sigma2"] = Sigma2),
                      _["agess_state"] = state_to_list(st),
                      _["agess_controls"] = List::create(
                          _["nu"] = ctl.nu,
                          _["eps_nonadapt"] = ctl.eps_nonadapt,
                          _["air_beta"] = ctl.air_beta,
                          _["w_const"] = ctl.w_const,
                          _["adapt_start"] = (int) ctl.adapt_start,
                          _["ridge_rel"] = ctl.ridge_rel));
}
