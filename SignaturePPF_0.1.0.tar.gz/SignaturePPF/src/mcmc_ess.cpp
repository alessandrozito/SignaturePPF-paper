// ============================================================================
// Gibbs sampler for the Poisson process factorization under the ACTIVITY prior.
//
// The only change to the model is the rate of the Gamma prior on the baseline:
//
//   OLD   phi_kj | mu_k ~ Ga( a , (a/mu_k) * int 1/2 c_j(t) dt )
//   NEW   phi_kj | mu_k ~ Ga( a , (a/mu_k) * int 1/2 c_j(t) e^{beta_k'x(t)} dt )
//                                                    ^^^^^^^^^^^^^^^^^^^^
//
// Writing q_j(beta_k) = int 1/2 c_j(t) e^{beta_k'x(t)} dt and reparametrising by
// the TOTAL activity
//
//   theta_kj = phi_kj * q_j(beta_k),
//
// the new prior becomes theta_kj | mu_k ~ Ga(a, a/mu_k), free of beta. Since the
// expected number of signature-k mutations in patient j is exactly phi_kj q_j =
// theta_kj, the likelihood's compensator collapses to sum_kj theta_kj and the
// sampler simplifies:
//
//   * theta_kj | ... ~ Ga(a + S_kj, 1 + a/mu_k)          - no q, no CopyTrack
//   * mu_k    | ... ~ InvGa(a0 + aJ, b0 + a sum_j theta_kj)
//   * beta_k  | ... has target
//        log f(beta_k) = - sum_j S_kj log q_j(beta_k)
//                        + sum_ijn W_ijk beta_k'x(t_ijn)  + log N(beta_k;0,sigma2_k)
//
// and the mutation-assignment probabilities use phi_kj = theta_kj / q_j(beta_k).
//
// -------------------------------- speed ------------------------------------
// The old sampler could collapse the whole per-patient contraction in the
// elliptical slice step into a single dot product, because sum_j theta_jk q_j(b)
// is LINEAR in q: sum_j theta_jk (C'v)_j = (C theta_k)'v. That is what made the
// step ~7x faster. Here the target needs log q_j SEPARATELY for each patient, so
// that reassociation is NOT available: the J-vector q(beta) = C'v has to be
// formed on every slice proposal. What is available instead:
//
//   (i)  the ellipse is linear in the exponent, so
//          SignalTrack (beta0 cos t + nu sin t) = cos t (SignalTrack beta0)
//                                               + sin t (SignalTrack nu),
//        and both are hoisted out of the shrinkage loop;
//   (ii) the target for beta_k involves no other signature, so the K slice
//        updates are conditionally independent given W, S and sigma2 and can be
//        advanced in lockstep - one pass over CopyTrack per shrinkage ROUND
//        instead of one per proposal (`beta_update = 2`, the default);
//   (iii) patients with S_kj = 0 drop out of sum_j S_kj log q_j, so the
//        contraction can skip them - though on real data every signature is
//        active in every patient, so this buys nothing there;
//   (iv) reuse_probs and logpost_every, exactly as in the original sampler.
//
// Measured at -O2 on the 80 breast cancer data (278,763 bins, J = 80, K = 12,
// p = 11), per iteration: (ii) cuts the number of CopyTrack passes from 100 to
// 14.6 and the beta step from 0.939 s to 0.492 s, i.e. 1.91x, taking the whole
// iteration from 1.084 s to 0.637 s. Everything other than the beta step costs
// 0.145 s, so the sampler remains beta-dominated.
//
// The gain is 1.9x rather than the ~7x the pass count suggests because batching
// removes CopyTrack traffic but not the exp() calls, of which there is one per
// bin per PROPOSAL (~28e6 per iteration) and whose count is unchanged. Those
// 100 proposals are ~8.3 per signature, i.e. ~7 slice shrinkages each: the
// prior on beta is far wider than its conditional posterior. Reducing that
// count - a preconditioned proposal - is where the next factor would come from,
// not from more restructuring of the contraction.
//
// For reference, the ORIGINAL sampler with its reassociated slice step costs
// 0.521 s per iteration on the same data, so despite losing reassociation
// entirely this one runs at 1.22x its cost.
//
// (Note when re-timing: devtools::load_all() compiles at -O0, which inflates
// the Armadillo element-wise work relative to the BLAS calls and understates
// the batching. Time an -O2 install.)
//
// CopyTrack is used untransposed so that q(beta) = CopyTrack.t() * v dispatches
// to a transposed GEMV/GEMM without ever materialising the transpose, and so
// that the per-patient dot products run down contiguous columns.
// ============================================================================
#include <RcppArmadillo.h>
#include <math.h>
#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include "progress.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// Everything except the exported entry point lives here, so that no symbol
// collides with the identically-named helpers of the original sampler.
namespace activity_prior {

const double Q_FLOOR = 1e-300;   // guards log(q) if a patient has no copies

// ---------------------------------------------------------------- assignments
inline void update_Mutation_assignement(arma::mat &W, const arma::mat &Probs) {
  const arma::uword N = Probs.n_rows, K = Probs.n_cols;
  W.zeros();
  for (arma::uword i = 0; i < N; ++i) {
    double u = arma::randu();
    double acc = 0.0;
    arma::uword col = 0;
    for (; col < K; ++col) {
      acc += Probs(i, col);
      if (u < acc || col == K - 1) {
        W(i, col) = 1;
        break;
      }
    }
  }
}

// ----------------------------------------------------------------- signatures
inline void update_Signatures_R(arma::mat &R,
                                const arma::mat &W,
                                const arma::mat &SigPrior,
                                arma::mat &Alpha,
                                std::vector<arma::uvec> &channel_indices) {
  const arma::uword I = R.n_rows, K = R.n_cols;
  for (arma::uword i = 0; i < I; i++) {
    arma::uvec &idx = channel_indices[i];
    if (!idx.is_empty()) {
      Alpha.row(i) = arma::sum(W.rows(idx), 0);
    }
    for (arma::uword k = 0; k < K; k++) {
      R(i, k) = arma::randg(1, arma::distr_param(Alpha(i, k) + SigPrior(i, k), 1.0))(0);
    }
  }
  R = arma::normalise(R, 1, 0);
}

// ------------------------------------------------ S_kj = sum_i sum_n W_ijk(t)
// Kept in its own step (the original code folded it into the Theta update)
// because the elliptical slice target needs it even when Theta is held fixed.
inline void accumulate_S(arma::mat &Smat,
                         const arma::mat &W,
                         std::vector<arma::uvec> &sample_indices) {
  const arma::uword J = Smat.n_rows;
  for (arma::uword j = 0; j < J; j++) {
    arma::uvec &idx = sample_indices[j];
    if (!idx.is_empty()) {
      Smat.row(j) = arma::sum(W.rows(idx), 0);
    } else {
      Smat.row(j).zeros();
    }
  }
}

// ------------------------------------------------------------- activities
// theta_kj ~ Ga(a + S_kj, 1 + a/mu_k). Neither CopyTrack nor beta appears: the
// e^{beta'x} in the prior rate is exactly what cancels the compensator.
inline void update_Activities_Theta(arma::mat &Theta,
                                    const arma::mat &Smat,
                                    const arma::rowvec &Mu,
                                    double a) {
  const arma::uword J = Theta.n_rows, K = Theta.n_cols;
  for (arma::uword j = 0; j < J; j++) {
    for (arma::uword k = 0; k < K; k++) {
      Theta(j, k) = arma::randg(1, arma::distr_param(a + Smat(j, k),
                                1.0 / (1.0 + a / Mu(k))))(0);
    }
  }
}

// ------------------------------------------------------- relevance weights
// mu_k ~ InvGa(a0 + a J, b0 + a sum_j theta_kj). The old version weighted the
// sum by CopyTot_j; on the activity scale no weighting is needed, which is why
// mu keeps exactly the same meaning (expected count per patient) in both models.
inline void update_RelevanceWeights_Mu(arma::rowvec &Mu,
                                       const arma::mat &Theta,
                                       double a, double a0, double b0) {
  const arma::uword K = Theta.n_cols, J = Theta.n_rows;
  arma::rowvec rate = b0 + a * arma::sum(Theta, 0);
  for (arma::uword k = 0; k < K; k++) {
    Mu(k) = arma::randg(1, arma::distr_param(a0 + a * J, 1.0 / rate(k)))(0);
  }
  Mu = 1.0 / Mu;
}

// ------------------------------------------------------------------ variances
inline void update_Variances_Sigma2(arma::rowvec &Sigma2,
                                    const arma::mat &Betas,
                                    double c0, double d0) {
  const arma::uword K = Betas.n_cols;
  const double p = Betas.n_rows;
  arma::rowvec Betasq = arma::sum(arma::square(Betas), 0);
  for (arma::uword k = 0; k < K; k++) {
    Sigma2(k) = arma::randg(1, arma::distr_param(c0 + p / 2.0,
                            1.0 / (d0 + Betasq(k) / 2.0)))(0);
  }
  Sigma2 = 1.0 / Sigma2;
}

// ============================ elliptical slice ==============================

// - sum_j S_kj log q_j(beta), over the patients listed in `idx` only.
// CopyTrack.col(j) is contiguous, so each q_j is a BLAS dot product.
inline double neg_S_logq_active(const arma::vec &v,
                                const arma::mat &CopyTrack,
                                const arma::vec &S_k,
                                const arma::uvec &idx) {
  double acc = 0.0;
  for (arma::uword m = 0; m < idx.n_elem; ++m) {
    const arma::uword j = idx(m);
    const double qj = arma::dot(CopyTrack.col(j), v);
    acc += S_k(j) * std::log(qj > Q_FLOOR ? qj : Q_FLOOR);
  }
  return -acc;
}

// Same quantity with one transposed GEMV over all patients.
inline double neg_S_logq_all(const arma::vec &v,
                             const arma::mat &CopyTrack,
                             const arma::vec &S_k) {
  arma::vec q = CopyTrack.t() * v;
  return -arma::dot(S_k, arma::log(arma::clamp(q, Q_FLOOR, arma::datum::inf)));
}

// Reference implementation: recomputes SignalTrack * beta at every proposal.
arma::vec EllipticalSlice_ref(int k,
                              const arma::vec &beta0,
                              const arma::mat &WtX,
                              const arma::rowvec &Sigma2,
                              const arma::mat &SignalTrack,
                              const arma::mat &CopyTrack,
                              const arma::vec &S_k) {
  const int p = beta0.n_elem;

  arma::vec nu = arma::randn<arma::vec>(p) * std::sqrt(Sigma2(k));
  double u = arma::as_scalar(arma::randu(1));

  arma::vec v0 = arma::exp(arma::clamp(SignalTrack * beta0, -20, 20));
  double logF0 = neg_S_logq_all(v0, CopyTrack, S_k) +
    arma::as_scalar(WtX.row(k) * beta0);
  double logy = logF0 + std::log(u);

  double theta = 2 * M_PI * arma::as_scalar(arma::randu(1));
  double theta_min = theta - 2.0 * M_PI, theta_max = theta;

  arma::vec beta_prop;
  const int max_iter = 1000;
  for (int i = 0; i < max_iter; i++) {
    beta_prop = beta0 * std::cos(theta) + nu * std::sin(theta);
    arma::vec v = arma::exp(arma::clamp(SignalTrack * beta_prop, -20, 20));
    double logF = neg_S_logq_all(v, CopyTrack, S_k) +
      arma::as_scalar(WtX.row(k) * beta_prop);
    if (logF > logy) return beta_prop;
    if (theta < 0) theta_min = theta; else theta_max = theta;
    theta = arma::as_scalar(arma::randu(1)) * (theta_max - theta_min) + theta_min;
  }
  Rcpp::Rcout << "Warning: ESS did not accept in max_iter\n";
  return beta0;
}

// Fast version. Mathematically identical; only the order of the arithmetic
// changes, and the random draws are the same in number and order, so with the
// same seed the two agree to summation rounding.
//   sb0 = SignalTrack * beta0 arrives precomputed (one GEMM for all signatures);
//   sb1 = SignalTrack * nu is drawn here, so it keeps its own pass.
arma::vec EllipticalSlice_fast(int k,
                               const arma::vec &beta0,
                               const arma::mat &WtX,
                               const arma::rowvec &Sigma2,
                               const arma::mat &SignalTrack,
                               const arma::mat &CopyTrack,
                               const arma::vec &S_k,
                               const arma::uvec &idx,
                               const arma::vec &sb0,
                               bool active_only) {
  const int p = beta0.n_elem;

  arma::vec nu = arma::randn<arma::vec>(p) * std::sqrt(Sigma2(k));
  double u = arma::as_scalar(arma::randu(1));
  arma::vec sb1 = SignalTrack * nu;

  const arma::vec v0 = arma::exp(arma::clamp(sb0, -20, 20));
  double logF0 = (active_only ? neg_S_logq_active(v0, CopyTrack, S_k, idx)
                              : neg_S_logq_all(v0, CopyTrack, S_k)) +
    arma::as_scalar(WtX.row(k) * beta0);
  double logy = logF0 + std::log(u);

  double theta = 2 * M_PI * arma::as_scalar(arma::randu(1));
  double theta_min = theta - 2.0 * M_PI, theta_max = theta;

  arma::vec beta_prop;
  const int max_iter = 1000;
  for (int i = 0; i < max_iter; i++) {
    beta_prop = beta0 * std::cos(theta) + nu * std::sin(theta);
    arma::vec v = arma::exp(arma::clamp(sb0 * std::cos(theta) +
                                        sb1 * std::sin(theta), -20, 20));
    double logF = (active_only ? neg_S_logq_active(v, CopyTrack, S_k, idx)
                               : neg_S_logq_all(v, CopyTrack, S_k)) +
      arma::as_scalar(WtX.row(k) * beta_prop);
    if (logF > logy) return beta_prop;
    if (theta < 0) theta_min = theta; else theta_max = theta;
    theta = arma::as_scalar(arma::randu(1)) * (theta_max - theta_min) + theta_min;
  }
  Rcpp::Rcout << "Warning: ESS did not accept in max_iter\n";
  return beta0;
}

// ------------------------------- batched -----------------------------------
// The target for beta_k involves only Smat.col(k), WtX.row(k) and Sigma2(k):
// nothing from any other signature. Given W, S and sigma2 the K elliptical
// slice updates are therefore CONDITIONALLY INDEPENDENT, and can be advanced in
// lockstep instead of one after another. Each shrinkage round then evaluates
// every signature still looking for a point with ONE pass over CopyTrack:
//
//   sequential : sum_k (1 + shrinks_k)   passes over CopyTrack
//   batched    : 1 + max_k shrinks_k     passes over CopyTrack
//
// which on K = 12 signatures accepting after a couple of shrinkages each is
// close to a K-fold saving on the term that dominates this sampler. It is the
// same kernel - each beta_k is still drawn from its exact full conditional with
// its own independent randomness - but the draws are interleaved differently, so
// the chain does not follow the sequential one path for path.
inline void update_Betas_ESS_batched(arma::mat &Betas,
                                     const arma::mat &WtX,
                                     const arma::rowvec &Sigma2,
                                     const arma::mat &Smat,
                                     const arma::mat &SignalTrack,
                                     const arma::mat &CopyTrack) {
  const arma::uword K = Betas.n_cols, p = Betas.n_rows, B = SignalTrack.n_rows;

  const arma::mat Beta0 = Betas;
  arma::mat SB0 = SignalTrack * Beta0;                 // B x K, one GEMM

  arma::mat Nu(p, K);
  arma::vec logy(K), theta(K), theta_min(K), theta_max(K);
  for (arma::uword k = 0; k < K; ++k) {
    Nu.col(k) = arma::randn<arma::vec>(p) * std::sqrt(Sigma2(k));
    logy(k) = std::log(arma::as_scalar(arma::randu(1)));   // logF0 added below
    theta(k) = 2 * M_PI * arma::as_scalar(arma::randu(1));
    theta_min(k) = theta(k) - 2.0 * M_PI;
    theta_max(k) = theta(k);
  }
  arma::mat SB1 = SignalTrack * Nu;                    // B x K, one GEMM

  // Slice level for every signature: one pass over CopyTrack for all of them.
  // (Available saving, not taken: the caller's Qmat already holds q_j(beta_k) at
  // the incoming Betas - nothing between the two points touches Betas - so this
  // pass could be replaced by passing Qmat in. Worth ~1 of the ~15 passes per
  // iteration, at the cost of an implicit precondition on the caller.)
  arma::mat Q0 = CopyTrack.t() * arma::exp(arma::clamp(SB0, -20, 20));   // J x K
  for (arma::uword k = 0; k < K; ++k) {
    logy(k) += -arma::dot(Smat.col(k),
                          arma::log(arma::clamp(Q0.col(k), Q_FLOOR, arma::datum::inf))) +
      arma::as_scalar(WtX.row(k) * Beta0.col(k));
  }

  arma::uvec active = arma::regspace<arma::uvec>(0, K - 1);
  arma::mat Prop(p, K);
  const int max_iter = 1000;
  for (int r = 0; r < max_iter && !active.is_empty(); ++r) {
    const arma::uword A = active.n_elem;
    arma::mat V(B, A);
    for (arma::uword m = 0; m < A; ++m) {
      const arma::uword k = active(m);
      const double ct = std::cos(theta(k)), st = std::sin(theta(k));
      Prop.col(k) = Beta0.col(k) * ct + Nu.col(k) * st;
      V.col(m) = arma::exp(arma::clamp(SB0.col(k) * ct + SB1.col(k) * st, -20, 20));
    }
    arma::mat Q = CopyTrack.t() * V;                   // J x A, one pass
    std::vector<arma::uword> still;
    still.reserve(A);
    for (arma::uword m = 0; m < A; ++m) {
      const arma::uword k = active(m);
      double logF = -arma::dot(Smat.col(k),
                               arma::log(arma::clamp(Q.col(m), Q_FLOOR, arma::datum::inf))) +
        arma::as_scalar(WtX.row(k) * Prop.col(k));
      if (logF > logy(k)) {
        Betas.col(k) = Prop.col(k);
      } else {
        if (theta(k) < 0) theta_min(k) = theta(k); else theta_max(k) = theta(k);
        theta(k) = arma::as_scalar(arma::randu(1)) * (theta_max(k) - theta_min(k)) +
          theta_min(k);
        still.push_back(k);
      }
    }
    active.set_size(still.size());
    for (std::size_t i = 0; i < still.size(); ++i) active(i) = still[i];
  }
  if (!active.is_empty()) {
    // Signatures still in `active` keep their incoming value, as in the
    // sequential version.
    Rcpp::Rcout << "Warning: ESS did not accept in max_iter\n";
  }
}

// beta_update: 0 = reference, 1 = sequential with the ellipse hoisted and the
// contraction restricted to patients with S_kj > 0, 2 = batched (default).
inline void update_Betas_EllipticalSlice(arma::mat &Betas,
                                         const arma::mat &WtX,
                                         const arma::rowvec &Sigma2,
                                         const arma::mat &Smat,
                                         const arma::mat &SignalTrack,
                                         const arma::mat &CopyTrack,
                                         int beta_update) {
  const int K = Betas.n_cols;
  if (beta_update >= 2) {
    update_Betas_ESS_batched(Betas, WtX, Sigma2, Smat, SignalTrack, CopyTrack);
  } else if (beta_update == 1) {
    // One pass over SignalTrack for every signature instead of one per
    // signature. Column k is still the current beta_k when signature k is
    // reached, because the loop has only written columns 0..k-1.
    arma::mat SB0 = SignalTrack * Betas;
    for (int k = 0; k < K; k++) {
      arma::vec beta0 = Betas.col(k);
      arma::vec S_k = Smat.col(k);
      arma::uvec idx = arma::find(S_k > 0.0);
      arma::vec sb0 = SB0.col(k);
      // The contraction over patients is worth restricting only when a decent
      // share of them are inactive; otherwise the single transposed GEMV wins.
      bool active_only = (idx.n_elem * 2 < S_k.n_elem);
      Betas.col(k) = EllipticalSlice_fast(k, beta0, WtX, Sigma2, SignalTrack,
                                          CopyTrack, S_k, idx, sb0, active_only);
    }
  } else {
    for (int k = 0; k < K; k++) {
      arma::vec beta0 = Betas.col(k);
      arma::vec S_k = Smat.col(k);
      Betas.col(k) = EllipticalSlice_ref(k, beta0, WtX, Sigma2, SignalTrack,
                                         CopyTrack, S_k);
    }
  }
}

} // namespace activity_prior


// [[Rcpp::export(.PoissonProcess_BayesActivityCN)]]
List PoissonProcess_BayesActivityCN(arma::mat &R_start,
                                    arma::mat &Theta_start,
                                    arma::mat &Betas_start,
                                    arma::rowvec &Mu_start,
                                    arma::rowvec &Sigma2_start,
                                    arma::mat &X,
                                    arma::mat &SignalTrack,
                                    arma::mat &CopyTrack,
                                    int nsamples,
                                    int burn_in,
                                    arma::uvec channel_id,
                                    arma::uvec sample_id,
                                    arma::mat SigPrior,
                                    bool update_R = true,
                                    bool update_Theta = true,
                                    bool update_Betas = true,
                                    double a = 1.1,
                                    double a0 = 2.5,
                                    double b0 = 1.5,
                                    double c0 = 100,
                                    double d0 = 1,
                                    int beta_update = 2,
                                    bool reuse_probs = true,
                                    int logpost_every = 10,
                                    int thin = 1,
                                    double iter_offset = 0,
                                    double total_all = 0,
                                    int print_every = 10,
                                    bool use_cr = true,
                                    double elapsed_offset = 0,
                                    bool verbose = false) {
  using namespace activity_prior;

  // Model dimensions
  const int I = R_start.n_rows;        // mutational channels
  const int J = Theta_start.n_cols;    // patients
  const int K = Theta_start.n_rows;    // signatures
  const int p = Betas_start.n_rows;    // covariates
  const int N = X.n_rows;              // mutations

  if (thin < 1) thin = 1;
  // Only every thin-th iteration is retained. `nsamples` always counts ITERATIONS, so a
  // block is a whole number of thinning cycles and the stored draws of
  // consecutive blocks concatenate without a gap or a duplicate at the seam.
  const arma::uword n_store = (arma::uword) (nsamples / thin);

  // Storage
  arma::cube BETAS(n_store, p, K);
  arma::cube THETAS(n_store, K, J);
  arma::cube SIGS(n_store, I, K);
  arma::mat MU(n_store, K);
  arma::mat SIGMA(n_store, K);
  arma::vec LP(n_store);
  arma::vec LLik(n_store);
  arma::vec LPrior(n_store);

  // Starting values. Theta is TOTAL activity here, transposed to J x K once.
  arma::mat R = R_start;
  arma::mat Theta = Theta_start.t();
  arma::mat Betas = Betas_start;
  arma::rowvec Mu = Mu_start;
  arma::rowvec Sigma2 = Sigma2_start;
  arma::mat W(N, K, arma::fill::zeros);
  arma::mat bigProd(N, K);

  // Ancillary quantities
  arma::mat Probs(N, K, arma::fill::zeros);
  arma::mat Alpha(I, K, arma::fill::zeros);
  arma::mat Smat(J, K, arma::fill::zeros);
  arma::mat WtX = W.t() * X;

  // Mean responses. Qmat(j, k) = q_j(beta_k); Phi = Theta / Qmat is the baseline
  // on the old scale, and is what the assignment probabilities need.
  arma::mat Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
  arma::mat ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
  arma::mat Qmat = CopyTrack.t() * ExpBetaSignal;
  arma::mat Phi = Theta / Qmat;

  // Seed bigProd from the starting values, so the first iteration sees the same
  // Probs whether or not reuse_probs is on.
  bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);

  // Index sets
  std::vector<arma::uvec> channel_indices(I);
  for (arma::uword i = 0; i < I; ++i) channel_indices[i] = arma::find(channel_id == i);
  std::vector<arma::uvec> sample_indices(J);
  for (arma::uword j = 0; j < J; ++j) sample_indices[j] = arma::find(sample_id == j);

  signatureppf::ProgressReporter progress("MCMC (ess)", (arma::uword) nsamples,
                                          (arma::uword) iter_offset,
                                          (arma::uword) total_all,
                                          verbose ? print_every : 0, use_cr,
                                          elapsed_offset);

  arma::uword s = 0;   // index of the next stored draw
  for (arma::uword iter = 0; iter < (arma::uword)nsamples; iter++) {

    // STEP 1 - latent categorical assignment for each mutation
    if (!reuse_probs) {
      bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
    }
    Probs = arma::normalise(bigProd + arma::datum::eps / 30, 1, 1);
    update_Mutation_assignement(W, Probs);

    // Aggregate the assignments once: both the Theta step and the beta target
    // need S_kj.
    accumulate_S(Smat, W, sample_indices);

    // STEP 2 - signatures
    if (update_R) update_Signatures_R(R, W, SigPrior, Alpha, channel_indices);

    // STEP 3 - activities and relevance weights
    if (update_Theta) {
      update_Activities_Theta(Theta, Smat, Mu, a);
      update_RelevanceWeights_Mu(Mu, Theta, a, a0, b0);
    }

    // STEP 4 - regression coefficients and their variances
    if (update_Betas) {
      WtX = W.t() * X;
      update_Betas_EllipticalSlice(Betas, WtX, Sigma2, Smat, SignalTrack,
                                   CopyTrack, beta_update);
      Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
      ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
      Qmat = CopyTrack.t() * ExpBetaSignal;
      update_Variances_Sigma2(Sigma2, Betas, c0, d0);
    }

    // Phi must be refreshed after either Theta or Betas moved.
    Phi = Theta / Qmat;

    // Thinning and the log-posterior grid are anchored to the RUN, not to the
    // checkpoint block, so that the draws of consecutive blocks concatenate into
    // exactly the sequence an uninterrupted run of the same length would store.
    const arma::uword global = (arma::uword) iter_offset + iter;
    const bool store = (((iter + 1) % (arma::uword) thin) == 0);

    // The log posterior is a diagnostic and never feeds back into an update, so
    // evaluating it every logpost_every-th iteration only subsamples the trace.
    // There is no reason to spend it on a iteration that is about to be discarded by
    // thinning, so it is only ever evaluated on a stored iteration.
    const bool eval_logpost = store &&
      ((logpost_every <= 1) || (((global + 1) % (arma::uword) logpost_every) == 0));
    if (reuse_probs || eval_logpost) {
      bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
    }

    double logLik = arma::datum::nan, logPrior = arma::datum::nan,
           logPost = arma::datum::nan;
    if (eval_logpost) {
      // The compensator is just the sum of the activities.
      logLik = arma::accu(arma::log(arma::sum(bigProd, 1))) - arma::accu(Theta);

      logPrior = arma::accu((SigPrior - 1) % arma::log(R)) +               // Dirichlet over signatures
        arma::accu((a - 1) * arma::log(Theta)) -
        a * arma::accu(arma::sum(Theta, 0) / Mu) -
        arma::accu(a * J * arma::log(Mu)) +                                // Gamma over activities
        arma::accu(- (a0 + 1) * arma::log(Mu) - b0 / Mu) +                 // InvGamma over mu
        arma::accu(- (c0 + 1 + p / 2.0) * arma::log(Sigma2) - d0 / Sigma2) + // InvGamma over sigma2
        arma::accu(- (0.5 / Sigma2) % arma::sum(arma::square(Betas), 0));  // Normal over betas

      logPost = logPrior + logLik;
    }

    if (store) {
      BETAS.row(s) = Betas;
      THETAS.row(s) = Theta.t();
      SIGS.row(s) = R;
      MU.row(s) = Mu;
      SIGMA.row(s) = Sigma2;
      LPrior(s) = logPrior;
      LLik(s) = logLik;
      LP(s) = logPost;
      ++s;
    }

    progress.tick(iter, logPost);
  }
  progress.finish();

    return List::create(_["SIGSchain"] = SIGS,
                      _["THETAchain"] = THETAS,
                      _["BETASchain"] = BETAS,
                      _["MUchain"] = MU,
                      _["SIGMA2chain"] = SIGMA,
                      _["logPostchain"] = LP,
                      _["logLikchain"] = LLik,
                      _["logPriorchain"] = LPrior,
                      // Parameters at the last iteration, so a further call can
                      // continue this chain. They are not recoverable from the
                      // stored draws once thin > 1.
                      _["last"] = List::create(_["R"] = R,
                                               _["Theta"] = Theta.t(),
                                               _["Betas"] = Betas,
                                               _["Mu"] = Mu,
                                               _["Sigma2"] = Sigma2));
}
