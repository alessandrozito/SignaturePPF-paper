#ifndef SIGNATUREPPF_PROGRESS_H
#define SIGNATUREPPF_PROGRESS_H

// Progress reporting shared by the MAP and MCMC backends.
//
// The old package printed a bare iteration counter, which says nothing about how
// long a run will take - and these runs take hours. This prints the iteration,
// the current objective, the per-iteration cost and an ETA:
//
//   iter    1200/10000 | logpost -12,345,678.90 |    0.84 s/it | elapsed 00:17:12 | eta 02:03:41
//
// Three deliberate choices:
//
//   * the per-iteration cost is the MEDIAN over a trailing window, not the mean.
//     Garbage collection, the periodic log-posterior evaluation and the AGESS
//     promotions all produce occasional slow iterations, and a mean over a short
//     window chases them. The median is what a user actually wants to read off.
//
//   * the ETA is withheld until the window has filled enough to mean anything,
//     rather than printing a wild number over the first few iterations.
//
//   * interactively the line is refreshed in place with a carriage return; when
//     R is not interactive (the cluster case, output redirected to a log file) a
//     carriage return would collapse the whole run onto one unreadable line, so
//     each report is written on its own line instead. `use_cr` is set from R.
//
// The reporter also owns the interrupt check, so every backend that reports
// progress is also interruptible. Rcpp::checkUserInterrupt() runs the check
// inside R_ToplevelExec and then throws a C++ exception, so unwinding destroys
// the surrounding Armadillo objects properly; a bare R_CheckUserInterrupt()
// would longjmp straight past their destructors.

#include <RcppArmadillo.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace signatureppf {

class ProgressReporter {
public:
  // label       shown on the closing summary line
  // total       iterations in THIS call (one checkpoint block, not the whole run)
  // iter_offset iterations already completed in earlier blocks
  // total_all   iterations in the whole run, so the ETA spans the run not the block
  // every       print interval; <= 0 silences printing but keeps interrupt checks
  ProgressReporter(const std::string &label,
                   arma::uword total,
                   arma::uword iter_offset,
                   arma::uword total_all,
                   int every,
                   bool use_cr = true,
                   double elapsed_offset = 0.0,
                   const char *objective_name = "logpost")
    : label_(label),
      total_(total),
      offset_(iter_offset),
      total_all_(total_all > 0 ? total_all : total),
      every_(every),
      use_cr_(use_cr),
      elapsed_offset_(elapsed_offset),
      objective_name_(objective_name),
      window_((std::size_t) kWindow, 0.0),
      n_times_(0),
      start_(std::chrono::steady_clock::now()),
      last_(start_),
      printed_(false),
      last_objective_(arma::datum::nan) {}

  // Call once per iteration, at the END of the iteration. `iter` is 0-based and local
  // to this block. Pass NA/NaN for `objective` on iterations where it was not
  // evaluated - the last finite value is carried forward in the display.
  void tick(arma::uword iter, double objective) {
    const std::chrono::steady_clock::time_point now = std::chrono::steady_clock::now();
    const double dt = std::chrono::duration<double>(now - last_).count();
    last_ = now;

    window_[n_times_ % (std::size_t) kWindow] = dt;
    ++n_times_;

    if (std::isfinite(objective)) last_objective_ = objective;

    // Checked every iteration regardless of the print interval: the cost is
    // negligible next to one Gibbs iteration, and a run that cannot be stopped with
    // Ctrl-C is a run that has to be killed from outside R.
    Rcpp::checkUserInterrupt();

    if (every_ <= 0) return;
    const bool is_last = (iter + 1 == total_);
    if (((iter + 1) % (arma::uword) every_ != 0) && !is_last) return;

    print(iter);
  }

  // Closes the refreshed line, but only once the run - not merely this block -
  // is over: a checkpointed run makes one call per block, and closing the line
  // each time would print a hundred stray newlines. The wall-time summary is
  // left to the R caller, which is the only side that knows the whole run.
  void finish() {
    if (every_ <= 0) return;
    const bool last_block = (offset_ + total_ >= total_all_);
    if (printed_ && use_cr_ && last_block) Rcpp::Rcout << "\n";
    Rcpp::Rcout.flush();
  }

  // Wall time spent on the RUN, not on this block: a checkpointed chain is a
  // sequence of calls, and an elapsed time that restarted at zero every block
  // would make a resumed run look far cheaper than it was.
  double elapsed() const {
    return elapsed_offset_ + std::chrono::duration<double>(
      std::chrono::steady_clock::now() - start_).count();
  }

  // Appended verbatim to the reported line. The MAP backend uses it to show the
  // relative change in the objective alongside the objective itself.
  void set_extra(const std::string &s) { extra_ = s; }

  // What the projected time is called. The MCMC runs a fixed number of iterations,
  // so time-to-completion really is an estimate. The optimizer stops at `tol`,
  // usually long before `maxiter`, so the same number is an upper BOUND there
  // and calling it an eta promises hours that will not be spent.
  void set_eta_label(const std::string &s) { eta_label_ = s; }

private:
  enum { kWindow = 50, kWarmup = 5 };

  void print(arma::uword iter) {
    const arma::uword done_all = offset_ + iter + 1;
    const double per_it = median_time();

    char buf[384];
    std::snprintf(buf, sizeof(buf), "%s  iter %7llu/%llu | %s %18s | %s | elapsed %s",
                  use_cr_ ? "\r" : "",
                  (unsigned long long) done_all,
                  (unsigned long long) total_all_,
                  objective_name_,
                  fmt_fixed(last_objective_, 2).c_str(),
                  rate(per_it).c_str(),
                  hms(elapsed()).c_str());
    Rcpp::Rcout << buf;

    if (!extra_.empty()) Rcpp::Rcout << " | " << extra_;

    if (n_times_ >= (std::size_t) kWarmup && per_it > 0.0 && done_all < total_all_) {
      Rcpp::Rcout << " | " << eta_label_ << " "
                  << hms(per_it * (double) (total_all_ - done_all));
    }
    if (use_cr_) {
      Rcpp::Rcout << "      ";   // clears any tail left by a longer previous line
    } else {
      Rcpp::Rcout << "\n";
    }
    Rcpp::Rcout.flush();
    printed_ = true;
  }

  // Median of the trailing window. Copies at most kWindow doubles, so the cost is
  // irrelevant next to the iteration it is timing.
  double median_time() const {
    const std::size_t n = std::min(n_times_, (std::size_t) kWindow);
    if (n == 0) return 0.0;
    std::vector<double> v(window_.begin(), window_.begin() + n);
    std::nth_element(v.begin(), v.begin() + n / 2, v.end());
    return v[n / 2];
  }

  // Fixed-point with thousands separators. Scientific notation is compact but
  // hard to compare at a glance across iterations - the exponent moves and the
  // eye has to re-read it every time - so the objective and the convergence
  // criterion are both printed as plain numbers.
  static std::string fmt_fixed(double x, int decimals) {
    if (!std::isfinite(x)) return "--";
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%.*f", decimals, x);
    std::string s(buf);

    const bool neg = (!s.empty() && s[0] == '-');
    if (neg) s.erase(0, 1);
    std::size_t dot = s.find('.');
    std::size_t int_end = (dot == std::string::npos) ? s.size() : dot;
    // Walk back from the decimal point inserting a separator every three digits.
    for (std::size_t i = int_end; i > 3; ) {
      i -= 3;
      s.insert(i, ",");
      int_end += 1;
    }
    return neg ? "-" + s : s;
  }

  // Sub-second iterations read better as it/s than as a string of leading zeros.
  static std::string rate(double per_it) {
    char buf[64];
    if (per_it <= 0.0)      std::snprintf(buf, sizeof(buf), "     --     ");
    else if (per_it >= 0.1) std::snprintf(buf, sizeof(buf), "%7.2f s/it", per_it);
    else                    std::snprintf(buf, sizeof(buf), "%7.1f it/s", 1.0 / per_it);
    return std::string(buf);
  }

  static std::string hms(double seconds) {
    if (!std::isfinite(seconds) || seconds < 0) return "--:--:--";
    const long long s = (long long) std::llround(seconds);
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%02lld:%02lld:%02lld",
                  s / 3600, (s % 3600) / 60, s % 60);
    return std::string(buf);
  }

  std::string label_;
  arma::uword total_, offset_, total_all_;
  int every_;
  bool use_cr_;
  double elapsed_offset_;
  const char *objective_name_;
  std::vector<double> window_;
  std::size_t n_times_;
  std::chrono::steady_clock::time_point start_, last_;
  bool printed_;
  double last_objective_;
  std::string extra_;
  std::string eta_label_ = "eta";
};

}  // namespace signatureppf

#endif  // SIGNATUREPPF_PROGRESS_H
