// ============================================================================
// Calibration of the informative-signature prior strength.
//
// betah_h is the total concentration of the Dirichlet prior on reference
// signature h, Dir(betah_h * s_h). It is calibrated by the criterion of
// CompressiveNMF: the value at which a draw from the prior has median cosine
// similarity `target` to the reference it is centred on.
//
// The R reference implementation evaluated that criterion by bisection over a
// wide bracket, ~13 Monte Carlo evaluations per signature. Two things make this
// version roughly an order of magnitude faster, and neither changes the
// criterion being solved.
//
// ---------------------------------------------------------------------------
// 1. THE EVALUATION IS STREAMED, AND THE NORMALISATION IS DROPPED
// ---------------------------------------------------------------------------
// The R version materialised the whole nsim x I matrix of Dirichlet draws, then
// normalised each row to sum to one, then took cosines. Neither step is needed:
// cosine similarity is scale invariant, so a Dirichlet draw can be replaced by
// the unnormalised gammas that generate it,
//
//     cos(g / sum(g), s) = cos(g, s),
//
// and each draw's contribution can be reduced to two accumulators as it is
// generated. Storage drops from nsim*I to nsim, and one pass over a 96 x 1000
// matrix per evaluation disappears.
//
// ---------------------------------------------------------------------------
// 2. THE ROOT IS FOUND BY A SCALING LAW, NOT BY BISECTION
// ---------------------------------------------------------------------------
// Write x ~ Dir(beta s) as x = s + e, so E[e] = 0 and
// Cov(e_i, e_j) = (s_i 1{i=j} - s_i s_j) / (beta + 1). Expanding the cosine to
// second order in e, with u = <e,s>/||s||^2 and v = ||e||^2/||s||^2,
//
//     cos(x, s) = (1 + u) / sqrt(1 + 2u + v)  =  1 - (v - u^2)/2 + O(e^3),
//
// and taking expectations of v and u^2 term by term gives
//
//     1 - E[cos]  ~=  C(s) / (2 (beta + 1)),
//     C(s) = (1 - m2)/m2 - (m3 - m2^2)/m2^2,   m2 = sum s_i^2,  m3 = sum s_i^3.
//
// So the miss (1 - cos) is inversely proportional to beta. Two consequences:
//
//   * the bracket is unnecessary - C(s) gives a starting value directly, and it
//     lands within a few percent for every COSMIC signature;
//   * a correction step is just a rescaling,
//         beta <- (beta + 1) * (1 - cos) / (1 - target) - 1,
//     which is a fixed point iteration with the exact asymptotic rate, so it
//     converges in one or two steps rather than the ~10 bisection needs.
//
// The expansion degrades when 1 - cos is not small, but the target is 0.975 by
// construction, so the solution always sits where it is accurate. Nothing relies
// on the approximation being right: every step is CHECKED by an actual Monte
// Carlo evaluation, and the loop only stops when a measured median similarity is
// within `tol` of the target. A bad prediction costs an extra iteration, not a
// wrong answer.
//
// ---------------------------------------------------------------------------
// A WARNING ABOUT SMALL beta
// ---------------------------------------------------------------------------
// Median similarity is NOT monotone in beta all the way down. As beta -> 0 the
// Dirichlet degenerates onto a single channel, drawn with probability s_i; for a
// spiked signature that degenerate draw has a high cosine to the reference, so
// similarity RISES again as beta falls. SBS10a, whose largest channel carries
// 0.67 of the mass, measures 0.977 at beta = 1, 0.969 at beta = 2 and 0.977
// again at beta = 8. A search bracket reaching down to 0 therefore admits a
// second root that is an artefact of degeneracy rather than a prior that says
// anything about the signature. `lo` exists to keep the search on the branch
// that does, and defaults to 10 - which is also where CompressiveNMF's own grid
// starts.
// ============================================================================
#include <RcppArmadillo.h>
#include <algorithm>
#include <cmath>
#include <vector>

using namespace Rcpp;

// [[Rcpp::depends(RcppArmadillo)]]

namespace {

// Median cosine similarity between s and nsim draws from Dir(betah * s).
double median_cosine(double betah, const arma::vec &s, double norm_s,
                     int nsim, std::vector<double> &buf) {
  const arma::uword I = s.n_elem;
  buf.resize(nsim);

  for (int r = 0; r < nsim; ++r) {
    double dot = 0.0, sq = 0.0;
    for (arma::uword i = 0; i < I; ++i) {
      const double shape = betah * s(i);
      // R::rgamma is undefined at shape 0; a zero concentration means that
      // coordinate is identically zero under the Dirichlet.
      const double g = (shape > 0.0) ? R::rgamma(shape, 1.0) : 0.0;
      dot += g * s(i);
      sq  += g * g;
    }
    buf[r] = (sq > 0.0) ? dot / (std::sqrt(sq) * norm_s) : 0.0;
  }

  // Only the middle order statistic is wanted, so a full sort is wasted work.
  const std::size_t n = buf.size();
  std::nth_element(buf.begin(), buf.begin() + n / 2, buf.end());
  double med = buf[n / 2];
  if (n % 2 == 0) {
    // Even n: average the two central order statistics, matching R's median().
    const double hi = *std::max_element(buf.begin(), buf.begin() + n / 2);
    med = 0.5 * (med + hi);
  }
  return med;
}

}  // namespace


// [[Rcpp::export(.tune_betah_cpp)]]
List tune_betah_cpp(const arma::mat &sigs,
                    double target,
                    int nsim,
                    double lo,
                    double hi,
                    int max_iter,
                    double tol) {

  const arma::uword H = sigs.n_cols;
  arma::vec betah(H), similarity(H);
  arma::ivec iters(H, arma::fill::zeros);
  std::vector<double> buf;
  buf.reserve(nsim);

  for (arma::uword h = 0; h < H; ++h) {
    const arma::vec s = sigs.col(h);
    const double norm_s = arma::norm(s, 2);
    const double m2 = arma::accu(arma::square(s));
    const double m3 = arma::accu(arma::pow(s, 3));

    // Second-order starting value; see the header. Degenerate shapes (a point
    // mass, where C <= 0) fall back to the middle of the search range.
    const double C = (1.0 - m2) / m2 - (m3 - m2 * m2) / (m2 * m2);
    double b = (C > 0.0) ? C / (2.0 * (1.0 - target)) - 1.0
                         : std::sqrt(lo * hi);
    b = std::min(std::max(b, lo), hi);

    double cos_b = median_cosine(b, s, norm_s, nsim, buf);
    int it = 1;

    while (std::fabs(cos_b - target) > tol && it < max_iter) {
      // (1 - cos) ~ C / (2(beta+1)), so matching the target is a rescaling.
      // Guarded against a near-exact hit turning into a division blow-up.
      const double miss = std::max(1.0 - cos_b, 1e-12);
      double b_new = (b + 1.0) * miss / (1.0 - target) - 1.0;
      b_new = std::min(std::max(b_new, lo), hi);

      // At the ends of the range the criterion cannot be met at all; stop rather
      // than iterate on a clamped value.
      if (b_new == b) break;

      b = b_new;
      cos_b = median_cosine(b, s, norm_s, nsim, buf);
      ++it;
    }

    betah(h) = b;
    similarity(h) = cos_b;
    iters(h) = it;

    Rcpp::checkUserInterrupt();
  }

  return List::create(_["betah"] = betah,
                      _["similarity"] = similarity,
                      _["iters"] = iters);
}
