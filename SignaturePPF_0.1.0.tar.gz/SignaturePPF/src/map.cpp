// ============================================================================
// MAP / MLE for the Poisson process factorization
//
// Remember that
// q_j(beta_k) = int 1/2 c_j(t) e^{beta_k'x(t)} dt, phi_kj = theta_kj/q_j(beta_k)
// and p_ijk the current attribution probabilities, the updates are
//
//   R      r'_ik = alpha_ik - 1 + sum_j sum_n p_ijk
//   Theta  theta_kj = (a - 1 + Sbar_kj) / (1 + a/mu_k)      Sbar_kj = sum_i sum_n p_ijk
//   Mu     mu_k = (b0 + a sum_j theta_kj) / (a0 + a J + 1)
//   Sigma2 sigma2_k = (d0 + |beta_k|^2/2) / (c0 + L/2 + 1)
//   Beta   Newton, beta_k <- beta_k - H_k^{-1} g_k with
//            H_k = sum_j Sbar_kj (Q_j/q_j - m_j m_j'/q_j^2) + I/sigma2_k
//            g_k = sum_j Sbar_kj m_j/q_j - sum_ijn p_ijk x(t_ijn) + beta_k/sigma2_k
//          where m_j = int 1/2 c_j e^{beta'x} x dt and Q_j = int 1/2 c_j e^{beta'x} xx' dt.
// ============================================================================
#include <RcppArmadillo.h>
#include <math.h>
#include <R.h>
#include <Rinternals.h>
#include <Rmath.h>
#include "progress.h"
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export(.PoissonProcess_optim_activity_CN)]]
List PoissonProcess_optim_activity_CN(arma::mat &R_start,         // Signatures
                                      arma::mat &Theta_start,     // Total activities
                                      arma::mat &Betas_start,     // Coefficients
                                      arma::rowvec &Mu_start,
                                      arma::rowvec &Sigma2_start,
                                      arma::mat &X,               // Covariates at the mutations
                                      arma::mat &SignalTrack,     // Covariates over the genome
                                      arma::mat &CopyTrack,
                                      arma::uvec channel_id,
                                      arma::uvec sample_id,
                                      arma::mat SigPrior,
                                      std::string method = "map",
                                      double a = 1.1,
                                      double a0 = 2.5, double b0 = 1.5,
                                      double c0 = 100, double d0 = 1,
                                      bool update_R = true,
                                      bool update_Theta = true,
                                      bool update_Betas = true,
                                      int n_iter_betas = 2,
                                      double rho = 0.5,
                                      int maxiter = 20,
                                      double tol = 1e-6,
                                      bool exact_hessian = true,
                                      int print_every = 10,
                                      bool use_cr = true,
                                      bool verbose = false) {

  const double Q_FLOOR = 1e-300;

  // Model dimensions
  const int I = R_start.n_rows;
  const int J = Theta_start.n_cols;
  const int K = Theta_start.n_rows;
  const int p = Betas_start.n_rows;
  const int N = X.n_rows;
  const int Ntrack = SignalTrack.n_rows;

  // Parameters. Theta is the total activity, transposed to J x K once.
  arma::mat R = R_start;
  arma::mat Theta = Theta_start.t();
  arma::mat Betas = Betas_start;
  arma::rowvec Mu = Mu_start;
  arma::rowvec Sigma2 = Sigma2_start;

  // Index sets
  std::vector<arma::uvec> channel_indices(I);
  for (arma::uword i = 0; i < I; ++i) channel_indices[i] = arma::find(channel_id == i);
  std::vector<arma::uvec> sample_indices(J);
  for (arma::uword j = 0; j < J; ++j) sample_indices[j] = arma::find(sample_id == j);

  arma::mat X_t = X.t();
  arma::mat SignalTrack_t = SignalTrack.t();

  // Working quantities
  arma::mat R_upd(I, K, arma::fill::zeros);
  arma::mat Sbar(J, K, arma::fill::zeros);
  arma::mat Gmat(J, K, arma::fill::zeros);
  arma::mat bin_CopyG(Ntrack, K);
  arma::mat Xtot_w(Ntrack, p);
  arma::vec grad_all(p);
  arma::mat Probs(N, K);
  arma::mat bigProd(N, K);
  arma::mat Hess(p, p, arma::fill::zeros);
  arma::mat grad_probs(p, K, arma::fill::zeros);
  arma::vec xi(p);

  // Mean responses
  arma::mat Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
  arma::mat ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
  arma::mat Qmat = CopyTrack.t() * ExpBetaSignal;      // J x K, q_j(beta_k)
  arma::mat Phi = Theta / Qmat;                        // baseline on the old scale

  // Convergence tracking
  arma::vec trace, trace_logLik, trace_logPrior;
  double maxdiff = 10.0;
  const int R_show = 10;

  bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
  double logLik_old = arma::accu(arma::log(arma::sum(bigProd, 1))) - arma::accu(Theta);
  double logPrior_old = 0.0, logPrior = 0.0, logLik = 0.0;

  if (method == "map") {
    logPrior_old = arma::accu((SigPrior - 1) % arma::log(R)) +
      arma::accu((a - 1) * arma::log(Theta)) -
      a * arma::accu(arma::sum(Theta, 0) / Mu) -
      arma::accu(a * J * arma::log(Mu)) +
      arma::accu(- (a0 + 1) * arma::log(Mu) - b0 / Mu) +
      arma::accu(- (c0 + 1 + p / 2.0) * arma::log(Sigma2) - d0 / Sigma2) +
      arma::accu(- (0.5 / Sigma2) % arma::sum(arma::square(Betas), 0));
  }

  signatureppf::ProgressReporter progress(
      method == "map" ? "MAP" : "MLE", (arma::uword) maxiter, 0,
      (arma::uword) maxiter, verbose ? print_every : 0, use_cr, 0.0,
      method == "map" ? "logpost" : "loglik");
  // The optimizer exits on `tol`, so the projection to `maxiter` is a ceiling.
  progress.set_eta_label("max");

  int it = 0;
  for (int iter = 0; iter < maxiter; iter++) {
    // NaN unless this iteration is one of the ones on which the objective is
    // actually evaluated; the reporter carries the last finite value forward.
    double objective = arma::datum::nan;

    if ((iter + 1) % R_show == 0) {
      bigProd = Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id);
      logLik = arma::accu(arma::log(arma::sum(bigProd, 1))) - arma::accu(Theta);
      if (method == "map") {
        logPrior = arma::accu((SigPrior - 1) % arma::log(R)) +
          arma::accu((a - 1) * arma::log(Theta)) -
          a * arma::accu(arma::sum(Theta, 0) / Mu) -
          arma::accu(a * J * arma::log(Mu)) +
          arma::accu(- (a0 + 1) * arma::log(Mu) - b0 / Mu) +
          arma::accu(- (c0 + 1 + p / 2.0) * arma::log(Sigma2) - d0 / Sigma2) +
          arma::accu(- (0.5 / Sigma2) % arma::sum(arma::square(Betas), 0));
        maxdiff = std::abs((logLik + logPrior) / (logLik_old + logPrior_old) - 1);
        objective = logLik + logPrior;
        {
          char b[64];
          std::snprintf(b, sizeof(b), "rel.diff %.8f", maxdiff);
          progress.set_extra(b);
        }
        logLik_old = logLik;
        logPrior_old = logPrior;
      } else if (method == "mle") {
        maxdiff = std::abs(logLik / logLik_old - 1);
        objective = logLik;
        {
          char b[64];
          std::snprintf(b, sizeof(b), "rel.diff %.8f", maxdiff);
          progress.set_extra(b);
        }
        logLik_old = logLik;
      }
      trace = arma::join_vert(trace, arma::vec({logPrior + logLik}));
      trace_logLik = arma::join_vert(trace_logLik, arma::vec({logLik}));
      trace_logPrior = arma::join_vert(trace_logPrior, arma::vec({logPrior}));
    }

    //-------------------------------------- STEP 0 - RELEVANCE WEIGHTS
    // Mode of InvGa(a0 + aJ, b0 + a sum_j theta_kj).
    if (update_Theta && method == "map") {
      Mu = (b0 + a * arma::sum(Theta, 0)) / (a0 + a * J + 1);
    }

    //-------------------------------------- STEP 1 - SIGNATURES R
    if (update_R) {
      Probs = arma::normalise(Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id), 1, 1);
      for (arma::uword i = 0; i < (arma::uword)I; i++) {
        arma::uvec &idx = channel_indices[i];
        if (!idx.is_empty()) R_upd.row(i) = arma::sum(Probs.rows(idx), 0);
      }
      if (method == "mle") {
        R = arma::normalise(R_upd, 1, 0);
      } else if (method == "map") {
        R = arma::normalise(R_upd + SigPrior - 1, 1, 0);
      }
      R.elem(arma::find(R <= 0)).fill(arma::datum::eps / 30);
    }

    //-------------------------------------- STEP 2 - ACTIVITIES THETA
    // theta_kj = (a - 1 + Sbar_kj)/(1 + a/mu_k). Neither q nor CopyTrack enters.
    if (update_Theta) {
      Probs = arma::normalise(Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id) +
                              arma::datum::eps / 30, 1, 1);
      for (arma::uword j = 0; j < (arma::uword)J; j++) {
        arma::uvec &idx = sample_indices[j];
        if (!idx.is_empty()) {
          Sbar.row(j) = arma::sum(Probs.rows(idx), 0);
        } else {
          Sbar.row(j).zeros();
        }
      }
      if (method == "mle") {
        Theta = Sbar;
      } else if (method == "map") {
        Theta = (Sbar + a - 1);
        Theta.each_row() /= (1.0 + a / Mu);
      }
      Theta.elem(arma::find(Theta <= 0)).fill(arma::datum::eps / 30);
      Phi = Theta / Qmat;
    }

    //-------------------------------------- STEP 3 - REGRESSION COEFFICIENTS BETA
    if (update_Betas) {

      Sigma2 = (d0 + arma::sum(arma::square(Betas), 0) / 2.0) / (c0 + p / 2.0 + 1);

      for (int iter_betas = 0; iter_betas < n_iter_betas; iter_betas++) {
        Probs = arma::normalise(Exp_XBetas % Phi.rows(sample_id) % R.rows(channel_id) +
                                arma::datum::eps / 30, 1, 1);
        // Sbar has to follow Betas, since Probs does.
        for (arma::uword j = 0; j < (arma::uword)J; j++) {
          arma::uvec &idx = sample_indices[j];
          if (!idx.is_empty()) {
            Sbar.row(j) = arma::sum(Probs.rows(idx), 0);
          } else {
            Sbar.row(j).zeros();
          }
        }
        // sum_ijn p_ijk x(t_ijn)
        grad_probs = X_t * Probs;

        // G_jk = Sbar_kj / q_j(beta_k); gamma_k = CopyTrack * G_.k
        Gmat = Sbar / arma::clamp(Qmat, Q_FLOOR, arma::datum::inf);
        bin_CopyG = CopyTrack * Gmat;

        // m_j for every signature, needed only by the exact Hessian. Computed
        // in blocks of signatures so CopyTrack is read ceil(K/blk) times per
        // Newton step rather than K times, with the stacked temporary held to a
        // fixed budget.
        std::vector<arma::mat> Mt_all;
        if (exact_hessian) {
          const double budget = 256e6;
          arma::uword blk = (arma::uword) std::max(1.0,
                              std::floor(budget / (8.0 * (double)Ntrack * (double)p)));
          blk = std::min<arma::uword>(blk, (arma::uword)K);
          Mt_all.resize(K);
          for (arma::uword k0 = 0; k0 < (arma::uword)K; k0 += blk) {
            const arma::uword kb = std::min<arma::uword>(blk, (arma::uword)K - k0);
            arma::mat Big(Ntrack, kb * (arma::uword)p);
            for (arma::uword m = 0; m < kb; ++m) {
              Big.cols(m * p, (m + 1) * p - 1) =
                SignalTrack.each_col() % ExpBetaSignal.col(k0 + m);
            }
            arma::mat MtBlk = CopyTrack.t() * Big;          // J x (kb*p)
            for (arma::uword m = 0; m < kb; ++m) {
              Mt_all[k0 + m] = MtBlk.cols(m * p, (m + 1) * p - 1);
            }
          }
        }

        for (int k = 0; k < K; k++) {
          Xtot_w = SignalTrack.each_col() % (ExpBetaSignal.col(k) % bin_CopyG.col(k));
          Hess = SignalTrack_t * Xtot_w;
          Hess = (Hess + Hess.t()) / 2.0;

          if (exact_hessian) {
            // - sum_j (Sbar_kj/q_j^2) m_j m_j', with Mt_all[k].row(j) = m_j'.
            const arma::mat &Mt = Mt_all[k];
            arma::vec dvec = Sbar.col(k) / arma::square(arma::clamp(Qmat.col(k), Q_FLOOR,
                                                                   arma::datum::inf));
            arma::mat Corr = Mt.t() * (Mt.each_col() % dvec);
            Hess -= (Corr + Corr.t()) / 2.0;
          }

          if (method == "mle") {
            Hess += 200 * arma::eye(arma::size(Hess));
            grad_all = arma::sum(Xtot_w, 0).t();
          } else if (method == "map") {
            Hess += 1 / Sigma2(k) * arma::eye(arma::size(Hess));
            grad_all = arma::sum(Xtot_w, 0).t() + Betas.col(k) / Sigma2(k);
          }

          xi = arma::solve(Hess, (grad_probs.col(k) - grad_all),
                           arma::solve_opts::likely_sympd);
          Betas.col(k) += xi * std::min(1.0, rho * std::pow(p, 0.5) / arma::norm(xi));
        }
        Betas = arma::clamp(Betas, -20, 20);
        Exp_XBetas = arma::exp(arma::clamp(X * Betas, -20, 20));
        ExpBetaSignal = arma::exp(arma::clamp(SignalTrack * Betas, -20, 20));
        Qmat = CopyTrack.t() * ExpBetaSignal;
        Phi = Theta / Qmat;
      }
    }

    progress.tick((arma::uword) iter, objective);

    // `it` counts iterations actually performed, so it agrees with what the
    // progress line reported; previously it stopped one short of the loop.
    it += 1;
    if (maxdiff < tol) break;
  }
  progress.finish();

  return List::create(_["R"] = R,
                      _["Theta"] = Theta.t(),
                      _["Phi"] = Phi.t(),
                      _["Q"] = Qmat.t(),
                      _["Betas"] = Betas,
                      _["Mu"] = Mu,
                      _["Sigma2"] = Sigma2,
                      _["iter"] = it,
                      _["maxdiff"] = maxdiff,
                      _["trace"] = trace,
                      _["trace_logLik"] = trace_logLik,
                      _["trace_logPrior"] = trace_logPrior);
}
